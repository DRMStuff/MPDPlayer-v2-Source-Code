/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.net;

import java.io.IOException;

public interface ObjectWriter {
    public void write(Object var1) throws IOException;
}

