/*
 * Decompiled with CFR 0.150.
 */
package ch.qos.logback.core.joran.node;

public class ComponentNode {
    String classStr;
}

