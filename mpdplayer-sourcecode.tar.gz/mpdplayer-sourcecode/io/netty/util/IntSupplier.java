/*
 * Decompiled with CFR 0.150.
 */
package io.netty.util;

public interface IntSupplier {
    public int get() throws Exception;
}

