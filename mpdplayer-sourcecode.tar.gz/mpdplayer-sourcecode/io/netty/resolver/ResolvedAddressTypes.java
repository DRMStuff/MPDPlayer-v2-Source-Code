/*
 * Decompiled with CFR 0.150.
 */
package io.netty.resolver;

public enum ResolvedAddressTypes {
    IPV4_ONLY,
    IPV6_ONLY,
    IPV4_PREFERRED,
    IPV6_PREFERRED;

}

