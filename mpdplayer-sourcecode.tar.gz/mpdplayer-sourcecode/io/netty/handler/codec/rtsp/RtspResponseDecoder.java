/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.codec.rtsp;

import io.netty.handler.codec.rtsp.RtspDecoder;

@Deprecated
public class RtspResponseDecoder
extends RtspDecoder {
}

