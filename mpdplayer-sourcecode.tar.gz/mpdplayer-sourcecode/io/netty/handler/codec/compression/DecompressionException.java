/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.codec.compression;

import io.netty.handler.codec.DecoderException;

public class DecompressionException
extends DecoderException {
    private static final long serialVersionUID = 3546272712208105199L;

    public DecompressionException() {
    }

    public DecompressionException(String message2, Throwable cause) {
        super(message2, cause);
    }

    public DecompressionException(String message2) {
        super(message2);
    }

    public DecompressionException(Throwable cause) {
        super(cause);
    }
}

