/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.codec;

public class CodecException
extends RuntimeException {
    private static final long serialVersionUID = -1464830400709348473L;

    public CodecException() {
    }

    public CodecException(String message2, Throwable cause) {
        super(message2, cause);
    }

    public CodecException(String message2) {
        super(message2);
    }

    public CodecException(Throwable cause) {
        super(cause);
    }
}

