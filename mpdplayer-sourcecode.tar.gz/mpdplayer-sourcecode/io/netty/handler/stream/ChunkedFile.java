/*
 * Decompiled with CFR 0.150.
 */
package io.netty.handler.stream;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.stream.ChunkedInput;
import io.netty.util.internal.ObjectUtil;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ChunkedFile
implements ChunkedInput<ByteBuf> {
    private final RandomAccessFile file;
    private final long startOffset;
    private final long endOffset;
    private final int chunkSize;
    private long offset;

    public ChunkedFile(File file2) throws IOException {
        this(file2, 8192);
    }

    public ChunkedFile(File file2, int chunkSize) throws IOException {
        this(new RandomAccessFile(file2, "r"), chunkSize);
    }

    public ChunkedFile(RandomAccessFile file2) throws IOException {
        this(file2, 8192);
    }

    public ChunkedFile(RandomAccessFile file2, int chunkSize) throws IOException {
        this(file2, 0L, file2.length(), chunkSize);
    }

    public ChunkedFile(RandomAccessFile file2, long offset, long length, int chunkSize) throws IOException {
        ObjectUtil.checkNotNull(file2, "file");
        ObjectUtil.checkPositiveOrZero(offset, "offset");
        ObjectUtil.checkPositiveOrZero(length, "length");
        ObjectUtil.checkPositive(chunkSize, "chunkSize");
        this.file = file2;
        this.offset = this.startOffset = offset;
        this.endOffset = offset + length;
        this.chunkSize = chunkSize;
        file2.seek(offset);
    }

    public long startOffset() {
        return this.startOffset;
    }

    public long endOffset() {
        return this.endOffset;
    }

    public long currentOffset() {
        return this.offset;
    }

    @Override
    public boolean isEndOfInput() throws Exception {
        return this.offset >= this.endOffset || !this.file.getChannel().isOpen();
    }

    @Override
    public void close() throws Exception {
        this.file.close();
    }

    @Override
    @Deprecated
    public ByteBuf readChunk(ChannelHandlerContext ctx2) throws Exception {
        return this.readChunk(ctx2.alloc());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public ByteBuf readChunk(ByteBufAllocator allocator) throws Exception {
        long offset = this.offset;
        if (offset >= this.endOffset) {
            return null;
        }
        int chunkSize = (int)Math.min((long)this.chunkSize, this.endOffset - offset);
        ByteBuf buf2 = allocator.heapBuffer(chunkSize);
        boolean release2 = true;
        try {
            this.file.readFully(buf2.array(), buf2.arrayOffset(), chunkSize);
            buf2.writerIndex(chunkSize);
            this.offset = offset + (long)chunkSize;
            release2 = false;
            ByteBuf byteBuf = buf2;
            return byteBuf;
        }
        finally {
            if (release2) {
                buf2.release();
            }
        }
    }

    @Override
    public long length() {
        return this.endOffset - this.startOffset;
    }

    @Override
    public long progress() {
        return this.offset - this.startOffset;
    }
}

