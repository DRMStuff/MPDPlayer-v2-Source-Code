/*
 * Decompiled with CFR 0.150.
 */
package io.netty.buffer.search;

import io.netty.buffer.search.SearchProcessor;

public interface SearchProcessorFactory {
    public SearchProcessor newSearchProcessor();
}

