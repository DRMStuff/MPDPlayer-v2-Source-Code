/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.util.cio;

import io.ktor.util.cio.FileChannelsKt;
import io.ktor.utils.io.ByteReadChannel;
import java.io.File;
import java.nio.file.Path;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\u001a\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004\u00a8\u0006\u0006"}, d2={"readChannel", "Lio/ktor/utils/io/ByteReadChannel;", "Ljava/nio/file/Path;", "start", "", "endInclusive", "ktor-utils"})
public final class FileChannelsAtNioPathKt {
    @NotNull
    public static final ByteReadChannel readChannel(@NotNull Path $this$readChannel, long start2, long endInclusive) {
        Intrinsics.checkNotNullParameter($this$readChannel, "<this>");
        File file2 = $this$readChannel.toFile();
        Intrinsics.checkNotNullExpressionValue(file2, "toFile()");
        return FileChannelsKt.readChannel$default(file2, start2, endInclusive, null, 4, null);
    }

    @NotNull
    public static final ByteReadChannel readChannel(@NotNull Path $this$readChannel) {
        Intrinsics.checkNotNullParameter($this$readChannel, "<this>");
        File file2 = $this$readChannel.toFile();
        Intrinsics.checkNotNullExpressionValue(file2, "toFile()");
        return FileChannelsKt.readChannel$default(file2, 0L, 0L, null, 7, null);
    }
}

