/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.websocket;

import kotlin.Metadata;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000* \b\u0002\u0010\u0000\"\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00020\u00012\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00020\u0001\u00a8\u0006\u0003"}, d2={"ExtensionInstaller", "Lkotlin/Function0;", "Lio/ktor/websocket/WebSocketExtension;", "ktor-websockets"})
public final class WebSocketExtensionKt {
}

