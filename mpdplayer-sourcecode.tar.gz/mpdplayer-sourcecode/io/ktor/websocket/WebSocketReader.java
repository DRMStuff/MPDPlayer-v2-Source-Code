/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.websocket;

import io.ktor.util.NIOKt;
import io.ktor.util.cio.ByteBufferPoolKt;
import io.ktor.utils.io.ByteReadChannel;
import io.ktor.utils.io.pool.ObjectPool;
import io.ktor.websocket.Frame;
import io.ktor.websocket.FrameParser;
import io.ktor.websocket.FrameTooBigException;
import io.ktor.websocket.FrameType;
import io.ktor.websocket.SimpleFrameCollector;
import io.ktor.websocket.WebSocketReader;
import java.nio.ByteBuffer;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.channels.ChannelKt;
import kotlinx.coroutines.channels.ReceiveChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001*B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t\u00a2\u0006\u0002\u0010\u000bJ\u0011\u0010#\u001a\u00020$H\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010%J\u0019\u0010&\u001a\u00020$2\u0006\u0010'\u001a\u00020\nH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(J\u0019\u0010)\u001a\u00020$2\u0006\u0010'\u001a\u00020\nH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u00138F\u00a2\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00140\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\u00020\u001eX\u0082\u0004\u00a2\u0006\b\n\u0000\u0012\u0004\b\u001f\u0010 R\u000e\u0010!\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006+"}, d2={"Lio/ktor/websocket/WebSocketReader;", "Lkotlinx/coroutines/CoroutineScope;", "byteChannel", "Lio/ktor/utils/io/ByteReadChannel;", "coroutineContext", "Lkotlin/coroutines/CoroutineContext;", "maxFrameSize", "", "pool", "Lio/ktor/utils/io/pool/ObjectPool;", "Ljava/nio/ByteBuffer;", "(Lio/ktor/utils/io/ByteReadChannel;Lkotlin/coroutines/CoroutineContext;JLio/ktor/utils/io/pool/ObjectPool;)V", "collector", "Lio/ktor/websocket/SimpleFrameCollector;", "getCoroutineContext", "()Lkotlin/coroutines/CoroutineContext;", "frameParser", "Lio/ktor/websocket/FrameParser;", "incoming", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Lio/ktor/websocket/Frame;", "getIncoming", "()Lkotlinx/coroutines/channels/ReceiveChannel;", "getMaxFrameSize", "()J", "setMaxFrameSize", "(J)V", "queue", "Lkotlinx/coroutines/channels/Channel;", "readerJob", "Lkotlinx/coroutines/Job;", "getReaderJob$annotations", "()V", "state", "Lio/ktor/websocket/WebSocketReader$State;", "handleFrameIfProduced", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "parseLoop", "buffer", "(Ljava/nio/ByteBuffer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readLoop", "State", "ktor-websockets"})
public final class WebSocketReader
implements CoroutineScope {
    @NotNull
    private final ByteReadChannel byteChannel;
    @NotNull
    private final CoroutineContext coroutineContext;
    private long maxFrameSize;
    @NotNull
    private State state;
    @NotNull
    private final FrameParser frameParser;
    @NotNull
    private final SimpleFrameCollector collector;
    @NotNull
    private final Channel<Frame> queue;
    @NotNull
    private final Job readerJob;

    public WebSocketReader(@NotNull ByteReadChannel byteChannel, @NotNull CoroutineContext coroutineContext2, long maxFrameSize, @NotNull ObjectPool<ByteBuffer> pool) {
        Intrinsics.checkNotNullParameter(byteChannel, "byteChannel");
        Intrinsics.checkNotNullParameter(coroutineContext2, "coroutineContext");
        Intrinsics.checkNotNullParameter(pool, "pool");
        this.byteChannel = byteChannel;
        this.coroutineContext = coroutineContext2;
        this.maxFrameSize = maxFrameSize;
        this.state = State.HEADER;
        this.frameParser = new FrameParser();
        this.collector = new SimpleFrameCollector();
        this.queue = ChannelKt.Channel$default(8, null, null, 6, null);
        this.readerJob = BuildersKt.launch(this, new CoroutineName("ws-reader"), CoroutineStart.ATOMIC, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(pool, this, null){
            Object L$0;
            int label;
            final /* synthetic */ ObjectPool<ByteBuffer> $pool;
            final /* synthetic */ WebSocketReader this$0;
            {
                this.$pool = $pool;
                this.this$0 = $receiver;
                super(2, $completion);
            }

            /*
             * Exception decompiling
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                /*
                 * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                 * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:406)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:481)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:588)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner.dumpWithArgs(ClassFileDumperAnonymousInner.java:87)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner.dumpInner(ConstructorInvokationAnonymousInner.java:75)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.CastExpression.dumpInner(CastExpression.java:95)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation.dumpInner(StaticFunctionInvokation.java:116)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment.dump(StructuredAssignment.java:61)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.dump(Block.java:560)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.dump(AttributeCode.java:135)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:617)
                 * org.benf.cfr.reader.entities.classfilehelpers.AbstractClassFileDumper.dumpMethods(AbstractClassFileDumper.java:193)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal.dump(ClassFileDumperNormal.java:77)
                 * org.benf.cfr.reader.entities.ClassFile.dump(ClassFile.java:1138)
                 * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:932)
                 * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
                 * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
                 * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
                 * org.benf.cfr.reader.Main.main(Main.java:49)
                 */
                throw new IllegalStateException(Decompilation failed);
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    public /* synthetic */ WebSocketReader(ByteReadChannel byteReadChannel, CoroutineContext coroutineContext2, long l, ObjectPool objectPool, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 8) != 0) {
            objectPool = ByteBufferPoolKt.getKtorDefaultPool();
        }
        this(byteReadChannel, coroutineContext2, l, objectPool);
    }

    @Override
    @NotNull
    public CoroutineContext getCoroutineContext() {
        return this.coroutineContext;
    }

    public final long getMaxFrameSize() {
        return this.maxFrameSize;
    }

    public final void setMaxFrameSize(long l) {
        this.maxFrameSize = l;
    }

    private static /* synthetic */ void getReaderJob$annotations() {
    }

    @NotNull
    public final ReceiveChannel<Frame> getIncoming() {
        return this.queue;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final Object readLoop(ByteBuffer var1_1, Continuation<? super Unit> var2_2) {
        if (!(var2_2 instanceof readLoop.1)) ** GOTO lbl-1000
        var4_3 = var2_2;
        if ((var4_3.label & -2147483648) != 0) {
            var4_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(this, var2_2){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                final /* synthetic */ WebSocketReader this$0;
                int label;
                {
                    this.this$0 = this$0;
                    super($completion);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return WebSocketReader.access$readLoop(this.this$0, null, this);
                }
            };
        }
        $result = $continuation.result;
        var5_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                buffer.clear();
                ** GOTO lbl40
            }
            case 1: {
                buffer = (ByteBuffer)$continuation.L$1;
                this = (WebSocketReader)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
                while (true) {
                    if (((Number)v0).intValue() == -1) {
                        this.state = State.CLOSED;
                        return Unit.INSTANCE;
                    }
                    buffer.flip();
                    $continuation.L$0 = this;
                    $continuation.L$1 = buffer;
                    $continuation.label = 2;
                    v1 = this.parseLoop(buffer, $continuation);
                    if (v1 == var5_5) {
                        return var5_5;
                    }
                    ** GOTO lbl38
                    break;
                }
            }
            case 2: {
                buffer = (ByteBuffer)$continuation.L$1;
                this = (WebSocketReader)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v1 = $result;
lbl38:
                // 2 sources

                buffer.compact();
lbl40:
                // 2 sources

                if (this.state == State.CLOSED) return Unit.INSTANCE;
                $continuation.L$0 = this;
                $continuation.L$1 = buffer;
                $continuation.label = 1;
                if ((v0 = this.byteChannel.readAvailable(buffer, (Continuation<? super Integer>)$continuation)) != var5_5) ** continue;
                return var5_5;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final Object parseLoop(ByteBuffer var1_1, Continuation<? super Unit> var2_2) {
        if (!(var2_2 instanceof parseLoop.1)) ** GOTO lbl-1000
        var4_3 = var2_2;
        if ((var4_3.label & -2147483648) != 0) {
            var4_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(this, var2_2){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                final /* synthetic */ WebSocketReader this$0;
                int label;
                {
                    this.this$0 = this$0;
                    super($completion);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return WebSocketReader.access$parseLoop(this.this$0, null, this);
                }
            };
        }
        $result = $continuation.result;
        var5_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                break;
            }
            case 1: {
                buffer = (ByteBuffer)$continuation.L$1;
                this = (WebSocketReader)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
                break;
            }
            case 2: {
                buffer = (ByteBuffer)$continuation.L$1;
                this = (WebSocketReader)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v1 = $result;
                break;
            }
            default: {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
        block10: while (buffer.hasRemaining() != false) {
            switch (WhenMappings.$EnumSwitchMapping$0[this.state.ordinal()]) {
                case 1: {
                    this.frameParser.frame(buffer);
                    if (this.frameParser.getBodyReady() == false) return Unit.INSTANCE;
                    this.state = State.BODY;
                    if (this.frameParser.getLength() > 0x7FFFFFFFL) throw new FrameTooBigException(this.frameParser.getLength());
                    if (this.frameParser.getLength() > this.maxFrameSize) {
                        throw new FrameTooBigException(this.frameParser.getLength());
                    }
                    this.collector.start((int)this.frameParser.getLength(), buffer);
                    $continuation.L$0 = this;
                    $continuation.L$1 = buffer;
                    $continuation.label = 1;
                    v0 = this.handleFrameIfProduced($continuation);
                    if (v0 != var5_5) continue block10;
                    return var5_5;
                }
                case 2: {
                    this.collector.handle(buffer);
                    $continuation.L$0 = this;
                    $continuation.L$1 = buffer;
                    $continuation.label = 2;
                    v1 = this.handleFrameIfProduced($continuation);
                    if (v1 != var5_5) continue block10;
                    return var5_5;
                }
                case 3: {
                    return Unit.INSTANCE;
                }
            }
        }
        return Unit.INSTANCE;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private final Object handleFrameIfProduced(Continuation<? super Unit> var1_1) {
        if (!(var1_1 instanceof handleFrameIfProduced.1)) ** GOTO lbl-1000
        var6_2 = var1_1;
        if ((var6_2.label & -2147483648) != 0) {
            var6_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(this, var1_1){
                Object L$0;
                /* synthetic */ Object result;
                final /* synthetic */ WebSocketReader this$0;
                int label;
                {
                    this.this$0 = this$0;
                    super($completion);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return WebSocketReader.access$handleFrameIfProduced(this.this$0, this);
                }
            };
        }
        $result = $continuation.result;
        var7_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                if (this.collector.getHasRemaining() != false) return Unit.INSTANCE;
                this.state = this.frameParser.getFrameType() == FrameType.CLOSE ? State.CLOSED : State.HEADER;
                $this$handleFrameIfProduced_u24lambda_u2d0 = this.frameParser;
                $i$a$-with-WebSocketReader$handleFrameIfProduced$frame$1 = false;
                frame = Frame.Companion.byType($this$handleFrameIfProduced_u24lambda_u2d0.getFin(), $this$handleFrameIfProduced_u24lambda_u2d0.getFrameType(), NIOKt.moveToByteArray(this.collector.take($this$handleFrameIfProduced_u24lambda_u2d0.getMaskKey())), $this$handleFrameIfProduced_u24lambda_u2d0.getRsv1(), $this$handleFrameIfProduced_u24lambda_u2d0.getRsv2(), $this$handleFrameIfProduced_u24lambda_u2d0.getRsv3());
                $continuation.L$0 = this;
                $continuation.label = 1;
                v0 = this.queue.send(frame, $continuation);
                if (v0 == var7_4) {
                    return var7_4;
                }
                ** GOTO lbl28
            }
            case 1: {
                this = (WebSocketReader)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl28:
                // 2 sources

                this.frameParser.bodyComplete();
                return Unit.INSTANCE;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    public static final /* synthetic */ Object access$readLoop(WebSocketReader $this, ByteBuffer buffer, Continuation $completion) {
        return $this.readLoop(buffer, $completion);
    }

    public static final /* synthetic */ Object access$parseLoop(WebSocketReader $this, ByteBuffer buffer, Continuation $completion) {
        return $this.parseLoop(buffer, $completion);
    }

    public static final /* synthetic */ Object access$handleFrameIfProduced(WebSocketReader $this, Continuation $completion) {
        return $this.handleFrameIfProduced($completion);
    }

    public static final /* synthetic */ Channel access$getQueue$p(WebSocketReader $this) {
        return $this.queue;
    }

    @Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005\u00a8\u0006\u0006"}, d2={"Lio/ktor/websocket/WebSocketReader$State;", "", "(Ljava/lang/String;I)V", "HEADER", "BODY", "CLOSED", "ktor-websockets"})
    private static final class State
    extends Enum<State> {
        public static final /* enum */ State HEADER = new State();
        public static final /* enum */ State BODY = new State();
        public static final /* enum */ State CLOSED = new State();
        private static final /* synthetic */ State[] $VALUES;

        public static State[] values() {
            return (State[])$VALUES.clone();
        }

        public static State valueOf(String value) {
            return Enum.valueOf(State.class, value);
        }

        static {
            $VALUES = arrstate = new State[]{State.HEADER, State.BODY, State.CLOSED};
        }
    }

    @Metadata(mv={1, 6, 0}, k=3, xi=48)
    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] arrn = new int[State.values().length];
            arrn[State.HEADER.ordinal()] = 1;
            arrn[State.BODY.ordinal()] = 2;
            arrn[State.CLOSED.ordinal()] = 3;
            $EnumSwitchMapping$0 = arrn;
        }
    }
}

