/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.websocket;

import io.ktor.util.cio.ByteBufferPoolKt;
import io.ktor.utils.io.ByteWriteChannel;
import io.ktor.utils.io.pool.ObjectPool;
import io.ktor.websocket.Frame;
import io.ktor.websocket.Serializer;
import io.ktor.websocket.WebSocketWriter;
import java.nio.ByteBuffer;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CompletableJob;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobKt;
import kotlinx.coroutines.channels.Channel;
import kotlinx.coroutines.channels.ChannelKt;
import kotlinx.coroutines.channels.ChannelResult;
import kotlinx.coroutines.channels.ClosedSendChannelException;
import kotlinx.coroutines.channels.SendChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000e\u0018\u00002\u00020\u0001:\u00010B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t\u00a2\u0006\u0002\u0010\u000bJ\b\u0010\"\u001a\u00020#H\u0007J\b\u0010$\u001a\u00020#H\u0002J!\u0010%\u001a\u00020\u00072\u0006\u0010&\u001a\u00020\u00142\u0006\u0010'\u001a\u00020\nH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(J\u0011\u0010)\u001a\u00020#H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010*J\u0019\u0010+\u001a\u00020#2\u0006\u0010,\u001a\u00020\u0014H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010-J\u0019\u0010.\u001a\u00020#2\u0006\u0010'\u001a\u00020\nH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010/R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u00138F\u00a2\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0014\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\u00020\u001fX\u0082\u0004\u00a2\u0006\b\n\u0000\u0012\u0004\b \u0010!\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u00061"}, d2={"Lio/ktor/websocket/WebSocketWriter;", "Lkotlinx/coroutines/CoroutineScope;", "writeChannel", "Lio/ktor/utils/io/ByteWriteChannel;", "coroutineContext", "Lkotlin/coroutines/CoroutineContext;", "masking", "", "pool", "Lio/ktor/utils/io/pool/ObjectPool;", "Ljava/nio/ByteBuffer;", "(Lio/ktor/utils/io/ByteWriteChannel;Lkotlin/coroutines/CoroutineContext;ZLio/ktor/utils/io/pool/ObjectPool;)V", "getCoroutineContext", "()Lkotlin/coroutines/CoroutineContext;", "getMasking", "()Z", "setMasking", "(Z)V", "outgoing", "Lkotlinx/coroutines/channels/SendChannel;", "Lio/ktor/websocket/Frame;", "getOutgoing", "()Lkotlinx/coroutines/channels/SendChannel;", "getPool", "()Lio/ktor/utils/io/pool/ObjectPool;", "queue", "Lkotlinx/coroutines/channels/Channel;", "", "serializer", "Lio/ktor/websocket/Serializer;", "writeLoopJob", "Lkotlinx/coroutines/Job;", "getWriteLoopJob$annotations", "()V", "close", "", "drainQueueAndDiscard", "drainQueueAndSerialize", "firstMsg", "buffer", "(Lio/ktor/websocket/Frame;Ljava/nio/ByteBuffer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "flush", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "send", "frame", "(Lio/ktor/websocket/Frame;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "writeLoop", "(Ljava/nio/ByteBuffer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "FlushRequest", "ktor-websockets"})
public final class WebSocketWriter
implements CoroutineScope {
    @NotNull
    private final ByteWriteChannel writeChannel;
    @NotNull
    private final CoroutineContext coroutineContext;
    private boolean masking;
    @NotNull
    private final ObjectPool<ByteBuffer> pool;
    @NotNull
    private final Channel<Object> queue;
    @NotNull
    private final Serializer serializer;
    @NotNull
    private final Job writeLoopJob;

    public WebSocketWriter(@NotNull ByteWriteChannel writeChannel2, @NotNull CoroutineContext coroutineContext2, boolean masking, @NotNull ObjectPool<ByteBuffer> pool) {
        Intrinsics.checkNotNullParameter(writeChannel2, "writeChannel");
        Intrinsics.checkNotNullParameter(coroutineContext2, "coroutineContext");
        Intrinsics.checkNotNullParameter(pool, "pool");
        this.writeChannel = writeChannel2;
        this.coroutineContext = coroutineContext2;
        this.masking = masking;
        this.pool = pool;
        this.queue = ChannelKt.Channel$default(8, null, null, 6, null);
        this.serializer = new Serializer();
        this.writeLoopJob = BuildersKt.launch(this, new CoroutineName("ws-writer"), CoroutineStart.ATOMIC, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(this, null){
            Object L$0;
            Object L$1;
            int label;
            final /* synthetic */ WebSocketWriter this$0;
            {
                this.this$0 = $receiver;
                super(2, $completion);
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var8_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        var2_3 = this.this$0.getPool();
                        var3_4 = this.this$0;
                        $i$f$useInstance = false;
                        instance$iv = $this$useInstance$iv.borrow();
                        it = (ByteBuffer)instance$iv;
                        $i$a$-useInstance-WebSocketWriter$writeLoopJob$1$1 = false;
                        this.L$0 = $this$useInstance$iv;
                        this.L$1 = instance$iv;
                        this.label = 1;
                        v0 = WebSocketWriter.access$writeLoop(var3_4, it, this);
                        ** if (v0 != var8_2) goto lbl19
lbl18:
                        // 1 sources

                        return var8_2;
lbl19:
                        // 1 sources

                        ** GOTO lbl29
                    }
                    case 1: {
                        $i$f$useInstance = false;
                        $i$a$-useInstance-WebSocketWriter$writeLoopJob$1$1 = false;
                        instance$iv = this.L$1;
                        $this$useInstance$iv = (ObjectPool)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
lbl29:
                        // 2 sources

                        var6_8 = Unit.INSTANCE;
                        return Unit.INSTANCE;
                    }
                }
                catch (Throwable var6_9) {
                    throw var6_9;
                }
                finally {
                    $this$useInstance$iv.recycle(instance$iv);
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    public /* synthetic */ WebSocketWriter(ByteWriteChannel byteWriteChannel, CoroutineContext coroutineContext2, boolean bl, ObjectPool objectPool, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 4) != 0) {
            bl = false;
        }
        if ((n & 8) != 0) {
            objectPool = ByteBufferPoolKt.getKtorDefaultPool();
        }
        this(byteWriteChannel, coroutineContext2, bl, objectPool);
    }

    @Override
    @NotNull
    public CoroutineContext getCoroutineContext() {
        return this.coroutineContext;
    }

    public final boolean getMasking() {
        return this.masking;
    }

    public final void setMasking(boolean bl) {
        this.masking = bl;
    }

    @NotNull
    public final ObjectPool<ByteBuffer> getPool() {
        return this.pool;
    }

    @NotNull
    public final SendChannel<Frame> getOutgoing() {
        return this.queue;
    }

    private static /* synthetic */ void getWriteLoopJob$annotations() {
    }

    /*
     * Exception decompiling
     */
    private final Object writeLoop(ByteBuffer var1_1, Continuation<? super Unit> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 0[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    private final void drainQueueAndDiscard() {
        SendChannel.DefaultImpls.close$default(this.queue, null, 1, null);
        try {
            while (ChannelResult.getOrNull-impl(this.queue.tryReceive-PtdJZtk()) != null) {
                Object message2;
                Object t = message2;
                if (t instanceof Frame.Close || (t instanceof Frame.Ping ? true : t instanceof Frame.Pong)) continue;
                if (t instanceof FlushRequest) {
                    ((FlushRequest)message2).complete();
                    continue;
                }
                if (t instanceof Frame.Text ? true : t instanceof Frame.Binary) continue;
                throw new IllegalArgumentException("unknown message " + message2);
            }
        }
        catch (CancellationException cancellationException) {
            // empty catch block
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final Object drainQueueAndSerialize(Frame var1_1, ByteBuffer var2_2, Continuation<? super Boolean> var3_3) {
        if (!(var3_3 instanceof drainQueueAndSerialize.1)) ** GOTO lbl-1000
        var11_4 = var3_3;
        if ((var11_4.label & -2147483648) != 0) {
            var11_4.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(this, var3_3){
                Object L$0;
                Object L$1;
                Object L$2;
                int I$0;
                /* synthetic */ Object result;
                final /* synthetic */ WebSocketWriter this$0;
                int label;
                {
                    this.this$0 = this$0;
                    super($completion);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return WebSocketWriter.access$drainQueueAndSerialize(this.this$0, null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var12_6 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        block0 : switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                flush = new Ref.ObjectRef();
                this.serializer.enqueue((Frame)firstMsg);
                closeSent = firstMsg instanceof Frame.Close;
lbl16:
                // 2 sources

                while (true) {
                    if (flush.element == null && closeSent == 0 && this.serializer.getRemainingCapacity() > 0 && ChannelResult.getOrNull-impl(this.queue.tryReceive-PtdJZtk()) != null) {
                        var7_10 = message;
                        if (var7_10 instanceof FlushRequest) {
                            flush.element = message;
                            continue;
                        }
                        if (var7_10 instanceof Frame.Close) {
                            this.serializer.enqueue((Frame)message);
                            closeSent = 1;
                            continue;
                        }
                        if (!(var7_10 instanceof Frame)) throw new IllegalArgumentException("unknown message " + message);
                        this.serializer.enqueue((Frame)message);
                        continue;
                    }
                    if (closeSent != 0) {
                        SendChannel.DefaultImpls.close$default(this.queue, null, 1, null);
                    }
                    if (!this.serializer.getHasOutstandingBytes() && buffer.position() == 0) break block0;
                    this.serializer.setMasking(this.masking);
                    this.serializer.serialize(buffer);
                    buffer.flip();
                    while (true) {
                        $continuation.L$0 = this;
                        $continuation.L$1 = buffer;
                        $continuation.L$2 = flush;
                        $continuation.I$0 = closeSent;
                        $continuation.label = 1;
                        v0 = this.writeChannel.writeFully(buffer, (Continuation<? super Unit>)$continuation);
                        if (v0 == var12_6) {
                            return var12_6;
                        }
                        ** GOTO lbl54
                        break;
                    }
                    break;
                }
            }
            case 1: {
                closeSent = $continuation.I$0;
                flush = (Ref.ObjectRef)$continuation.L$2;
                buffer = (ByteBuffer)$continuation.L$1;
                this = (WebSocketWriter)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl54:
                // 2 sources

                if (!this.serializer.getHasOutstandingBytes() && !buffer.hasRemaining()) {
                    if ((FlushRequest)flush.element != null) {
                        $i$a$-let-WebSocketWriter$drainQueueAndSerialize$2 = false;
                        this.writeChannel.flush();
                        it.complete();
                        flush.element = null;
                    }
                }
                if ((flush.element != null || closeSent != 0) && buffer.hasRemaining()) ** continue;
                buffer.compact();
                ** continue;
            }
        }
        this.writeChannel.flush();
        v1 = (FlushRequest)flush.element;
        if (v1 == null) return Boxing.boxBoolean(closeSent != 0);
        Boxing.boxBoolean(v1.complete());
        return Boxing.boxBoolean(closeSent != 0);
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Nullable
    public final Object send(@NotNull Frame frame, @NotNull Continuation<? super Unit> $completion) {
        Object object = this.queue.send(frame, $completion);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return object;
        }
        return Unit.INSTANCE;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Nullable
    public final Object flush(@NotNull Continuation<? super Unit> var1_1) {
        if (!(var1_1 instanceof flush.1)) ** GOTO lbl-1000
        var7_2 = var1_1;
        if ((var7_2.label & -2147483648) != 0) {
            var7_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(this, var1_1){
                Object L$0;
                Object L$1;
                Object L$2;
                /* synthetic */ Object result;
                final /* synthetic */ WebSocketWriter this$0;
                int label;
                {
                    this.this$0 = this$0;
                    super($completion);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return this.this$0.flush(this);
                }
            };
        }
        $result = $continuation.result;
        var8_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                it = var2_5 = new FlushRequest((Job)this.getCoroutineContext().get(Job.Key));
                $i$a$-also-WebSocketWriter$flush$2 = false;
                $continuation.L$0 = this;
                $continuation.L$1 = var2_5;
                $continuation.L$2 = it;
                $continuation.label = 1;
                v0 = this.queue.send(it, $continuation);
                ** if (v0 != var8_4) goto lbl23
lbl22:
                // 1 sources

                return var8_4;
lbl23:
                // 1 sources

                ** GOTO lbl55
            }
            case 1: {
                $i$a$-also-WebSocketWriter$flush$2 = false;
                it = (FlushRequest)$continuation.L$2;
                var2_5 = (FlushRequest)$continuation.L$1;
                this = (WebSocketWriter)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
                    ** break;
                }
                catch (ClosedSendChannelException var5_10) {
                    it.complete();
                    $continuation.L$0 = var2_5;
                    $continuation.L$1 = null;
                    $continuation.L$2 = null;
                    $continuation.label = 2;
                    v1 = this.writeLoopJob.join($continuation);
                    if (v1 == var8_4) {
                        return var8_4;
                    }
                    ** GOTO lbl55
                }
            }
            case 2: {
                $i$a$-also-WebSocketWriter$flush$2 = false;
                var2_5 = (FlushRequest)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v1 = $result;
                ** break;
            }
            catch (Throwable sendFailure) {
                it.complete();
                throw sendFailure;
            }
lbl55:
            // 4 sources

            $continuation.L$0 = null;
            $continuation.L$1 = null;
            $continuation.L$2 = null;
            $continuation.label = 3;
            v2 = var2_5.await($continuation);
            v3 = v2;
            if (v2 != var8_4) return Unit.INSTANCE;
            return var8_4;
            case 3: {
                ResultKt.throwOnFailure($result);
                v3 = $result;
                return Unit.INSTANCE;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="Will be removed", level=DeprecationLevel.ERROR)
    public final void close() {
        SendChannel.DefaultImpls.close$default(this.queue, null, 1, null);
    }

    public static final /* synthetic */ Object access$writeLoop(WebSocketWriter $this, ByteBuffer buffer, Continuation $completion) {
        return $this.writeLoop(buffer, $completion);
    }

    public static final /* synthetic */ Object access$drainQueueAndSerialize(WebSocketWriter $this, Frame firstMsg, ByteBuffer buffer, Continuation $completion) {
        return $this.drainQueueAndSerialize(firstMsg, buffer, $completion);
    }

    @Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J\u0011\u0010\u0007\u001a\u00020\bH\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\tJ\u0006\u0010\n\u001a\u00020\u000bR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\f"}, d2={"Lio/ktor/websocket/WebSocketWriter$FlushRequest;", "", "parent", "Lkotlinx/coroutines/Job;", "(Lkotlinx/coroutines/Job;)V", "done", "Lkotlinx/coroutines/CompletableJob;", "await", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "complete", "", "ktor-websockets"})
    private static final class FlushRequest {
        @NotNull
        private final CompletableJob done;

        public FlushRequest(@Nullable Job parent) {
            this.done = JobKt.Job(parent);
        }

        public final boolean complete() {
            return this.done.complete();
        }

        @Nullable
        public final Object await(@NotNull Continuation<? super Unit> $completion) {
            Object object = this.done.join($completion);
            if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                return object;
            }
            return Unit.INSTANCE;
        }
    }
}

