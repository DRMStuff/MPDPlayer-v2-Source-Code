/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.engine;

import io.ktor.http.BadContentTypeFormatException;
import io.ktor.http.ContentType;
import io.ktor.http.HttpHeaders;
import io.ktor.http.Parameters;
import io.ktor.http.ParametersBuilder;
import io.ktor.http.ParametersKt;
import io.ktor.http.QueryKt;
import io.ktor.http.content.MultipartKt;
import io.ktor.http.content.OutgoingContent;
import io.ktor.http.content.PartData;
import io.ktor.server.application.ApplicationCall;
import io.ktor.server.application.ApplicationCallKt;
import io.ktor.server.engine.DefaultTransformJvmKt;
import io.ktor.server.engine.DefaultTransformKt;
import io.ktor.server.plugins.BadRequestException;
import io.ktor.server.request.ApplicationReceivePipeline;
import io.ktor.server.request.ApplicationRequestPropertiesKt;
import io.ktor.server.response.ApplicationSendPipeline;
import io.ktor.util.cio.ReadersKt;
import io.ktor.util.pipeline.PipelineContext;
import io.ktor.util.pipeline.PipelinePhase;
import io.ktor.utils.io.ByteReadChannel;
import io.ktor.utils.io.core.ByteReadPacket;
import io.ktor.utils.io.core.Input;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u00006\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a-\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u00012\u0006\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00010\u0005H\u0080\b\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0006\u001a\n\u0010\u0007\u001a\u00020\b*\u00020\t\u001a\n\u0010\u0007\u001a\u00020\b*\u00020\n\u001a!\u0010\u000b\u001a\u00020\f*\u00020\r2\n\u0010\u000e\u001a\u00060\u000fj\u0002`\u0010H\u0080@\u00f8\u0001\u0001\u00a2\u0006\u0002\u0010\u0011\u0082\u0002\u000b\n\u0005\b\u009920\u0001\n\u0002\b\u0019\u00a8\u0006\u0012"}, d2={"withContentType", "R", "call", "Lio/ktor/server/application/ApplicationCall;", "block", "Lkotlin/Function0;", "(Lio/ktor/server/application/ApplicationCall;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "installDefaultTransformations", "", "Lio/ktor/server/request/ApplicationReceivePipeline;", "Lio/ktor/server/response/ApplicationSendPipeline;", "readText", "", "Lio/ktor/utils/io/ByteReadChannel;", "charset", "Ljava/nio/charset/Charset;", "Lio/ktor/utils/io/charsets/Charset;", "(Lio/ktor/utils/io/ByteReadChannel;Ljava/nio/charset/Charset;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "ktor-server-host-common"})
public final class DefaultTransformKt {
    public static final void installDefaultTransformations(@NotNull ApplicationSendPipeline $this$installDefaultTransformations) {
        Intrinsics.checkNotNullParameter($this$installDefaultTransformations, "<this>");
        $this$installDefaultTransformations.intercept(ApplicationSendPipeline.Phases.getRender(), (Function3)new Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object>(null){
            int label;
            private /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;

            /*
             * WARNING - void declaration
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        PipelineContext $this$intercept = (PipelineContext)this.L$0;
                        Object value = this.L$1;
                        PipelineContext $this$call$iv = $this$intercept;
                        boolean $i$f$getCall = false;
                        OutgoingContent transformed2 = io.ktor.server.http.content.DefaultTransformKt.transformDefaultContent((ApplicationCall)$this$call$iv.getContext(), value);
                        if (transformed2 == null) return Unit.INSTANCE;
                        this.L$0 = null;
                        this.label = 1;
                        Object object3 = $this$intercept.proceedWith(transformed2, this);
                        if (object3 != object2) return Unit.INSTANCE;
                        return object2;
                    }
                    case 1: {
                        void $result;
                        ResultKt.throwOnFailure($result);
                        Object object3 = $result;
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @Nullable
            public final Object invoke(@NotNull PipelineContext<Object, ApplicationCall> p1, @NotNull Object p2, @Nullable Continuation<? super Unit> p3) {
                Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object> function3 = new /* invalid duplicate definition of identical inner class */;
                function3.L$0 = p1;
                function3.L$1 = p2;
                return function3.invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    public static final void installDefaultTransformations(@NotNull ApplicationReceivePipeline $this$installDefaultTransformations) {
        Intrinsics.checkNotNullParameter($this$installDefaultTransformations, "<this>");
        $this$installDefaultTransformations.intercept(ApplicationReceivePipeline.Phases.getTransform(), (Function3)new Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object>(null){
            int label;
            private /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var14_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$intercept = (PipelineContext)this.L$0;
                        body = this.L$1;
                        v0 = body instanceof ByteReadChannel != false ? (ByteReadChannel)body : null;
                        if (v0 == null) {
                            return Unit.INSTANCE;
                        }
                        channel = v0;
                        $this$call$iv = $this$intercept;
                        $i$f$getCall = false;
                        var6_9 = ApplicationCallKt.getReceiveType((ApplicationCall)$this$call$iv.getContext()).getType();
                        if (!Intrinsics.areEqual(var6_9, Reflection.getOrCreateKotlinClass(ByteReadChannel.class))) ** GOTO lbl17
                        v1 = null;
                        ** GOTO lbl97
lbl17:
                        // 1 sources

                        if (!Intrinsics.areEqual(var6_9, Reflection.getOrCreateKotlinClass(byte[].class))) ** GOTO lbl29
                        this.L$0 = $this$intercept;
                        this.label = 1;
                        v1 = ReadersKt.toByteArray$default(channel, 0, this, 1, null);
                        if (v1 == var14_2) {
                            return var14_2;
                        }
                        ** GOTO lbl97
                    }
                    case 1: {
                        $this$intercept = (PipelineContext)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
                        ** GOTO lbl97
                    }
lbl29:
                    // 1 sources

                    if (!Intrinsics.areEqual(var6_9, Reflection.getOrCreateKotlinClass(Parameters.class))) ** GOTO lbl87
                    $this$call$iv = $this$intercept;
                    $i$f$getCall = false;
                    call$iv = (ApplicationCall)$this$call$iv.getContext();
                    $i$f$withContentType = false;
                    try {
                        $i$a$-withContentType-DefaultTransformKt$installDefaultTransformations$2$transformed$contentType$1 = false;
                        $this$call$iv = $this$intercept;
                        $i$f$getCall = false;
                        var13_18 = ApplicationRequestPropertiesKt.contentType(((ApplicationCall)$this$call$iv.getContext()).getRequest());
                    }
                    catch (BadContentTypeFormatException parseFailure$iv) {
                        throw new BadRequestException("Illegal Content-Type header format: " + call$iv.getRequest().getHeaders().get(HttpHeaders.INSTANCE.getContentType()), parseFailure$iv);
                    }
                    contentType = var13_18;
                    if (!contentType.match(ContentType.Application.INSTANCE.getFormUrlEncoded())) ** GOTO lbl64
                    $this$call$iv = $this$intercept;
                    $i$f$getCall = false;
                    v2 = ApplicationRequestPropertiesKt.contentCharset(((ApplicationCall)$this$call$iv.getContext()).getRequest());
                    if (v2 == null) {
                        v2 = Charsets.UTF_8;
                    }
                    this.L$0 = $this$intercept;
                    this.label = 2;
                    v3 = DefaultTransformKt.readText(channel, v2, this);
                    if (v3 == var14_2) {
                        return var14_2;
                    }
                    ** GOTO lbl61
                    case 2: {
                        $this$intercept = (PipelineContext)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
lbl61:
                        // 2 sources

                        string = (String)v3;
                        v1 = QueryKt.parseQueryString$default(string, 0, 0, false, 14, null);
                        ** GOTO lbl97
                    }
lbl64:
                    // 1 sources

                    if (!contentType.match(ContentType.MultiPart.INSTANCE.getFormData())) ** GOTO lbl85
                    $i$f$build = false;
                    $this$invokeSuspend_u24lambda_u2d1 = var10_14 = ParametersKt.ParametersBuilder$default(0, 1, null);
                    $i$a$-build-DefaultTransformKt$installDefaultTransformations$2$transformed$1 = false;
                    this.L$0 = $this$intercept;
                    this.L$1 = var10_14;
                    this.label = 3;
                    v4 = MultipartKt.forEachPart(DefaultTransformJvmKt.multiPartData($this$intercept, channel), (Function2<? super PartData, ? super Continuation<? super Unit>, ? extends Object>)new Function2<PartData, Continuation<? super Unit>, Object>($this$invokeSuspend_u24lambda_u2d1, null){
                        int label;
                        /* synthetic */ Object L$0;
                        final /* synthetic */ ParametersBuilder $this_build;
                        {
                            this.$this_build = $receiver;
                            super(2, $completion);
                        }

                        @Nullable
                        public final Object invokeSuspend(@NotNull Object object) {
                            IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0: {
                                    ResultKt.throwOnFailure(object);
                                    PartData part2 = (PartData)this.L$0;
                                    if (part2 instanceof PartData.FormItem) {
                                        String string = part2.getName();
                                        if (string != null) {
                                            String string2 = string;
                                            ParametersBuilder parametersBuilder = this.$this_build;
                                            String partName = string2;
                                            boolean bl = false;
                                            parametersBuilder.append(partName, ((PartData.FormItem)part2).getValue());
                                        }
                                    }
                                    part2.getDispose().invoke();
                                    return Unit.INSTANCE;
                                }
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }

                        @NotNull
                        public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                            Function2<PartData, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                            function2.L$0 = value;
                            return (Continuation)((Object)function2);
                        }

                        @Nullable
                        public final Object invoke(@NotNull PartData p1, @Nullable Continuation<? super Unit> p2) {
                            return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                        }
                    }, this);
                    if (v4 == var14_2) {
                        return var14_2;
                    }
                    ** GOTO lbl83
                    case 3: {
                        $i$f$build = false;
                        $i$a$-build-DefaultTransformKt$installDefaultTransformations$2$transformed$1 = false;
                        var10_14 = (ParametersBuilder)this.L$1;
                        $this$intercept = (PipelineContext)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v4 = $result;
lbl83:
                        // 2 sources

                        v1 = var10_14.build();
                        ** GOTO lbl97
                    }
lbl85:
                    // 1 sources

                    v1 = null;
                    ** GOTO lbl97
lbl87:
                    // 1 sources

                    this.L$0 = $this$intercept;
                    this.label = 4;
                    v1 = DefaultTransformJvmKt.defaultPlatformTransformations($this$intercept, body, this);
                    if (v1 == var14_2) {
                        return var14_2;
                    }
                    ** GOTO lbl97
                    case 4: {
                        $this$intercept = (PipelineContext)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl97:
                        // 8 sources

                        transformed = v1;
                        if (transformed == null) return Unit.INSTANCE;
                        this.L$0 = null;
                        this.L$1 = null;
                        this.label = 5;
                        v5 = $this$intercept.proceedWith(transformed, this);
                        v6 = v5;
                        if (v5 != var14_2) return Unit.INSTANCE;
                        return var14_2;
                    }
                    case 5: {
                        ResultKt.throwOnFailure($result);
                        v6 = $result;
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @Nullable
            public final Object invoke(@NotNull PipelineContext<Object, ApplicationCall> p1, @NotNull Object p2, @Nullable Continuation<? super Unit> p3) {
                Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object> function3 = new /* invalid duplicate definition of identical inner class */;
                function3.L$0 = p1;
                function3.L$1 = p2;
                return function3.invokeSuspend(Unit.INSTANCE);
            }
        });
        PipelinePhase afterTransform = new PipelinePhase("AfterTransform");
        $this$installDefaultTransformations.insertPhaseAfter(ApplicationReceivePipeline.Phases.getTransform(), afterTransform);
        $this$installDefaultTransformations.intercept(afterTransform, (Function3)new Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object>(null){
            int label;
            private /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var13_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$intercept = (PipelineContext)this.L$0;
                        body = this.L$1;
                        v0 = body instanceof ByteReadChannel != false ? (ByteReadChannel)body : null;
                        if (v0 == null) {
                            return Unit.INSTANCE;
                        }
                        channel = v0;
                        $this$call$iv = $this$intercept;
                        $i$f$getCall = false;
                        if (!Intrinsics.areEqual(ApplicationCallKt.getReceiveType((ApplicationCall)$this$call$iv.getContext()).getType(), Reflection.getOrCreateKotlinClass(String.class))) {
                            return Unit.INSTANCE;
                        }
                        $this$call$iv = $this$intercept;
                        $i$f$getCall = false;
                        call$iv = (ApplicationCall)$this$call$iv.getContext();
                        $i$f$withContentType = false;
                        try {
                            $i$a$-withContentType-DefaultTransformKt$installDefaultTransformations$3$charset$1 = false;
                            $this$call$iv = $this$intercept;
                            $i$f$getCall = false;
                            var12_15 = ApplicationRequestPropertiesKt.contentCharset(((ApplicationCall)$this$call$iv.getContext()).getRequest());
                        }
                        catch (BadContentTypeFormatException parseFailure$iv) {
                            throw new BadRequestException("Illegal Content-Type header format: " + call$iv.getRequest().getHeaders().get(HttpHeaders.INSTANCE.getContentType()), parseFailure$iv);
                        }
                        v1 = var12_15;
                        v2 = v1;
                        if (v1 == null) {
                            v2 = Charsets.UTF_8;
                        }
                        charset = v2;
                        this.L$0 = $this$intercept;
                        this.label = 1;
                        v3 = DefaultTransformKt.readText(channel, charset, this);
                        if (v3 == var13_2) {
                            return var13_2;
                        }
                        ** GOTO lbl44
                    }
                    case 1: {
                        $this$intercept = (PipelineContext)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
lbl44:
                        // 2 sources

                        text = (String)v3;
                        this.L$0 = null;
                        this.label = 2;
                        v4 = $this$intercept.proceedWith(text, this);
                        v5 = v4;
                        if (v4 != var13_2) return Unit.INSTANCE;
                        return var13_2;
                    }
                    case 2: {
                        ResultKt.throwOnFailure($result);
                        v5 = $result;
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @Nullable
            public final Object invoke(@NotNull PipelineContext<Object, ApplicationCall> p1, @NotNull Object p2, @Nullable Continuation<? super Unit> p3) {
                Function3<PipelineContext<Object, ApplicationCall>, Object, Continuation<? super Unit>, Object> function3 = new /* invalid duplicate definition of identical inner class */;
                function3.L$0 = p1;
                function3.L$1 = p2;
                return function3.invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    public static final <R> R withContentType(@NotNull ApplicationCall call, @NotNull Function0<? extends R> block2) {
        R r;
        Intrinsics.checkNotNullParameter(call, "call");
        Intrinsics.checkNotNullParameter(block2, "block");
        boolean $i$f$withContentType = false;
        try {
            r = block2.invoke();
        }
        catch (BadContentTypeFormatException parseFailure) {
            throw new BadRequestException("Illegal Content-Type header format: " + call.getRequest().getHeaders().get(HttpHeaders.INSTANCE.getContentType()), parseFailure);
        }
        return r;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Nullable
    public static final Object readText(@NotNull ByteReadChannel var0, @NotNull Charset var1_1, @NotNull Continuation<? super String> var2_2) {
        if (!(var2_2 instanceof readText.1)) ** GOTO lbl-1000
        var7_3 = var2_2;
        if ((var7_3.label & -2147483648) != 0) {
            var7_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super readText.1>)var2_2){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return DefaultTransformKt.readText(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var8_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $continuation.L$0 = charset;
                $continuation.label = 1;
                v0 = $this$readText.readRemaining(0x7FFFFFFFFFFFFFFFL, $continuation);
                if (v0 == var8_5) {
                    return var8_5;
                }
                ** GOTO lbl22
            }
            case 1: {
                charset = (Charset)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl22:
                // 2 sources

                $this$isEmpty$iv = content = (ByteReadPacket)v0;
                $i$f$isEmpty = false;
                if ($this$isEmpty$iv.getEndOfInput()) {
                    return "";
                }
                try {
                    var4_7 = Intrinsics.areEqual(charset, Charsets.UTF_8) != false || Intrinsics.areEqual(charset, Charsets.ISO_8859_1) != false ? Input.readText$default(content, 0, 0, 3, null) : DefaultTransformJvmKt.readTextWithCustomCharset(content, charset);
                    return var4_7;
                }
                finally {
                    content.release();
                }
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}

