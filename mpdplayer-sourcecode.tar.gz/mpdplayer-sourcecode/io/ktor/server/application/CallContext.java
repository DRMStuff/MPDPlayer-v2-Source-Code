/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.application;

import io.ktor.server.application.ApplicationCall;
import io.ktor.util.KtorDsl;
import io.ktor.util.pipeline.PipelineContext;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@KtorDsl
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\"\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0017\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0002B!\b\u0000\u0012\u0006\u0010\u0003\u001a\u00028\u0000\u0012\u0010\u0010\u0004\u001a\f\u0012\u0002\b\u0003\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0010\u0007J\r\u0010\r\u001a\u00020\u000eH\u0000\u00a2\u0006\u0002\b\u000fR\u001e\u0010\u0004\u001a\f\u0012\u0002\b\u0003\u0012\u0004\u0012\u00020\u00060\u0005X\u0094\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0003\u001a\u00028\u0000\u00a2\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\u0010"}, d2={"Lio/ktor/server/application/CallContext;", "PluginConfig", "", "pluginConfig", "context", "Lio/ktor/util/pipeline/PipelineContext;", "Lio/ktor/server/application/ApplicationCall;", "(Ljava/lang/Object;Lio/ktor/util/pipeline/PipelineContext;)V", "getContext", "()Lio/ktor/util/pipeline/PipelineContext;", "getPluginConfig", "()Ljava/lang/Object;", "Ljava/lang/Object;", "finish", "", "finish$ktor_server_core", "ktor-server-core"})
public class CallContext<PluginConfig> {
    @NotNull
    private final PluginConfig pluginConfig;
    @NotNull
    private final PipelineContext<?, ApplicationCall> context;

    public CallContext(@NotNull PluginConfig pluginConfig, @NotNull PipelineContext<?, ApplicationCall> context) {
        Intrinsics.checkNotNullParameter(pluginConfig, "pluginConfig");
        Intrinsics.checkNotNullParameter(context, "context");
        this.pluginConfig = pluginConfig;
        this.context = context;
    }

    @NotNull
    public final PluginConfig getPluginConfig() {
        return this.pluginConfig;
    }

    @NotNull
    protected PipelineContext<?, ApplicationCall> getContext() {
        return this.context;
    }

    public final void finish$ktor_server_core() {
        this.getContext().finish();
    }
}

