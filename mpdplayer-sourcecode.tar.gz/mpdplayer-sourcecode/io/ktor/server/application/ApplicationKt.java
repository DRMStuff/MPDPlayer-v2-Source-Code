/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.application;

import io.ktor.server.application.Application;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0019\u0010\u0000\u001a\u00060\u0001j\u0002`\u0002*\u00020\u00038F\u00a2\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005\u00a8\u0006\u0006"}, d2={"log", "Lorg/slf4j/Logger;", "Lio/ktor/util/logging/Logger;", "Lio/ktor/server/application/Application;", "getLog", "(Lio/ktor/server/application/Application;)Lorg/slf4j/Logger;", "ktor-server-core"})
public final class ApplicationKt {
    @NotNull
    public static final Logger getLog(@NotNull Application $this$log) {
        Intrinsics.checkNotNullParameter($this$log, "<this>");
        return $this$log.getEnvironment().getLog();
    }
}

