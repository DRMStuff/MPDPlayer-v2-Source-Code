/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.sessions;

import io.ktor.server.application.ApplicationCall;
import io.ktor.server.sessions.CurrentSession;
import io.ktor.server.sessions.SessionDataKt;
import io.ktor.server.sessions.SessionProvider;
import io.ktor.server.sessions.SessionTracker;
import io.ktor.server.sessions.SessionTrackerById;
import io.ktor.server.sessions.SessionsKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0016\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0002\u001a\u001b\u0010\u0000\u001a\u0004\u0018\u00010\u0001\"\n\b\u0000\u0010\u0005\u0018\u0001*\u00020\u0006*\u00020\u0002H\u0086\b\u001a\u0016\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u0001H\u0001\"\u0017\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\u00a8\u0006\b"}, d2={"sessionId", "", "Lio/ktor/server/application/ApplicationCall;", "getSessionId", "(Lio/ktor/server/application/ApplicationCall;)Ljava/lang/String;", "SessionType", "", "name", "ktor-server-sessions"})
public final class SessionTrackerByIdKt {
    public static final /* synthetic */ <SessionType> String sessionId(ApplicationCall $this$sessionId) {
        Intrinsics.checkNotNullParameter($this$sessionId, "<this>");
        boolean $i$f$sessionId = false;
        CurrentSession currentSession = SessionDataKt.getSessions($this$sessionId);
        Intrinsics.reifiedOperationMarker(4, "SessionType");
        String name = currentSession.findName(Reflection.getOrCreateKotlinClass(Object.class));
        return SessionTrackerByIdKt.sessionId($this$sessionId, name);
    }

    /*
     * WARNING - void declaration
     */
    @Nullable
    public static final String getSessionId(@NotNull ApplicationCall $this$sessionId) {
        String string;
        void $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter($this$sessionId, "<this>");
        Iterable $this$filter$iv = $this$sessionId.getApplication().getAttributes().get(SessionsKt.getSessionProvidersKey());
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            SessionProvider it = (SessionProvider)element$iv$iv;
            boolean bl = false;
            if (!(it.getTracker() instanceof SessionTrackerById)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        List providers2 = (List)destination$iv$iv;
        switch (providers2.size()) {
            case 0: {
                string = null;
                break;
            }
            case 1: {
                string = SessionTrackerByIdKt.sessionId($this$sessionId, ((SessionProvider)providers2.get(0)).getName());
                break;
            }
            default: {
                throw new IllegalStateException("Multiple session providers installed. Please use sessionId<S>() function instead.".toString());
            }
        }
        return string;
    }

    /*
     * WARNING - void declaration
     */
    @PublishedApi
    @Nullable
    public static final String sessionId(@NotNull ApplicationCall $this$sessionId, @NotNull String name) {
        Object v0;
        block3: {
            void $this$firstOrNull$iv;
            Intrinsics.checkNotNullParameter($this$sessionId, "<this>");
            Intrinsics.checkNotNullParameter(name, "name");
            Iterable iterable = $this$sessionId.getApplication().getAttributes().get(SessionsKt.getSessionProvidersKey());
            boolean $i$f$firstOrNull = false;
            for (Object element$iv : $this$firstOrNull$iv) {
                SessionProvider it = (SessionProvider)element$iv;
                boolean bl = false;
                if (!Intrinsics.areEqual(it.getName(), name)) continue;
                v0 = element$iv;
                break block3;
            }
            v0 = null;
        }
        SessionProvider sessionProvider = v0;
        if (sessionProvider == null) {
            throw new IllegalStateException(("No session provider " + name + " found.").toString());
        }
        SessionProvider provider2 = sessionProvider;
        SessionTracker sessionTracker = provider2.getTracker();
        SessionTrackerById sessionTrackerById = sessionTracker instanceof SessionTrackerById ? (SessionTrackerById)sessionTracker : null;
        if (sessionTrackerById == null) {
            throw new IllegalStateException(("Provider " + name + " doesn't use session IDs").toString());
        }
        SessionTrackerById tracker = sessionTrackerById;
        return $this$sessionId.getAttributes().getOrNull(tracker.getSessionIdKey$ktor_server_sessions());
    }
}

