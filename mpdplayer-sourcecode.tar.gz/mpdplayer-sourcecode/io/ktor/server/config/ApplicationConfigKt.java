/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.config;

import io.ktor.server.config.ApplicationConfig;
import io.ktor.server.config.ApplicationConfigValue;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0014\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\u001a\u0014\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001\u001a\u001a\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0005*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001\u00a8\u0006\u0006"}, d2={"tryGetString", "", "Lio/ktor/server/config/ApplicationConfig;", "key", "tryGetStringList", "", "ktor-server-core"})
public final class ApplicationConfigKt {
    @Nullable
    public static final String tryGetString(@NotNull ApplicationConfig $this$tryGetString, @NotNull String key2) {
        Intrinsics.checkNotNullParameter($this$tryGetString, "<this>");
        Intrinsics.checkNotNullParameter(key2, "key");
        ApplicationConfigValue applicationConfigValue = $this$tryGetString.propertyOrNull(key2);
        return applicationConfigValue != null ? applicationConfigValue.getString() : null;
    }

    @Nullable
    public static final List<String> tryGetStringList(@NotNull ApplicationConfig $this$tryGetStringList, @NotNull String key2) {
        Intrinsics.checkNotNullParameter($this$tryGetStringList, "<this>");
        Intrinsics.checkNotNullParameter(key2, "key");
        ApplicationConfigValue applicationConfigValue = $this$tryGetStringList.propertyOrNull(key2);
        return applicationConfigValue != null ? applicationConfigValue.getList() : null;
    }
}

