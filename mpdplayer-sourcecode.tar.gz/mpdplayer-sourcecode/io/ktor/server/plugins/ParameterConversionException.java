/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.plugins;

import io.ktor.server.plugins.BadRequestException;
import io.ktor.util.internal.ExceptionUtilsJvmKt;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CopyableThrowable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0006\u0018\u00002\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002B!\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\u0002\u0010\bJ\b\u0010\f\u001a\u00020\u0000H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\n\u00a8\u0006\r"}, d2={"Lio/ktor/server/plugins/ParameterConversionException;", "Lio/ktor/server/plugins/BadRequestException;", "Lkotlinx/coroutines/CopyableThrowable;", "parameterName", "", "type", "cause", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V", "getParameterName", "()Ljava/lang/String;", "getType", "createCopy", "ktor-server-core"})
public final class ParameterConversionException
extends BadRequestException
implements CopyableThrowable<ParameterConversionException> {
    @NotNull
    private final String parameterName;
    @NotNull
    private final String type;

    public ParameterConversionException(@NotNull String parameterName, @NotNull String type2, @Nullable Throwable cause) {
        Intrinsics.checkNotNullParameter(parameterName, "parameterName");
        Intrinsics.checkNotNullParameter(type2, "type");
        super("Request parameter " + parameterName + " couldn't be parsed/converted to " + type2, cause);
        this.parameterName = parameterName;
        this.type = type2;
    }

    public /* synthetic */ ParameterConversionException(String string, String string2, Throwable throwable, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        this(string, string2, throwable);
    }

    @NotNull
    public final String getParameterName() {
        return this.parameterName;
    }

    @NotNull
    public final String getType() {
        return this.type;
    }

    @Override
    @NotNull
    public ParameterConversionException createCopy() {
        ParameterConversionException parameterConversionException;
        ParameterConversionException it = parameterConversionException = new ParameterConversionException(this.parameterName, this.type, this);
        boolean bl = false;
        ExceptionUtilsJvmKt.initCauseBridge(it, this);
        return parameterConversionException;
    }
}

