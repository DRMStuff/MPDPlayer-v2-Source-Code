/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.plugins.callloging;

import io.ktor.server.application.ApplicationCall;
import io.ktor.server.plugins.callloging.MDCEntry;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.slf4j.MDCContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.MDC;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u00002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0000\u001aG\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\u0005\u001a\u00020\u00062\u001e\b\u0004\u0010\u0007\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\t\u0012\u0006\u0012\u0004\u0018\u00010\n0\bH\u0080H\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000b\u001a\u0012\u0010\f\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00040\u0003H\u0000\u001a&\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0\u000e*\b\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\u0010"}, d2={"withMDC", "", "mdcEntries", "", "Lio/ktor/server/plugins/callloging/MDCEntry;", "call", "Lio/ktor/server/application/ApplicationCall;", "block", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "", "(Ljava/util/List;Lio/ktor/server/application/ApplicationCall;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "cleanup", "setup", "", "", "ktor-server-call-logging"})
public final class MDCEntryUtilsKt {
    @Nullable
    public static final Object withMDC(@NotNull List<MDCEntry> mdcEntries, @NotNull ApplicationCall call, @NotNull Function1<? super Continuation<? super Unit>, ? extends Object> block2, @NotNull Continuation<? super Unit> $completion) {
        boolean $i$f$withMDC = false;
        Object object = BuildersKt.withContext(new MDCContext(MDCEntryUtilsKt.setup(mdcEntries, call)), (Function2)new Function2<CoroutineScope, Continuation<? super Unit>, Object>(block2, mdcEntries, null){
            int label;
            final /* synthetic */ Function1<Continuation<? super Unit>, Object> $block;
            final /* synthetic */ List<MDCEntry> $mdcEntries;
            {
                this.$block = $block;
                this.$mdcEntries = $mdcEntries;
                super(2, $completion);
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             * WARNING - void declaration
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        this.label = 1;
                        Object object3 = this.$block.invoke(this);
                        if (object3 != object2) return Unit.INSTANCE;
                        return object2;
                    }
                    case 1: {
                        Object object3;
                        try {
                            void $result;
                            ResultKt.throwOnFailure($result);
                            object3 = $result;
                            return Unit.INSTANCE;
                        }
                        catch (Throwable throwable) {
                            throw throwable;
                        }
                        finally {
                            MDCEntryUtilsKt.cleanup(this.$mdcEntries);
                        }
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            @Nullable
            public final Object invokeSuspend$$forInline(@NotNull Object $result) {
                try {
                    this.$block.invoke(this);
                }
                finally {
                    MDCEntryUtilsKt.cleanup(this.$mdcEntries);
                }
                return Unit.INSTANCE;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, $completion);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return object;
        }
        return Unit.INSTANCE;
    }

    private static final Object withMDC$$forInline(List<MDCEntry> mdcEntries, ApplicationCall call, Function1<? super Continuation<? super Unit>, ? extends Object> block2, Continuation<? super Unit> $completion) {
        boolean $i$f$withMDC = false;
        CoroutineContext coroutineContext2 = new MDCContext(MDCEntryUtilsKt.setup(mdcEntries, call));
        Function2 function2 = new /* invalid duplicate definition of identical inner class */;
        InlineMarker.mark(0);
        BuildersKt.withContext(coroutineContext2, function2, $completion);
        InlineMarker.mark(1);
        return Unit.INSTANCE;
    }

    @NotNull
    public static final Map<String, String> setup(@NotNull List<MDCEntry> $this$setup, @NotNull ApplicationCall call) {
        Intrinsics.checkNotNullParameter($this$setup, "<this>");
        Intrinsics.checkNotNullParameter(call, "call");
        HashMap result2 = new HashMap();
        Iterable $this$forEach$iv = $this$setup;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            String mdcValue;
            Object $this$setup_u24lambda_u2d2_u24lambda_u2d0;
            MDCEntry entry = (MDCEntry)element$iv;
            boolean bl = false;
            Object object = $this$setup;
            try {
                $this$setup_u24lambda_u2d2_u24lambda_u2d0 = object;
                boolean bl2 = false;
                $this$setup_u24lambda_u2d2_u24lambda_u2d0 = Result.constructor-impl(entry.getProvider().invoke(call));
            }
            catch (Throwable bl2) {
                $this$setup_u24lambda_u2d2_u24lambda_u2d0 = Result.constructor-impl(ResultKt.createFailure(bl2));
            }
            object = $this$setup_u24lambda_u2d2_u24lambda_u2d0;
            String provider2 = (String)(Result.isFailure-impl(object) ? null : object);
            if (provider2 == null) continue;
            boolean bl3 = false;
            ((Map)result2).put(entry.getName(), mdcValue);
        }
        return result2;
    }

    public static final void cleanup(@NotNull List<MDCEntry> $this$cleanup) {
        Intrinsics.checkNotNullParameter($this$cleanup, "<this>");
        Iterable $this$forEach$iv = $this$cleanup;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            MDCEntry it = (MDCEntry)element$iv;
            boolean bl = false;
            MDC.remove(it.getName());
        }
    }
}

