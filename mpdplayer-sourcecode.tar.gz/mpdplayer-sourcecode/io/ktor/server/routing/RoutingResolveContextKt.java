/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.routing;

import kotlin.Metadata;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u000e\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\b\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0004"}, d2={"MIN_QUALITY", "", "ROUTING_DEFAULT_CAPACITY", "", "ktor-server-core"})
public final class RoutingResolveContextKt {
    private static final int ROUTING_DEFAULT_CAPACITY = 16;
    private static final double MIN_QUALITY = -1.7976931348623157E308;
}

