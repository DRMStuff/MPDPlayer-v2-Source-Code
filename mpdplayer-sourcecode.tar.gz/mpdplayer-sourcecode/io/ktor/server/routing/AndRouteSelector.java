/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.server.routing;

import io.ktor.http.Parameters;
import io.ktor.http.ParametersKt;
import io.ktor.server.routing.RouteSelector;
import io.ktor.server.routing.RouteSelectorEvaluation;
import io.ktor.server.routing.RoutingResolveContext;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u00a2\u0006\u0002\u0010\u0004J\t\u0010\b\u001a\u00020\u0001H\u00c6\u0003J\t\u0010\t\u001a\u00020\u0001H\u00c6\u0003J\u001d\u0010\n\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00012\b\b\u0002\u0010\u0003\u001a\u00020\u0001H\u00c6\u0001J\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u00d6\u0003J\u0018\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\t\u0010\u0015\u001a\u00020\u0014H\u00d6\u0001J\b\u0010\u0016\u001a\u00020\u0017H\u0016R\u0011\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0003\u001a\u00020\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0006\u00a8\u0006\u0018"}, d2={"Lio/ktor/server/routing/AndRouteSelector;", "Lio/ktor/server/routing/RouteSelector;", "first", "second", "(Lio/ktor/server/routing/RouteSelector;Lio/ktor/server/routing/RouteSelector;)V", "getFirst", "()Lio/ktor/server/routing/RouteSelector;", "getSecond", "component1", "component2", "copy", "equals", "", "other", "", "evaluate", "Lio/ktor/server/routing/RouteSelectorEvaluation;", "context", "Lio/ktor/server/routing/RoutingResolveContext;", "segmentIndex", "", "hashCode", "toString", "", "ktor-server-core"})
public final class AndRouteSelector
extends RouteSelector {
    @NotNull
    private final RouteSelector first;
    @NotNull
    private final RouteSelector second;

    public AndRouteSelector(@NotNull RouteSelector first2, @NotNull RouteSelector second2) {
        Intrinsics.checkNotNullParameter(first2, "first");
        Intrinsics.checkNotNullParameter(second2, "second");
        this.first = first2;
        this.second = second2;
    }

    @NotNull
    public final RouteSelector getFirst() {
        return this.first;
    }

    @NotNull
    public final RouteSelector getSecond() {
        return this.second;
    }

    @Override
    @NotNull
    public RouteSelectorEvaluation evaluate(@NotNull RoutingResolveContext context, int segmentIndex) {
        Intrinsics.checkNotNullParameter(context, "context");
        RouteSelectorEvaluation result1 = this.first.evaluate(context, segmentIndex);
        if (!(result1 instanceof RouteSelectorEvaluation.Success)) {
            return result1;
        }
        RouteSelectorEvaluation result2 = this.second.evaluate(context, segmentIndex + ((RouteSelectorEvaluation.Success)result1).getSegmentIncrement());
        if (!(result2 instanceof RouteSelectorEvaluation.Success)) {
            return result2;
        }
        Parameters resultValues = ParametersKt.plus(((RouteSelectorEvaluation.Success)result1).getParameters(), ((RouteSelectorEvaluation.Success)result2).getParameters());
        return new RouteSelectorEvaluation.Success(((RouteSelectorEvaluation.Success)result1).getQuality() * ((RouteSelectorEvaluation.Success)result2).getQuality(), resultValues, ((RouteSelectorEvaluation.Success)result1).getSegmentIncrement() + ((RouteSelectorEvaluation.Success)result2).getSegmentIncrement());
    }

    @NotNull
    public String toString() {
        return "" + '{' + this.first + " & " + this.second + '}';
    }

    @NotNull
    public final RouteSelector component1() {
        return this.first;
    }

    @NotNull
    public final RouteSelector component2() {
        return this.second;
    }

    @NotNull
    public final AndRouteSelector copy(@NotNull RouteSelector first2, @NotNull RouteSelector second2) {
        Intrinsics.checkNotNullParameter(first2, "first");
        Intrinsics.checkNotNullParameter(second2, "second");
        return new AndRouteSelector(first2, second2);
    }

    public static /* synthetic */ AndRouteSelector copy$default(AndRouteSelector andRouteSelector, RouteSelector routeSelector, RouteSelector routeSelector2, int n, Object object) {
        if ((n & 1) != 0) {
            routeSelector = andRouteSelector.first;
        }
        if ((n & 2) != 0) {
            routeSelector2 = andRouteSelector.second;
        }
        return andRouteSelector.copy(routeSelector, routeSelector2);
    }

    public int hashCode() {
        int result2 = this.first.hashCode();
        result2 = result2 * 31 + this.second.hashCode();
        return result2;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AndRouteSelector)) {
            return false;
        }
        AndRouteSelector andRouteSelector = (AndRouteSelector)other;
        if (!Intrinsics.areEqual(this.first, andRouteSelector.first)) {
            return false;
        }
        return Intrinsics.areEqual(this.second, andRouteSelector.second);
    }
}

