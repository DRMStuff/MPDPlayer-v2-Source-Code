/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.client.engine;

import io.ktor.client.HttpClient;
import io.ktor.client.engine.HttpClientEngine;
import io.ktor.client.engine.HttpClientEngineBaseKt;
import io.ktor.client.engine.HttpClientEngineCapability;
import io.ktor.util.CoroutinesUtilsKt;
import io.ktor.util.InternalAPI;
import java.util.Set;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CompletableJob;
import kotlinx.coroutines.CoroutineName;
import kotlinx.coroutines.Job;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\b&\u0018\u00002\u00020\u0010B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H\u0016\u00a2\u0006\u0004\b\u0006\u0010\u0007R\u001b\u0010\r\u001a\u00020\b8VX\u0096\u0084\u0002\u00a2\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u000b\u0010\fR\u0014\u0010\u0002\u001a\u00020\u00018\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b\u0002\u0010\u000e\u00a8\u0006\u000f"}, d2={"Lio/ktor/client/engine/HttpClientEngineBase;", "", "engineName", "<init>", "(Ljava/lang/String;)V", "", "close", "()V", "Lkotlin/coroutines/CoroutineContext;", "coroutineContext$delegate", "Lkotlin/Lazy;", "getCoroutineContext", "()Lkotlin/coroutines/CoroutineContext;", "coroutineContext", "Ljava/lang/String;", "ktor-client-core", "Lio/ktor/client/engine/HttpClientEngine;"})
public abstract class HttpClientEngineBase
implements HttpClientEngine {
    @NotNull
    private final String engineName;
    @NotNull
    private volatile /* synthetic */ int closed;
    private static final /* synthetic */ AtomicIntegerFieldUpdater closed$FU;
    @NotNull
    private final Lazy coroutineContext$delegate;

    public HttpClientEngineBase(@NotNull String engineName) {
        Intrinsics.checkNotNullParameter(engineName, "engineName");
        this.engineName = engineName;
        this.closed = 0;
        this.coroutineContext$delegate = LazyKt.lazy((Function0)new Function0<CoroutineContext>(this){
            final /* synthetic */ HttpClientEngineBase this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            @NotNull
            public final CoroutineContext invoke() {
                return CoroutinesUtilsKt.SilentSupervisor$default(null, 1, null).plus(this.this$0.getDispatcher()).plus(new CoroutineName(HttpClientEngineBase.access$getEngineName$p(this.this$0) + "-context"));
            }
        });
    }

    @Override
    @NotNull
    public CoroutineContext getCoroutineContext() {
        Lazy lazy = this.coroutineContext$delegate;
        return (CoroutineContext)lazy.getValue();
    }

    @Override
    public void close() {
        if (!closed$FU.compareAndSet(this, 0, 1)) {
            return;
        }
        Object e = this.getCoroutineContext().get(Job.Key);
        CompletableJob completableJob = e instanceof CompletableJob ? (CompletableJob)e : null;
        if (completableJob == null) {
            return;
        }
        CompletableJob requestJob = completableJob;
        requestJob.complete();
        requestJob.invokeOnCompletion((Function1<? super Throwable, Unit>)new Function1<Throwable, Unit>(this){
            final /* synthetic */ HttpClientEngineBase this$0;
            {
                this.this$0 = $receiver;
                super(1);
            }

            public final void invoke(@Nullable Throwable it) {
                HttpClientEngineBaseKt.access$close(this.this$0.getDispatcher());
            }
        });
    }

    @Override
    @NotNull
    public Set<HttpClientEngineCapability<?>> getSupportedCapabilities() {
        return HttpClientEngine.DefaultImpls.getSupportedCapabilities(this);
    }

    @Override
    @InternalAPI
    public void install(@NotNull HttpClient client2) {
        HttpClientEngine.DefaultImpls.install(this, client2);
    }

    public static final /* synthetic */ String access$getEngineName$p(HttpClientEngineBase $this) {
        return $this.engineName;
    }

    static {
        closed$FU = AtomicIntegerFieldUpdater.newUpdater(HttpClientEngineBase.class, "closed");
    }
}

