/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.client.call;

import io.ktor.client.HttpClient;
import io.ktor.client.call.HttpClientCall;
import io.ktor.client.call.SavedHttpRequest;
import io.ktor.client.call.SavedHttpResponse;
import io.ktor.client.request.HttpRequest;
import io.ktor.client.statement.HttpResponse;
import io.ktor.utils.io.ByteChannelCtorKt;
import io.ktor.utils.io.ByteReadChannel;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u00a2\u0006\u0002\u0010\nJ\u0011\u0010\u000f\u001a\u00020\u0010H\u0094@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0011R\u0014\u0010\u000b\u001a\u00020\fX\u0094D\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\u0012"}, d2={"Lio/ktor/client/call/SavedHttpCall;", "Lio/ktor/client/call/HttpClientCall;", "client", "Lio/ktor/client/HttpClient;", "request", "Lio/ktor/client/request/HttpRequest;", "response", "Lio/ktor/client/statement/HttpResponse;", "responseBody", "", "(Lio/ktor/client/HttpClient;Lio/ktor/client/request/HttpRequest;Lio/ktor/client/statement/HttpResponse;[B)V", "allowDoubleReceive", "", "getAllowDoubleReceive", "()Z", "getResponseContent", "Lio/ktor/utils/io/ByteReadChannel;", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "ktor-client-core"})
public final class SavedHttpCall
extends HttpClientCall {
    @NotNull
    private final byte[] responseBody;
    private final boolean allowDoubleReceive;

    public SavedHttpCall(@NotNull HttpClient client2, @NotNull HttpRequest request2, @NotNull HttpResponse response2, @NotNull byte[] responseBody) {
        Intrinsics.checkNotNullParameter(client2, "client");
        Intrinsics.checkNotNullParameter(request2, "request");
        Intrinsics.checkNotNullParameter(response2, "response");
        Intrinsics.checkNotNullParameter(responseBody, "responseBody");
        super(client2);
        this.responseBody = responseBody;
        this.setRequest(new SavedHttpRequest(this, request2));
        this.setResponse(new SavedHttpResponse(this, this.responseBody, response2));
        this.allowDoubleReceive = true;
    }

    @Override
    @Nullable
    protected Object getResponseContent(@NotNull Continuation<? super ByteReadChannel> $completion) {
        return ByteChannelCtorKt.ByteReadChannel(this.responseBody);
    }

    @Override
    protected boolean getAllowDoubleReceive() {
        return this.allowDoubleReceive;
    }
}

