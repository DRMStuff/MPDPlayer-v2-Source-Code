/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.client.plugins.websocket.cio;

import io.ktor.client.HttpClient;
import io.ktor.client.plugins.websocket.ClientWebSocketSession;
import io.ktor.client.plugins.websocket.cio.BuildersCioKt;
import io.ktor.client.request.HttpRequestBuilder;
import io.ktor.client.request.HttpRequestKt;
import io.ktor.client.statement.HttpStatement;
import io.ktor.http.HttpMethod;
import io.ktor.http.URLProtocol;
import io.ktor.websocket.WebSocketSessionKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000B\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\u001a\u0087\u0001\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00062\u0019\b\u0002\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00010\u000b\u00a2\u0006\u0002\b\r2'\u0010\u000e\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u000f\u00a2\u0006\u0002\b\rH\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0013\u001a^\u0010\u0014\u001a\u00020\u0010*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00062\u0019\b\u0002\u0010\u000e\u001a\u0013\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00010\u000b\u00a2\u0006\u0002\b\rH\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0015\u001a\u0087\u0001\u0010\u0016\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00062\u0019\b\u0002\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00010\u000b\u00a2\u0006\u0002\b\r2'\u0010\u000e\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u000f\u00a2\u0006\u0002\b\rH\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0013\u001a\u0087\u0001\u0010\u0017\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00062\u0019\b\u0002\u0010\n\u001a\u0013\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00010\u000b\u00a2\u0006\u0002\b\r2'\u0010\u000e\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u000f\u00a2\u0006\u0002\b\rH\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0013\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\u0018"}, d2={"webSocketRaw", "", "Lio/ktor/client/HttpClient;", "method", "Lio/ktor/http/HttpMethod;", "host", "", "port", "", "path", "request", "Lkotlin/Function1;", "Lio/ktor/client/request/HttpRequestBuilder;", "Lkotlin/ExtensionFunctionType;", "block", "Lkotlin/Function2;", "Lio/ktor/client/plugins/websocket/ClientWebSocketSession;", "Lkotlin/coroutines/Continuation;", "", "(Lio/ktor/client/HttpClient;Lio/ktor/http/HttpMethod;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "webSocketRawSession", "(Lio/ktor/client/HttpClient;Lio/ktor/http/HttpMethod;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "wsRaw", "wssRaw", "ktor-client-cio"})
public final class BuildersCioKt {
    /*
     * WARNING - void declaration
     */
    @Nullable
    public static final Object webSocketRawSession(@NotNull HttpClient $this$webSocketRawSession, @NotNull HttpMethod method2, @Nullable String host2, @Nullable Integer port2, @Nullable String path, @NotNull Function1<? super HttpRequestBuilder, Unit> block2, @NotNull Continuation<? super ClientWebSocketSession> $completion) {
        void $this$prepareRequest$iv$iv;
        void builder$iv$iv;
        HttpRequestBuilder httpRequestBuilder;
        HttpClient $this$prepareRequest$iv = $this$webSocketRawSession;
        boolean $i$f$prepareRequest = false;
        HttpClient httpClient = $this$prepareRequest$iv;
        HttpRequestBuilder $this$webSocketRawSession_u24lambda_u2d0 = httpRequestBuilder = new HttpRequestBuilder();
        boolean bl = false;
        $this$webSocketRawSession_u24lambda_u2d0.setMethod(method2);
        HttpRequestKt.url$default($this$webSocketRawSession_u24lambda_u2d0, "ws", host2, port2, path, null, 16, null);
        block2.invoke($this$webSocketRawSession_u24lambda_u2d0);
        boolean $i$f$prepareRequest2 = false;
        HttpStatement request2 = new HttpStatement((HttpRequestBuilder)builder$iv$iv, (HttpClient)$this$prepareRequest$iv$iv);
        CompletableDeferred result2 = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
        BuildersKt.launch$default($this$webSocketRawSession, null, null, new Function2<CoroutineScope, Continuation<? super Unit>, Object>(request2, (CompletableDeferred<ClientWebSocketSession>)result2, null){
            Object L$0;
            Object L$1;
            Object L$2;
            int label;
            final /* synthetic */ HttpStatement $request;
            final /* synthetic */ CompletableDeferred<ClientWebSocketSession> $result;
            {
                this.$request = $request;
                this.$result = $result;
                super(2, $completion);
            }

            /*
             * Exception decompiling
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                /*
                 * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                 * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [11[CASE]], but top level block is 0[TRYBLOCK]
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:588)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner.dumpWithArgs(ClassFileDumperAnonymousInner.java:87)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner.dumpInner(ConstructorInvokationAnonymousInner.java:75)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation.dumpInner(StaticFunctionInvokation.java:116)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredExpressionStatement.dump(StructuredExpressionStatement.java:27)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.dump(Block.java:560)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.dump(AttributeCode.java:135)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:617)
                 * org.benf.cfr.reader.entities.classfilehelpers.AbstractClassFileDumper.dumpMethods(AbstractClassFileDumper.java:193)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal.dump(ClassFileDumperNormal.java:77)
                 * org.benf.cfr.reader.entities.ClassFile.dump(ClassFile.java:1138)
                 * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:932)
                 * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
                 * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
                 * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
                 * org.benf.cfr.reader.Main.main(Main.java:49)
                 */
                throw new IllegalStateException(Decompilation failed);
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 3, null);
        return result2.await($completion);
    }

    public static /* synthetic */ Object webSocketRawSession$default(HttpClient httpClient, HttpMethod httpMethod, String string, Integer n, String string2, Function1 function1, Continuation continuation2, int n2, Object object) {
        if ((n2 & 1) != 0) {
            httpMethod = HttpMethod.Companion.getGet();
        }
        if ((n2 & 2) != 0) {
            string = null;
        }
        if ((n2 & 4) != 0) {
            n = null;
        }
        if ((n2 & 8) != 0) {
            string2 = null;
        }
        if ((n2 & 0x10) != 0) {
            function1 = webSocketRawSession.2.INSTANCE;
        }
        return BuildersCioKt.webSocketRawSession(httpClient, httpMethod, string, n, string2, function1, continuation2);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Nullable
    public static final Object webSocketRaw(@NotNull HttpClient var0, @NotNull HttpMethod var1_1, @Nullable String var2_2, @Nullable Integer var3_3, @Nullable String var4_4, @NotNull Function1<? super HttpRequestBuilder, Unit> var5_5, @NotNull Function2<? super ClientWebSocketSession, ? super Continuation<? super Unit>, ? extends Object> var6_6, @NotNull Continuation<? super Unit> var7_7) {
        if (!(var7_7 instanceof webSocketRaw.1)) ** GOTO lbl-1000
        var11_8 = var7_7;
        if ((var11_8.label & -2147483648) != 0) {
            var11_8.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super webSocketRaw.1>)var7_7){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return BuildersCioKt.webSocketRaw(null, null, null, null, null, null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var12_10 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $continuation.L$0 = block;
                $continuation.label = 1;
                v0 = BuildersCioKt.webSocketRawSession($this$webSocketRaw, (HttpMethod)method, (String)host, (Integer)port, (String)path, (Function1<? super HttpRequestBuilder, Unit>)new Function1<HttpRequestBuilder, Unit>((Integer)port, (Function1<? super HttpRequestBuilder, Unit>)request){
                    final /* synthetic */ Integer $port;
                    final /* synthetic */ Function1<HttpRequestBuilder, Unit> $request;
                    {
                        this.$port = $port;
                        this.$request = $request;
                        super(1);
                    }

                    public final void invoke(@NotNull HttpRequestBuilder $this$webSocketRawSession) {
                        Intrinsics.checkNotNullParameter($this$webSocketRawSession, "$this$webSocketRawSession");
                        $this$webSocketRawSession.getUrl().setProtocol(URLProtocol.Companion.getWS());
                        if (this.$port != null) {
                            $this$webSocketRawSession.getUrl().setPort(this.$port);
                        }
                        this.$request.invoke($this$webSocketRawSession);
                    }
                }, $continuation);
                if (v0 == var12_10) {
                    return var12_10;
                }
                ** GOTO lbl22
            }
            case 1: {
                block = (Function2)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl22:
                // 2 sources

                session = (ClientWebSocketSession)v0;
                $continuation.L$0 = session;
                $continuation.label = 2;
                v1 = block.invoke(session, $continuation);
                ** if (v1 != var12_10) goto lbl30
lbl29:
                // 1 sources

                return var12_10;
lbl30:
                // 1 sources

                ** GOTO lbl37
            }
            case 2: {
                session = (ClientWebSocketSession)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v1 = $result;
lbl37:
                // 2 sources

                $continuation.L$0 = null;
                $continuation.label = 3;
                v2 = WebSocketSessionKt.close$default(session, null, $continuation, 1, null);
                v3 = v2;
                if (v2 != var12_10) return Unit.INSTANCE;
                return var12_10;
            }
            case 3: {
                ResultKt.throwOnFailure($result);
                v3 = $result;
                return Unit.INSTANCE;
            }
            catch (Throwable cause) {
                try {
                    $continuation.L$0 = session;
                    $continuation.label = 4;
                    v4 = WebSocketSessionKt.closeExceptionally(session, cause, $continuation);
                    ** if (v4 != var12_10) goto lbl61
                }
                catch (Throwable var9_13) {
                    $continuation.L$0 = var9_13;
                    $continuation.label = 6;
                    v5 = WebSocketSessionKt.close$default(session, null, $continuation, 1, null);
                    v6 = v5;
                    if (v5 != var12_10) throw var9_14;
                    return var12_10;
                }
lbl60:
                // 1 sources

                return var12_10;
lbl61:
                // 1 sources

                ** GOTO lbl68
                case 4: {
                    session = (ClientWebSocketSession)$continuation.L$0;
                    ResultKt.throwOnFailure($result);
                    v4 = $result;
lbl68:
                    // 2 sources

                    $continuation.L$0 = null;
                    $continuation.label = 5;
                    v7 = WebSocketSessionKt.close$default(session, null, $continuation, 1, null);
                    v8 = v7;
                    if (v7 != var12_10) return Unit.INSTANCE;
                    return var12_10;
                }
                case 5: {
                    ResultKt.throwOnFailure($result);
                    v8 = $result;
                    return Unit.INSTANCE;
                }
            }
            case 6: {
                var9_14 = (Throwable)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v6 = $result;
                throw var9_14;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    public static /* synthetic */ Object webSocketRaw$default(HttpClient httpClient, HttpMethod httpMethod, String string, Integer n, String string2, Function1 function1, Function2 function2, Continuation continuation2, int n2, Object object) {
        if ((n2 & 1) != 0) {
            httpMethod = HttpMethod.Companion.getGet();
        }
        if ((n2 & 2) != 0) {
            string = null;
        }
        if ((n2 & 4) != 0) {
            n = null;
        }
        if ((n2 & 8) != 0) {
            string2 = null;
        }
        if ((n2 & 0x10) != 0) {
            function1 = webSocketRaw.2.INSTANCE;
        }
        return BuildersCioKt.webSocketRaw(httpClient, httpMethod, string, n, string2, function1, function2, continuation2);
    }

    @Nullable
    public static final Object wsRaw(@NotNull HttpClient $this$wsRaw, @NotNull HttpMethod method2, @Nullable String host2, @Nullable Integer port2, @Nullable String path, @NotNull Function1<? super HttpRequestBuilder, Unit> request2, @NotNull Function2<? super ClientWebSocketSession, ? super Continuation<? super Unit>, ? extends Object> block2, @NotNull Continuation<? super Unit> $completion) {
        Object object = BuildersCioKt.webSocketRaw($this$wsRaw, method2, host2, port2, path, request2, block2, $completion);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return object;
        }
        return Unit.INSTANCE;
    }

    public static /* synthetic */ Object wsRaw$default(HttpClient httpClient, HttpMethod httpMethod, String string, Integer n, String string2, Function1 function1, Function2 function2, Continuation continuation2, int n2, Object object) {
        if ((n2 & 1) != 0) {
            httpMethod = HttpMethod.Companion.getGet();
        }
        if ((n2 & 2) != 0) {
            string = null;
        }
        if ((n2 & 4) != 0) {
            n = null;
        }
        if ((n2 & 8) != 0) {
            string2 = null;
        }
        if ((n2 & 0x10) != 0) {
            function1 = wsRaw.2.INSTANCE;
        }
        return BuildersCioKt.wsRaw(httpClient, httpMethod, string, n, string2, function1, function2, continuation2);
    }

    @Nullable
    public static final Object wssRaw(@NotNull HttpClient $this$wssRaw, @NotNull HttpMethod method2, @Nullable String host2, @Nullable Integer port2, @Nullable String path, @NotNull Function1<? super HttpRequestBuilder, Unit> request2, @NotNull Function2<? super ClientWebSocketSession, ? super Continuation<? super Unit>, ? extends Object> block2, @NotNull Continuation<? super Unit> $completion) {
        Object object = BuildersCioKt.webSocketRaw($this$wssRaw, method2, host2, port2, path, (Function1<? super HttpRequestBuilder, Unit>)new Function1<HttpRequestBuilder, Unit>(port2, request2){
            final /* synthetic */ Integer $port;
            final /* synthetic */ Function1<HttpRequestBuilder, Unit> $request;
            {
                this.$port = $port;
                this.$request = $request;
                super(1);
            }

            public final void invoke(@NotNull HttpRequestBuilder $this$webSocketRaw) {
                Intrinsics.checkNotNullParameter($this$webSocketRaw, "$this$webSocketRaw");
                $this$webSocketRaw.getUrl().setProtocol(URLProtocol.Companion.getWSS());
                if (this.$port != null) {
                    $this$webSocketRaw.getUrl().setPort(this.$port);
                }
                this.$request.invoke($this$webSocketRaw);
            }
        }, block2, $completion);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return object;
        }
        return Unit.INSTANCE;
    }

    public static /* synthetic */ Object wssRaw$default(HttpClient httpClient, HttpMethod httpMethod, String string, Integer n, String string2, Function1 function1, Function2 function2, Continuation continuation2, int n2, Object object) {
        if ((n2 & 1) != 0) {
            httpMethod = HttpMethod.Companion.getGet();
        }
        if ((n2 & 2) != 0) {
            string = null;
        }
        if ((n2 & 4) != 0) {
            n = null;
        }
        if ((n2 & 8) != 0) {
            string2 = null;
        }
        if ((n2 & 0x10) != 0) {
            function1 = wssRaw.2.INSTANCE;
        }
        return BuildersCioKt.wssRaw(httpClient, httpMethod, string, n, string2, function1, function2, continuation2);
    }
}

