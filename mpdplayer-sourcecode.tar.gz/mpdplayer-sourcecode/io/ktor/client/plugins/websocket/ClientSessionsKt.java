/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.client.plugins.websocket;

import io.ktor.client.plugins.HttpClientPluginKt;
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession;
import io.ktor.client.plugins.websocket.WebSockets;
import io.ktor.serialization.ContentConverterKt;
import io.ktor.serialization.WebsocketContentConverter;
import io.ktor.serialization.WebsocketConverterNotFoundException;
import io.ktor.serialization.WebsocketDeserializeException;
import io.ktor.util.reflect.TypeInfo;
import io.ktor.util.reflect.TypeInfoJvmKt;
import io.ktor.websocket.Frame;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KType;
import kotlin.reflect.TypesJVMKt;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.channels.SendChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0003\u001a\u001d\u0010\u0005\u001a\u0002H\u0006\"\u0006\b\u0000\u0010\u0006\u0018\u0001*\u00020\u0002H\u0086H\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0007\u001a%\u0010\b\u001a\u00020\t\"\u0006\b\u0000\u0010\u0006\u0018\u0001*\u00020\u00022\u0006\u0010\n\u001a\u0002H\u0006H\u0086H\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000b\"\u0017\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\f"}, d2={"converter", "Lio/ktor/serialization/WebsocketContentConverter;", "Lio/ktor/client/plugins/websocket/DefaultClientWebSocketSession;", "getConverter", "(Lio/ktor/client/plugins/websocket/DefaultClientWebSocketSession;)Lio/ktor/serialization/WebsocketContentConverter;", "receiveDeserialized", "T", "(Lio/ktor/client/plugins/websocket/DefaultClientWebSocketSession;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "sendSerialized", "", "data", "(Lio/ktor/client/plugins/websocket/DefaultClientWebSocketSession;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "ktor-client-core"})
public final class ClientSessionsKt {
    @Nullable
    public static final WebsocketContentConverter getConverter(@NotNull DefaultClientWebSocketSession $this$converter) {
        Intrinsics.checkNotNullParameter($this$converter, "<this>");
        WebSockets webSockets = (WebSockets)HttpClientPluginKt.pluginOrNull($this$converter.getCall().getClient(), WebSockets.Plugin);
        return webSockets != null ? webSockets.getContentConverter() : null;
    }

    /*
     * WARNING - void declaration
     */
    public static final /* synthetic */ <T> Object sendSerialized(DefaultClientWebSocketSession $this$sendSerialized, T data2, Continuation<? super Unit> $completion) {
        void $this$sendSerializedBase$iv;
        void charset$iv;
        boolean $i$f$sendSerialized = false;
        Object object = ClientSessionsKt.getConverter($this$sendSerialized);
        if (object == null) {
            throw new WebsocketConverterNotFoundException("No converter was found for websocket", null, 2, null);
        }
        WebsocketContentConverter converter = object;
        object = $this$sendSerialized;
        Charset charset = ContentConverterKt.suitableCharset$default($this$sendSerialized.getCall().getRequest().getHeaders(), null, 1, null);
        boolean $i$f$sendSerializedBase = false;
        boolean $i$f$typeInfo = false;
        Intrinsics.reifiedOperationMarker(6, "T");
        KType kType$iv$iv = null;
        Type reifiedType$iv$iv = TypesJVMKt.getJavaType(kType$iv$iv);
        Intrinsics.reifiedOperationMarker(4, "T");
        TypeInfo typeInfo = TypeInfoJvmKt.typeInfoImpl(reifiedType$iv$iv, Reflection.getOrCreateKotlinClass(Object.class), kType$iv$iv);
        InlineMarker.mark(0);
        Object object2 = converter.serializeNullable((Charset)charset$iv, typeInfo, data2, $completion);
        InlineMarker.mark(1);
        Frame serializedData$iv = (Frame)object2;
        SendChannel<Frame> sendChannel = $this$sendSerializedBase$iv.getOutgoing();
        InlineMarker.mark(0);
        sendChannel.send(serializedData$iv, $completion);
        InlineMarker.mark(1);
        return Unit.INSTANCE;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final /* synthetic */ <T> Object receiveDeserialized(DefaultClientWebSocketSession $this$receiveDeserialized, Continuation<? super T> $completion) {
        Object object;
        void charset$iv;
        void $this$receiveDeserializedBase$iv;
        boolean $i$f$receiveDeserialized = false;
        Object object2 = ClientSessionsKt.getConverter($this$receiveDeserialized);
        if (object2 == null) {
            throw new WebsocketConverterNotFoundException("No converter was found for websocket", null, 2, null);
        }
        WebsocketContentConverter converter = object2;
        object2 = $this$receiveDeserialized;
        Charset charset = ContentConverterKt.suitableCharset$default($this$receiveDeserialized.getCall().getRequest().getHeaders(), null, 1, null);
        boolean $i$f$receiveDeserializedBase = false;
        ReceiveChannel<Frame> receiveChannel2 = $this$receiveDeserializedBase$iv.getIncoming();
        InlineMarker.mark(0);
        Object object3 = receiveChannel2.receive($completion);
        InlineMarker.mark(1);
        Frame frame$iv = (Frame)object3;
        if (!converter.isApplicable(frame$iv)) {
            throw new WebsocketDeserializeException("Converter doesn't support frame type " + frame$iv.getFrameType().name(), null, frame$iv, 2, null);
        }
        boolean $i$f$typeInfo = false;
        Intrinsics.reifiedOperationMarker(6, "T");
        KType kType$iv$iv = null;
        Type reifiedType$iv$iv = TypesJVMKt.getJavaType(kType$iv$iv);
        Intrinsics.reifiedOperationMarker(4, "T");
        TypeInfo typeInfo$iv = TypeInfoJvmKt.typeInfoImpl(reifiedType$iv$iv, Reflection.getOrCreateKotlinClass(Object.class), kType$iv$iv);
        InlineMarker.mark(0);
        Object object4 = converter.deserialize((Charset)charset$iv, typeInfo$iv, frame$iv, $completion);
        InlineMarker.mark(1);
        Object result$iv = object4;
        Intrinsics.reifiedOperationMarker(3, "T");
        if (result$iv instanceof Object) {
            object = result$iv;
        } else if (result$iv == null) {
            KType kType = typeInfo$iv.getKotlinType();
            boolean bl = kType != null ? kType.isMarkedNullable() : false;
            if (!bl) throw new WebsocketDeserializeException("Frame has null content", null, frame$iv, 2, null);
            object = null;
        } else {
            StringBuilder stringBuilder = new StringBuilder().append("Can't deserialize value : expected value of type ");
            Intrinsics.reifiedOperationMarker(4, "T");
            throw new WebsocketDeserializeException(stringBuilder.append(Reflection.getOrCreateKotlinClass(Object.class).getSimpleName()).append(", got ").append(Reflection.getOrCreateKotlinClass(result$iv.getClass()).getSimpleName()).toString(), null, frame$iv, 2, null);
        }
        Intrinsics.reifiedOperationMarker(1, "T");
        return object;
    }
}

