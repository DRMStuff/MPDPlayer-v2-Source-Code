/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.http.cio;

import io.ktor.http.cio.HttpHeadersMap;
import io.ktor.http.cio.HttpParserKt;
import io.ktor.http.cio.MultipartEvent;
import io.ktor.http.cio.MultipartKt;
import io.ktor.http.cio.internals.CharArrayBuilder;
import io.ktor.http.cio.internals.CharsKt;
import io.ktor.utils.io.ByteChannel;
import io.ktor.utils.io.ByteChannelKt;
import io.ktor.utils.io.ByteReadChannel;
import io.ktor.utils.io.ByteReadChannelJVMKt;
import io.ktor.utils.io.ByteWriteChannel;
import io.ktor.utils.io.ByteWriteChannelKt;
import io.ktor.utils.io.DelimitedKt;
import io.ktor.utils.io.LookAheadSession;
import io.ktor.utils.io.LookAheadSuspendSession;
import io.ktor.utils.io.charsets.CharsetJVMKt;
import io.ktor.utils.io.core.BytePacketBuilder;
import io.ktor.utils.io.core.ByteReadPacket;
import io.ktor.utils.io.core.OutputArraysJVMKt;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CompletableDeferred;
import kotlinx.coroutines.CompletableDeferredKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u0000\u0082\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\r\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a!\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\tH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\n\u001aW\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\"\u0010\u000f\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u00102\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0015\u001a\u0010\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0017\u001a\u00020\u0018H\u0007\u001a\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0002\u001a\u0010\u0010\u001d\u001a\u00020\u00012\u0006\u0010\u001b\u001a\u00020\u001cH\u0007\u001a\u0010\u0010\u001e\u001a\u00020\u00012\u0006\u0010\u001b\u001a\u00020\u001cH\u0000\u001a?\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\f0 2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010!\u001a\u00020\"2\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010#\u001a;\u0010$\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010!\u001a\u00020\"2\u0006\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010%\u001a;\u0010&\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010!\u001a\u00020\"2\u0006\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010%\u001a\u0019\u0010'\u001a\u00020\u00182\u0006\u0010\b\u001a\u00020\tH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(\u001a\u0019\u0010)\u001a\u00020\u00182\u0006\u0010\b\u001a\u00020\tH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(\u001a3\u0010*\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010!\u001a\u00020+2\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010,\u001a3\u0010-\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010!\u001a\u00020+2\b\b\u0002\u0010\u0014\u001a\u00020\fH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010,\u001a!\u0010.\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\tH\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\n\u001a\u0014\u0010/\u001a\u00020\u001a*\u00020\u00012\u0006\u00100\u001a\u00020\u0001H\u0002\u001a \u00101\u001a\b\u0012\u0004\u0012\u00020302*\u0002042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u0018\u001a/\u00101\u001a\b\u0012\u0004\u0012\u00020302*\u0002042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u001b\u001a\u00020\u001c2\b\u00105\u001a\u0004\u0018\u00010\f\u00a2\u0006\u0002\u00106\u001a1\u00101\u001a\b\u0012\u0004\u0012\u00020302*\u0002042\u0006\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\b\u00107\u001a\u0004\u0018\u00010\fH\u0007\u00a2\u0006\u0002\u00108\u001a\u001d\u00109\u001a\u00020\u0006*\u00020\t2\u0006\u0010:\u001a\u00020\u0001H\u0080@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010;\u001a\u001e\u0010<\u001a\u00020\u0006*\u00020\u00012\u0006\u0010=\u001a\u00020\u00012\b\b\u0002\u0010>\u001a\u00020\u001aH\u0002\u001a\u0014\u0010?\u001a\u00020\u001a*\u00020@2\u0006\u0010:\u001a\u00020\u0001H\u0002\u001a\u0014\u0010A\u001a\u00020\u001a*\u00020@2\u0006\u0010:\u001a\u00020\u0001H\u0002\u001a\u001d\u0010B\u001a\u00020\u0006*\u00020\t2\u0006\u0010:\u001a\u00020\u0001H\u0082@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010;\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006C"}, d2={"BoundaryTrailingBuffer", "Ljava/nio/ByteBuffer;", "CrLf", "PrefixChar", "", "boundary", "", "boundaryPrefixed", "input", "Lio/ktor/utils/io/ByteReadChannel;", "(Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "copyUntilBoundary", "", "name", "", "writeFully", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "", "limit", "(Ljava/lang/String;Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Lkotlin/jvm/functions/Function2;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "expectMultipart", "headers", "Lio/ktor/http/cio/HttpHeadersMap;", "findBoundary", "", "contentType", "", "parseBoundary", "parseBoundaryInternal", "parsePart", "Lkotlin/Pair;", "output", "Lio/ktor/utils/io/ByteWriteChannel;", "(Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Lio/ktor/utils/io/ByteWriteChannel;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "parsePartBody", "(Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Lio/ktor/utils/io/ByteWriteChannel;Lio/ktor/http/cio/HttpHeadersMap;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "parsePartBodyImpl", "parsePartHeaders", "(Lio/ktor/utils/io/ByteReadChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "parsePartHeadersImpl", "parsePreamble", "Lio/ktor/utils/io/core/BytePacketBuilder;", "(Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Lio/ktor/utils/io/core/BytePacketBuilder;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "parsePreambleImpl", "skipBoundary", "indexOfPartial", "sub", "parseMultipart", "Lkotlinx/coroutines/channels/ReceiveChannel;", "Lio/ktor/http/cio/MultipartEvent;", "Lkotlinx/coroutines/CoroutineScope;", "contentLength", "(Lkotlinx/coroutines/CoroutineScope;Lio/ktor/utils/io/ByteReadChannel;Ljava/lang/CharSequence;Ljava/lang/Long;)Lkotlinx/coroutines/channels/ReceiveChannel;", "totalLength", "(Lkotlinx/coroutines/CoroutineScope;Ljava/nio/ByteBuffer;Lio/ktor/utils/io/ByteReadChannel;Ljava/lang/Long;)Lkotlinx/coroutines/channels/ReceiveChannel;", "skipDelimiterOrEof", "delimiter", "(Lio/ktor/utils/io/ByteReadChannel;Ljava/nio/ByteBuffer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "startsWith", "prefix", "prefixSkip", "startsWithDelimiter", "Lio/ktor/utils/io/LookAheadSession;", "tryEnsureDelimiter", "trySkipDelimiterSuspend", "ktor-http-cio"})
public final class MultipartKt {
    @NotNull
    private static final ByteBuffer CrLf;
    @NotNull
    private static final ByteBuffer BoundaryTrailingBuffer;
    private static final byte PrefixChar = 45;

    @Deprecated(message="This is going to be removed. Use parseMultipart instead.", level=DeprecationLevel.ERROR)
    @Nullable
    public static final Object parsePreamble(@NotNull ByteBuffer boundaryPrefixed, @NotNull ByteReadChannel input2, @NotNull BytePacketBuilder output2, long limit, @NotNull Continuation<? super Long> $completion) {
        return MultipartKt.parsePreambleImpl(boundaryPrefixed, input2, output2, limit, $completion);
    }

    public static /* synthetic */ Object parsePreamble$default(ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, BytePacketBuilder bytePacketBuilder, long l, Continuation continuation2, int n, Object object) {
        if ((n & 8) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.parsePreamble(byteBuffer, byteReadChannel, bytePacketBuilder, l, continuation2);
    }

    private static final Object parsePreambleImpl(ByteBuffer boundaryPrefixed, ByteReadChannel input2, BytePacketBuilder output2, long limit, Continuation<? super Long> $completion) {
        return MultipartKt.copyUntilBoundary("preamble/prologue", boundaryPrefixed, input2, (Function2<? super ByteBuffer, ? super Continuation<? super Unit>, ? extends Object>)new Function2<ByteBuffer, Continuation<? super Unit>, Object>(output2, null){
            int label;
            /* synthetic */ Object L$0;
            final /* synthetic */ BytePacketBuilder $output;
            {
                this.$output = $output;
                super(2, $completion);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        ByteBuffer it = (ByteBuffer)this.L$0;
                        OutputArraysJVMKt.writeFully(this.$output, it);
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ByteBuffer, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ByteBuffer p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, limit, $completion);
    }

    static /* synthetic */ Object parsePreambleImpl$default(ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, BytePacketBuilder bytePacketBuilder, long l, Continuation continuation2, int n, Object object) {
        if ((n & 8) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.parsePreambleImpl(byteBuffer, byteReadChannel, bytePacketBuilder, l, continuation2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="This is going to be removed. Use parseMultipart instead.", level=DeprecationLevel.ERROR)
    @Nullable
    public static final Object parsePart(@NotNull ByteBuffer var0, @NotNull ByteReadChannel var1_1, @NotNull ByteWriteChannel var2_2, long var3_3, @NotNull Continuation<? super Pair<HttpHeadersMap, Long>> var5_4) {
        if (!(var5_4 instanceof parsePart.1)) ** GOTO lbl-1000
        var10_5 = var5_4;
        if ((var10_5.label & -2147483648) != 0) {
            var10_5.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super parsePart.1>)var5_4){
                Object L$0;
                Object L$1;
                Object L$2;
                long J$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return MultipartKt.parsePart(null, null, null, 0L, this);
                }
            };
        }
        $result = $continuation.result;
        var11_7 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $continuation.L$0 = boundaryPrefixed;
                $continuation.L$1 = input;
                $continuation.L$2 = output;
                $continuation.J$0 = limit;
                $continuation.label = 1;
                v0 = MultipartKt.parsePartHeadersImpl(input, $continuation);
                if (v0 == var11_7) {
                    return var11_7;
                }
                ** GOTO lbl28
            }
            case 1: {
                limit = $continuation.J$0;
                output = (ByteWriteChannel)$continuation.L$2;
                input = (ByteReadChannel)$continuation.L$1;
                boundaryPrefixed = (ByteBuffer)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl28:
                // 2 sources

                headers = (HttpHeadersMap)v0;
                $continuation.L$0 = headers;
                $continuation.L$1 = null;
                $continuation.L$2 = null;
                $continuation.label = 2;
                v1 = MultipartKt.parsePartBodyImpl(boundaryPrefixed, input, output, headers, limit, $continuation);
                ** if (v1 != var11_7) goto lbl38
lbl37:
                // 1 sources

                return var11_7;
lbl38:
                // 1 sources

                ** GOTO lbl45
            }
            case 2: {
                headers = (HttpHeadersMap)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v1 = $result;
lbl45:
                    // 2 sources

                    size = ((Number)v1).longValue();
                    return new Pair<HttpHeadersMap, Long>(headers, Boxing.boxLong(size));
                }
                catch (Throwable t) {
                    headers.release();
                    throw t;
                }
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    public static /* synthetic */ Object parsePart$default(ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, ByteWriteChannel byteWriteChannel, long l, Continuation continuation2, int n, Object object) {
        if ((n & 8) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.parsePart(byteBuffer, byteReadChannel, byteWriteChannel, l, continuation2);
    }

    @Deprecated(message="This is going to be removed. Use parseMultipart instead.", level=DeprecationLevel.ERROR)
    @Nullable
    public static final Object parsePartHeaders(@NotNull ByteReadChannel input2, @NotNull Continuation<? super HttpHeadersMap> $completion) {
        return MultipartKt.parsePartHeadersImpl(input2, $completion);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static final Object parsePartHeadersImpl(ByteReadChannel var0, Continuation<? super HttpHeadersMap> var1_1) {
        if (!(var1_1 instanceof parsePartHeadersImpl.1)) ** GOTO lbl-1000
        var5_2 = var1_1;
        if ((var5_2.label & -2147483648) != 0) {
            var5_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super parsePartHeadersImpl.1>)var1_1){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return MultipartKt.access$parsePartHeadersImpl(null, this);
                }
            };
        }
        $result = $continuation.result;
        var6_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                builder = new CharArrayBuilder(null, 1, null);
                $continuation.L$0 = builder;
                $continuation.label = 1;
                v0 = HttpParserKt.parseHeaders$default(input, builder, null, $continuation, 4, null);
                ** if (v0 != var6_4) goto lbl20
lbl19:
                // 1 sources

                return var6_4;
lbl20:
                // 1 sources

                ** GOTO lbl27
            }
            case 1: {
                builder = (CharArrayBuilder)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl27:
                    // 2 sources

                    v1 = (HttpHeadersMap)v0;
                    if (v1 != null) return v1;
                    throw new EOFException("Failed to parse multipart headers: unexpected end of stream");
                }
                catch (Throwable t) {
                    builder.release();
                    throw t;
                }
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="This is going to be removed. Use parseMultipart instead.", level=DeprecationLevel.ERROR)
    @Nullable
    public static final Object parsePartBody(@NotNull ByteBuffer boundaryPrefixed, @NotNull ByteReadChannel input2, @NotNull ByteWriteChannel output2, @NotNull HttpHeadersMap headers2, long limit, @NotNull Continuation<? super Long> $completion) {
        return MultipartKt.parsePartBodyImpl(boundaryPrefixed, input2, output2, headers2, limit, $completion);
    }

    public static /* synthetic */ Object parsePartBody$default(ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, ByteWriteChannel byteWriteChannel, HttpHeadersMap httpHeadersMap, long l, Continuation continuation2, int n, Object object) {
        if ((n & 0x10) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.parsePartBody(byteBuffer, byteReadChannel, byteWriteChannel, httpHeadersMap, l, continuation2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static final Object parsePartBodyImpl(ByteBuffer var0, ByteReadChannel var1_1, ByteWriteChannel var2_2, HttpHeadersMap var3_3, long var4_4, Continuation<? super Long> var6_5) {
        if (!(var6_5 instanceof parsePartBodyImpl.1)) ** GOTO lbl-1000
        var11_6 = var6_5;
        if ((var11_6.label & -2147483648) != 0) {
            var11_6.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super parsePartBodyImpl.1>)var6_5){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return MultipartKt.access$parsePartBodyImpl(null, null, null, null, 0L, this);
                }
            };
        }
        $result = $continuation.result;
        var12_8 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                v0 = headers.get("Content-Length");
                v1 = cl = v0 != null ? Boxing.boxLong(CharsKt.parseDecLong(v0)) : null;
                if (cl == null) ** GOTO lbl29
                if (cl > limit) {
                    throw new IOException("Multipart part content length limit of " + (long)limit + " exceeded (actual size is " + cl + ')');
                }
                $continuation.L$0 = output;
                $continuation.label = 1;
                v2 = ByteReadChannelJVMKt.copyTo((ByteReadChannel)input, output, cl, $continuation);
                if (v2 == var12_8) {
                    return var12_8;
                }
                ** GOTO lbl27
            }
            case 1: {
                output = (ByteWriteChannel)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v2 = $result;
lbl27:
                // 2 sources

                v3 = ((Number)v2).longValue();
                ** GOTO lbl40
            }
lbl29:
            // 1 sources

            $continuation.L$0 = output;
            $continuation.label = 2;
            v4 = MultipartKt.copyUntilBoundary("part", boundaryPrefixed, (ByteReadChannel)input, (Function2<? super ByteBuffer, ? super Continuation<? super Unit>, ? extends Object>)new Function2<ByteBuffer, Continuation<? super Unit>, Object>(output, null){
                int label;
                /* synthetic */ Object L$0;
                final /* synthetic */ ByteWriteChannel $output;
                {
                    this.$output = $output;
                    super(2, $completion);
                }

                /*
                 * WARNING - void declaration
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                @Nullable
                public final Object invokeSuspend(@NotNull Object object) {
                    Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0: {
                            ResultKt.throwOnFailure(object);
                            ByteBuffer it = (ByteBuffer)this.L$0;
                            this.label = 1;
                            Object object3 = this.$output.writeFully(it, (Continuation<? super Unit>)this);
                            if (object3 != object2) return Unit.INSTANCE;
                            return object2;
                        }
                        case 1: {
                            void $result;
                            ResultKt.throwOnFailure($result);
                            Object object3 = $result;
                            return Unit.INSTANCE;
                        }
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }

                @NotNull
                public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                    Function2<ByteBuffer, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                    function2.L$0 = value;
                    return (Continuation)((Object)function2);
                }

                @Nullable
                public final Object invoke(@NotNull ByteBuffer p1, @Nullable Continuation<? super Unit> p2) {
                    return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                }
            }, (long)limit, $continuation);
            if (v4 == var12_8) {
                return var12_8;
            }
            ** GOTO lbl39
            case 2: {
                output = (ByteWriteChannel)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v4 = $result;
lbl39:
                // 2 sources

                v3 = ((Number)v4).longValue();
lbl40:
                // 2 sources

                size = v3;
                output.flush();
                return Boxing.boxLong(size);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    static /* synthetic */ Object parsePartBodyImpl$default(ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, ByteWriteChannel byteWriteChannel, HttpHeadersMap httpHeadersMap, long l, Continuation continuation2, int n, Object object) {
        if ((n & 0x10) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.parsePartBodyImpl(byteBuffer, byteReadChannel, byteWriteChannel, httpHeadersMap, l, continuation2);
    }

    @Deprecated(message="This is going to be removed. Use parseMultipart instead.", level=DeprecationLevel.ERROR)
    @Nullable
    public static final Object boundary(@NotNull ByteBuffer boundaryPrefixed, @NotNull ByteReadChannel input2, @NotNull Continuation<? super Boolean> $completion) {
        return MultipartKt.skipBoundary(boundaryPrefixed, input2, $completion);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static final Object skipBoundary(ByteBuffer var0, ByteReadChannel var1_1, Continuation<? super Boolean> var2_2) {
        if (!(var2_2 instanceof skipBoundary.1)) ** GOTO lbl-1000
        var5_3 = var2_2;
        if ((var5_3.label & -2147483648) != 0) {
            var5_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super skipBoundary.1>)var2_2){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return MultipartKt.access$skipBoundary(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var6_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $continuation.L$0 = input;
                $continuation.label = 1;
                v0 = MultipartKt.skipDelimiterOrEof(input, boundaryPrefixed, $continuation);
                if (v0 == var6_5) {
                    return var6_5;
                }
                ** GOTO lbl22
            }
            case 1: {
                input = (ByteReadChannel)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl22:
                // 2 sources

                if (!((Boolean)v0).booleanValue()) {
                    return Boxing.boxBoolean(true);
                }
                result = new Ref.BooleanRef();
                $continuation.L$0 = result;
                $continuation.label = 2;
                v1 = input.lookAheadSuspend((Function2)new Function2<LookAheadSuspendSession, Continuation<? super Unit>, Object>(result, null){
                    int label;
                    private /* synthetic */ Object L$0;
                    final /* synthetic */ Ref.BooleanRef $result;
                    {
                        this.$result = $result;
                        super(2, $completion);
                    }

                    /*
                     * Unable to fully structure code
                     * Enabled aggressive block sorting
                     * Lifted jumps to return sites
                     */
                    @Nullable
                    public final Object invokeSuspend(@NotNull Object var1_1) {
                        var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0: {
                                ResultKt.throwOnFailure(var1_1);
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                this.L$0 = $this$lookAheadSuspend;
                                this.label = 1;
                                v0 = $this$lookAheadSuspend.awaitAtLeast(1, this);
                                if (v0 == var5_2) {
                                    return var5_2;
                                }
                                ** GOTO lbl16
                            }
                            case 1: {
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                ResultKt.throwOnFailure($result);
                                v0 = $result;
lbl16:
                                // 2 sources

                                v1 = $this$lookAheadSuspend.request(0, 1);
                                if (v1 == null) {
                                    throw new IOException("Failed to pass multipart boundary: unexpected end of stream");
                                }
                                buffer = v1;
                                if (buffer.get(buffer.position()) != 45) {
                                    return Unit.INSTANCE;
                                }
                                if (buffer.remaining() > 1 && buffer.get(buffer.position() + 1) == 45) {
                                    this.$result.element = true;
                                    $this$lookAheadSuspend.consumed(2);
                                    return Unit.INSTANCE;
                                }
                                this.L$0 = $this$lookAheadSuspend;
                                this.label = 2;
                                v2 = $this$lookAheadSuspend.awaitAtLeast(2, this);
                                if (v2 == var5_2) {
                                    return var5_2;
                                }
                                ** GOTO lbl36
                            }
                            case 2: {
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                ResultKt.throwOnFailure($result);
                                v2 = $result;
lbl36:
                                // 2 sources

                                v3 = $this$lookAheadSuspend.request(1, 1);
                                if (v3 == null) {
                                    throw new IOException("Failed to pass multipart boundary: unexpected end of stream");
                                }
                                attempt2buffer = v3;
                                if (attempt2buffer.get(attempt2buffer.position()) != 45) return Unit.INSTANCE;
                                this.$result.element = true;
                                $this$lookAheadSuspend.consumed(2);
                                return Unit.INSTANCE;
                            }
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }

                    @NotNull
                    public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                        Function2<LookAheadSuspendSession, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                        function2.L$0 = value;
                        return (Continuation)((Object)function2);
                    }

                    @Nullable
                    public final Object invoke(@NotNull LookAheadSuspendSession p1, @Nullable Continuation<? super Unit> p2) {
                        return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                    }
                }, $continuation);
                v2 = v1;
                if (v1 != var6_5) return Boxing.boxBoolean(result.element);
                return var6_5;
            }
            case 2: {
                result = (Ref.BooleanRef)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v2 = $result;
                return Boxing.boxBoolean(result.element);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="This is going to be removed.", level=DeprecationLevel.ERROR)
    public static final boolean expectMultipart(@NotNull HttpHeadersMap headers2) {
        Intrinsics.checkNotNullParameter(headers2, "headers");
        CharSequence charSequence = headers2.get("Content-Type");
        return charSequence != null ? StringsKt.startsWith$default(charSequence, (CharSequence)"multipart/", false, 2, null) : false;
    }

    @NotNull
    public static final ReceiveChannel<MultipartEvent> parseMultipart(@NotNull CoroutineScope $this$parseMultipart, @NotNull ByteReadChannel input2, @NotNull HttpHeadersMap headers2) {
        Intrinsics.checkNotNullParameter($this$parseMultipart, "<this>");
        Intrinsics.checkNotNullParameter(input2, "input");
        Intrinsics.checkNotNullParameter(headers2, "headers");
        CharSequence charSequence = headers2.get("Content-Type");
        if (charSequence == null) {
            throw new IOException("Failed to parse multipart: no Content-Type header");
        }
        CharSequence contentType2 = charSequence;
        CharSequence charSequence2 = headers2.get("Content-Length");
        Long contentLength = charSequence2 != null ? Long.valueOf(CharsKt.parseDecLong(charSequence2)) : null;
        return MultipartKt.parseMultipart($this$parseMultipart, input2, contentType2, contentLength);
    }

    @NotNull
    public static final ReceiveChannel<MultipartEvent> parseMultipart(@NotNull CoroutineScope $this$parseMultipart, @NotNull ByteReadChannel input2, @NotNull CharSequence contentType2, @Nullable Long contentLength) {
        Intrinsics.checkNotNullParameter($this$parseMultipart, "<this>");
        Intrinsics.checkNotNullParameter(input2, "input");
        Intrinsics.checkNotNullParameter(contentType2, "contentType");
        if (!StringsKt.startsWith$default(contentType2, (CharSequence)"multipart/", false, 2, null)) {
            throw new IOException("Failed to parse multipart: Content-Type should be multipart/* but it is " + contentType2);
        }
        ByteBuffer boundaryBytes = MultipartKt.parseBoundaryInternal(contentType2);
        return MultipartKt.parseMultipart($this$parseMultipart, boundaryBytes, input2, contentLength);
    }

    @Deprecated(message="This is going to be removed. Use parseMultipart(contentType) instead.", level=DeprecationLevel.ERROR)
    @NotNull
    public static final ReceiveChannel<MultipartEvent> parseMultipart(@NotNull CoroutineScope $this$parseMultipart, @NotNull ByteBuffer boundaryPrefixed, @NotNull ByteReadChannel input2, @Nullable Long totalLength) {
        Intrinsics.checkNotNullParameter($this$parseMultipart, "<this>");
        Intrinsics.checkNotNullParameter(boundaryPrefixed, "boundaryPrefixed");
        Intrinsics.checkNotNullParameter(input2, "input");
        return ProduceKt.produce$default($this$parseMultipart, null, 0, new Function2<ProducerScope<? super MultipartEvent>, Continuation<? super Unit>, Object>(input2, boundaryPrefixed, totalLength, null){
            Object L$1;
            Object L$2;
            Object L$3;
            Object L$4;
            long J$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ByteReadChannel $input;
            final /* synthetic */ ByteBuffer $boundaryPrefixed;
            final /* synthetic */ Long $totalLength;
            {
                this.$input = $input;
                this.$boundaryPrefixed = $boundaryPrefixed;
                this.$totalLength = $totalLength;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var15_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        readBeforeParse = this.$input.getTotalBytesRead();
                        v0 = this.$boundaryPrefixed.duplicate();
                        Intrinsics.checkNotNull(v0);
                        $this$invokeSuspend_u24lambda_u2d0 = var6_5 = v0;
                        $i$a$-apply-MultipartKt$parseMultipart$1$firstBoundary$1 = false;
                        $this$invokeSuspend_u24lambda_u2d0.position(2);
                        firstBoundary = var6_5;
                        preamble = new BytePacketBuilder(null, 1, null);
                        this.L$0 = $this$produce;
                        this.L$1 = firstBoundary;
                        this.L$2 = preamble;
                        this.J$0 = readBeforeParse;
                        this.label = 1;
                        v1 = MultipartKt.access$parsePreambleImpl(firstBoundary, this.$input, preamble, 8192L, this);
                        if (v1 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl32
                    }
                    case 1: {
                        readBeforeParse = this.J$0;
                        preamble = (BytePacketBuilder)this.L$2;
                        firstBoundary = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl32:
                        // 2 sources

                        if (preamble.getSize() > 0) {
                            this.L$0 = $this$produce;
                            this.L$1 = firstBoundary;
                            this.L$2 = null;
                            this.J$0 = readBeforeParse;
                            this.label = 2;
                            v2 = $this$produce.send(new MultipartEvent.Preamble(preamble.build()), this);
                            if (v2 == var15_2) {
                                return var15_2;
                            }
                        }
                        ** GOTO lbl48
                    }
                    case 2: {
                        readBeforeParse = this.J$0;
                        firstBoundary = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl48:
                        // 2 sources

                        this.L$0 = $this$produce;
                        this.L$1 = null;
                        this.L$2 = null;
                        this.J$0 = readBeforeParse;
                        this.label = 3;
                        v3 = MultipartKt.access$skipBoundary(firstBoundary, this.$input, this);
                        if (v3 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl62
                    }
                    case 3: {
                        readBeforeParse = this.J$0;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
lbl62:
                        // 2 sources

                        if (((Boolean)v3).booleanValue()) {
                            return Unit.INSTANCE;
                        }
                        trailingBuffer = MultipartKt.access$getBoundaryTrailingBuffer$p().duplicate();
                        ** GOTO lbl213
                    }
                    case 4: {
                        readBeforeParse = this.J$0;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v4 = $result;
                        while (true) {
                            v5 = MultipartKt.access$getCrLf$p();
                            Intrinsics.checkNotNullExpressionValue(trailingBuffer, "trailingBuffer");
                            this.L$0 = $this$produce;
                            this.L$1 = trailingBuffer;
                            this.J$0 = readBeforeParse;
                            this.label = 5;
                            v6 = DelimitedKt.readUntilDelimiter(this.$input, v5, trailingBuffer, this);
                            if (v6 == var15_2) {
                                return var15_2;
                            }
                            ** GOTO lbl89
                            break;
                        }
                    }
                    case 5: {
                        readBeforeParse = this.J$0;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v6 = $result;
lbl89:
                        // 2 sources

                        if (((Number)v6).intValue() != 0) {
                            throw new IOException("Failed to parse multipart: boundary line is too long");
                        }
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.J$0 = readBeforeParse;
                        this.label = 6;
                        v7 = DelimitedKt.skipDelimiter(this.$input, MultipartKt.access$getCrLf$p(), this);
                        if (v7 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl105
                    }
                    case 6: {
                        readBeforeParse = this.J$0;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v7 = $result;
lbl105:
                        // 2 sources

                        body = ByteChannelKt.ByteChannel$default(false, 1, null);
                        headers = CompletableDeferredKt.CompletableDeferred$default(null, 1, null);
                        part = new MultipartEvent.MultipartPart(headers, body);
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.L$2 = body;
                        this.L$3 = headers;
                        this.J$0 = readBeforeParse;
                        this.label = 7;
                        v8 = $this$produce.send(part, this);
                        if (v8 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl126
                    }
                    case 7: {
                        readBeforeParse = this.J$0;
                        headers = (CompletableDeferred)this.L$3;
                        body = (ByteChannel)this.L$2;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v8 = $result;
lbl126:
                        // 2 sources

                        hh = null;
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.L$2 = body;
                        this.L$3 = headers;
                        this.J$0 = readBeforeParse;
                        this.label = 8;
                        v9 = MultipartKt.access$parsePartHeadersImpl(this.$input, this);
                        ** if (v9 != var15_2) goto lbl138
lbl137:
                        // 1 sources

                        return var15_2;
lbl138:
                        // 1 sources

                        ** GOTO lbl150
                    }
                    case 8: {
                        readBeforeParse = this.J$0;
                        hh = null;
                        headers = (CompletableDeferred)this.L$3;
                        body = (ByteChannel)this.L$2;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v9 = $result;
lbl150:
                        // 2 sources

                        if (!headers.complete(hh = (HttpHeadersMap)v9)) {
                            hh.release();
                            throw new CancellationException("Multipart processing has been cancelled");
                        }
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.L$2 = body;
                        this.L$3 = headers;
                        this.L$4 = hh;
                        this.J$0 = readBeforeParse;
                        this.label = 9;
                        v10 = MultipartKt.parsePartBodyImpl$default(this.$boundaryPrefixed, this.$input, body, hh, 0L, this, 16, null);
                        ** if (v10 != var15_2) goto lbl163
lbl162:
                        // 1 sources

                        return var15_2;
lbl163:
                        // 1 sources

                        ** GOTO lbl184
                    }
                    case 9: {
                        readBeforeParse = this.J$0;
                        hh = (HttpHeadersMap)this.L$4;
                        headers = (CompletableDeferred)this.L$3;
                        body = (ByteChannel)this.L$2;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        try {
                            ResultKt.throwOnFailure($result);
                            v10 = $result;
                        }
                        catch (Throwable t) {
                            if (headers.completeExceptionally(t)) {
                                v11 = hh;
                                if (v11 != null) {
                                    v11.release();
                                }
                            }
                            body.close(t);
                            throw t;
                        }
lbl184:
                        // 2 sources

                        ByteWriteChannelKt.close(body);
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.L$2 = null;
                        this.L$3 = null;
                        this.L$4 = null;
                        this.J$0 = readBeforeParse;
                        this.label = 10;
                        v12 = MultipartKt.access$skipBoundary(this.$boundaryPrefixed, this.$input, this);
                        if (v12 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl203
                    }
                    case 10: {
                        readBeforeParse = this.J$0;
                        trailingBuffer = (ByteBuffer)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v12 = $result;
lbl203:
                        // 2 sources

                        if (!((Boolean)v12).booleanValue()) ** GOTO lbl213
                        if (this.$input.getAvailableForRead() != 0) {
                            this.L$0 = $this$produce;
                            this.L$1 = null;
                            this.J$0 = readBeforeParse;
                            this.label = 11;
                            v13 = DelimitedKt.skipDelimiter(this.$input, MultipartKt.access$getCrLf$p(), this);
                            if (v13 == var15_2) {
                                return var15_2;
                            }
                        }
                        ** GOTO lbl226
lbl213:
                        // 2 sources

                        v14 = MultipartKt.access$getCrLf$p();
                        Intrinsics.checkNotNullExpressionValue(trailingBuffer, "trailingBuffer");
                        this.L$0 = $this$produce;
                        this.L$1 = trailingBuffer;
                        this.J$0 = readBeforeParse;
                        this.label = 4;
                        if ((v4 = DelimitedKt.readUntilDelimiter(this.$input, v14, trailingBuffer, this)) != var15_2) ** continue;
                        return var15_2;
                    }
                    case 11: {
                        readBeforeParse = this.J$0;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v13 = $result;
lbl226:
                        // 2 sources

                        if (this.$totalLength == null) ** GOTO lbl255
                        consumedExceptEpilogue = this.$input.getTotalBytesRead() - readBeforeParse;
                        size = this.$totalLength - consumedExceptEpilogue;
                        if (size > 0x7FFFFFFFL) {
                            throw new IOException("Failed to parse multipart: prologue is too long");
                        }
                        if (size <= 0L) return Unit.INSTANCE;
                        var13_17 = $this$produce;
                        this.L$0 = var13_17;
                        this.L$1 = null;
                        this.label = 12;
                        v15 = this.$input.readPacket((int)size, this);
                        if (v15 == var15_2) {
                            return var15_2;
                        }
                        ** GOTO lbl244
                    }
                    case 12: {
                        var13_17 = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v15 = $result;
lbl244:
                        // 2 sources

                        var14_18 = (ByteReadPacket)v15;
                        this.L$0 = null;
                        this.label = 13;
                        v16 = var13_17.send(new MultipartEvent.Epilogue(var14_18), this);
                        v17 = v16;
                        if (v16 != var15_2) return Unit.INSTANCE;
                        return var15_2;
                    }
                    case 13: {
                        ResultKt.throwOnFailure($result);
                        v17 = $result;
                        return Unit.INSTANCE;
                    }
lbl255:
                    // 1 sources

                    this.L$0 = $this$produce;
                    this.L$1 = null;
                    this.label = 14;
                    v18 = ByteReadChannel.DefaultImpls.readRemaining$default(this.$input, 0L, this, 1, null);
                    if (v18 == var15_2) {
                        return var15_2;
                    }
                    ** GOTO lbl266
                    case 14: {
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v18 = $result;
lbl266:
                        // 2 sources

                        $this$isNotEmpty$iv = epilogueContent = (ByteReadPacket)v18;
                        $i$f$isNotEmpty = false;
                        if ($this$isNotEmpty$iv.getEndOfInput() == false == false) return Unit.INSTANCE;
                        this.L$0 = null;
                        this.label = 15;
                        v19 = $this$produce.send(new MultipartEvent.Epilogue(epilogueContent), this);
                        v20 = v19;
                        if (v19 != var15_2) return Unit.INSTANCE;
                        return var15_2;
                    }
                    case 15: {
                        ResultKt.throwOnFailure($result);
                        v20 = $result;
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super MultipartEvent>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super MultipartEvent> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 3, null);
    }

    /*
     * Exception decompiling
     */
    private static final Object copyUntilBoundary(String var0, ByteBuffer var1_1, ByteReadChannel var2_2, Function2<? super ByteBuffer, ? super Continuation<? super Unit>, ? extends Object> var3_3, long var4_4, Continuation<? super Long> var6_5) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [4[CASE]], but top level block is 0[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    static /* synthetic */ Object copyUntilBoundary$default(String string, ByteBuffer byteBuffer, ByteReadChannel byteReadChannel, Function2 function2, long l, Continuation continuation2, int n, Object object) {
        if ((n & 0x10) != 0) {
            l = Long.MAX_VALUE;
        }
        return MultipartKt.copyUntilBoundary(string, byteBuffer, byteReadChannel, function2, l, continuation2);
    }

    private static final int findBoundary(CharSequence contentType2) {
        int state2 = 0;
        int paramNameCount = 0;
        int n = contentType2.length();
        block7: for (int i = 0; i < n; ++i) {
            char ch2 = contentType2.charAt(i);
            switch (state2) {
                case 0: {
                    if (ch2 != ';') continue block7;
                    state2 = 1;
                    paramNameCount = 0;
                    continue block7;
                }
                case 1: {
                    if (ch2 == '=') {
                        state2 = 2;
                        continue block7;
                    }
                    if (ch2 == ';') {
                        paramNameCount = 0;
                        continue block7;
                    }
                    if (ch2 == ',') {
                        state2 = 0;
                        continue block7;
                    }
                    if (ch2 == ' ') continue block7;
                    if (paramNameCount == 0 && StringsKt.startsWith(contentType2, (CharSequence)"boundary=", i, true)) {
                        return i;
                    }
                    ++paramNameCount;
                    continue block7;
                }
                case 2: {
                    char c = ch2;
                    if (c == '\"') {
                        state2 = 3;
                        continue block7;
                    }
                    if (c == ',') {
                        state2 = 0;
                        continue block7;
                    }
                    if (c != ';') continue block7;
                    state2 = 1;
                    paramNameCount = 0;
                    continue block7;
                }
                case 3: {
                    if (ch2 == '\"') {
                        state2 = 1;
                        paramNameCount = 0;
                        continue block7;
                    }
                    if (ch2 != '\\') continue block7;
                    state2 = 4;
                    continue block7;
                }
                case 4: {
                    state2 = 3;
                }
            }
        }
        return -1;
    }

    @Deprecated(message="This is going to become internal. Use parseMultipart instead or file a ticket explaining why do you need this function.", level=DeprecationLevel.ERROR)
    @NotNull
    public static final ByteBuffer parseBoundary(@NotNull CharSequence contentType2) {
        Intrinsics.checkNotNullParameter(contentType2, "contentType");
        return MultipartKt.parseBoundaryInternal(contentType2);
    }

    /*
     * Enabled aggressive block sorting
     */
    @NotNull
    public static final ByteBuffer parseBoundaryInternal(@NotNull CharSequence contentType2) {
        Intrinsics.checkNotNullParameter(contentType2, "contentType");
        int boundaryParameter = MultipartKt.findBoundary(contentType2);
        if (boundaryParameter == -1) {
            throw new IOException("Failed to parse multipart: Content-Type's boundary parameter is missing");
        }
        int boundaryStart = boundaryParameter + 9;
        ByteBuffer byteBuffer = ByteBuffer.allocate(74);
        Intrinsics.checkNotNullExpressionValue(byteBuffer, "allocate(74)");
        ByteBuffer boundaryBytes = byteBuffer;
        boundaryBytes.put((byte)13);
        boundaryBytes.put((byte)10);
        boundaryBytes.put((byte)45);
        boundaryBytes.put((byte)45);
        int state2 = 0;
        int n = contentType2.length();
        block6: for (int i = boundaryStart; i < n; ++i) {
            char ch2 = contentType2.charAt(i);
            int v = ch2 & 0xFFFF;
            if ((v & 0xFFFF) > 127) {
                StringBuilder stringBuilder = new StringBuilder().append("Failed to parse multipart: wrong boundary byte 0x");
                String string = Integer.toString(v, kotlin.text.CharsKt.checkRadix(16));
                Intrinsics.checkNotNullExpressionValue(string, "toString(this, checkRadix(radix))");
                throw new IOException(stringBuilder.append(string).append(" - should be 7bit character").toString());
            }
            switch (state2) {
                case 0: {
                    char c = ch2;
                    if (c == ' ') break;
                    if (c == '\"') {
                        state2 = 2;
                        break;
                    }
                    if (c == ';' ? true : c == ',') break block6;
                    state2 = 1;
                    boundaryBytes.put((byte)v);
                    break;
                }
                case 1: {
                    if (ch2 == ' ' || ch2 == ',' || ch2 == ';') break block6;
                    if (!boundaryBytes.hasRemaining()) {
                        throw new IOException("Failed to parse multipart: boundary shouldn't be longer than 70 characters");
                    }
                    boundaryBytes.put((byte)v);
                    break;
                }
                case 2: {
                    if (ch2 == '\\') {
                        state2 = 3;
                        break;
                    }
                    if (ch2 == '\"') break block6;
                    if (!boundaryBytes.hasRemaining()) {
                        throw new IOException("Failed to parse multipart: boundary shouldn't be longer than 70 characters");
                    }
                    boundaryBytes.put((byte)v);
                    break;
                }
                case 3: {
                    if (!boundaryBytes.hasRemaining()) {
                        throw new IOException("Failed to parse multipart: boundary shouldn't be longer than 70 characters");
                    }
                    boundaryBytes.put((byte)v);
                    state2 = 2;
                }
            }
        }
        boundaryBytes.flip();
        if (boundaryBytes.remaining() == 4) {
            throw new IOException("Empty multipart boundary is not allowed");
        }
        return boundaryBytes;
    }

    @Nullable
    public static final Object skipDelimiterOrEof(@NotNull ByteReadChannel $this$skipDelimiterOrEof, @NotNull ByteBuffer delimiter, @NotNull Continuation<? super Boolean> $completion) {
        if (!delimiter.hasRemaining()) {
            String string = "Failed requirement.";
            throw new IllegalArgumentException(string.toString());
        }
        if (!(delimiter.remaining() <= 8192)) {
            boolean bl = false;
            String string = "Delimiter of " + delimiter.remaining() + " bytes is too long: at most 8192 bytes could be checked";
            throw new IllegalArgumentException(string.toString());
        }
        Ref.BooleanRef found = new Ref.BooleanRef();
        $this$skipDelimiterOrEof.lookAhead((Function1)new Function1<LookAheadSession, Unit>(found, delimiter){
            final /* synthetic */ Ref.BooleanRef $found;
            final /* synthetic */ ByteBuffer $delimiter;
            {
                this.$found = $found;
                this.$delimiter = $delimiter;
                super(1);
            }

            public final void invoke(@NotNull LookAheadSession $this$lookAhead) {
                Intrinsics.checkNotNullParameter($this$lookAhead, "$this$lookAhead");
                this.$found.element = MultipartKt.access$tryEnsureDelimiter($this$lookAhead, this.$delimiter) == this.$delimiter.remaining();
            }
        });
        if (found.element) {
            return Boxing.boxBoolean(true);
        }
        return MultipartKt.trySkipDelimiterSuspend($this$skipDelimiterOrEof, delimiter, $completion);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static final Object trySkipDelimiterSuspend(ByteReadChannel var0, ByteBuffer var1_1, Continuation<? super Boolean> var2_2) {
        if (!(var2_2 instanceof trySkipDelimiterSuspend.1)) ** GOTO lbl-1000
        var5_3 = var2_2;
        if ((var5_3.label & -2147483648) != 0) {
            var5_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super trySkipDelimiterSuspend.1>)var2_2){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return MultipartKt.access$trySkipDelimiterSuspend(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var6_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                result = new Ref.BooleanRef();
                result.element = true;
                $continuation.L$0 = result;
                $continuation.label = 1;
                v0 = $this$trySkipDelimiterSuspend.lookAheadSuspend((Function2)new Function2<LookAheadSuspendSession, Continuation<? super Unit>, Object>((ByteBuffer)delimiter, result, null){
                    int label;
                    private /* synthetic */ Object L$0;
                    final /* synthetic */ ByteBuffer $delimiter;
                    final /* synthetic */ Ref.BooleanRef $result;
                    {
                        this.$delimiter = $delimiter;
                        this.$result = $result;
                        super(2, $completion);
                    }

                    /*
                     * Unable to fully structure code
                     * Enabled aggressive block sorting
                     * Lifted jumps to return sites
                     */
                    @Nullable
                    public final Object invokeSuspend(@NotNull Object var1_1) {
                        var3_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0: {
                                ResultKt.throwOnFailure(var1_1);
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                this.L$0 = $this$lookAheadSuspend;
                                this.label = 1;
                                v0 = $this$lookAheadSuspend.awaitAtLeast(this.$delimiter.remaining(), this);
                                if (v0 == var3_2) {
                                    return var3_2;
                                }
                                ** GOTO lbl16
                            }
                            case 1: {
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                ResultKt.throwOnFailure($result);
                                v0 = $result;
lbl16:
                                // 2 sources

                                if (((Boolean)v0).booleanValue()) ** GOTO lbl30
                                this.L$0 = $this$lookAheadSuspend;
                                this.label = 2;
                                v1 = $this$lookAheadSuspend.awaitAtLeast(1, this);
                                if (v1 == var3_2) {
                                    return var3_2;
                                }
                                ** GOTO lbl27
                            }
                            case 2: {
                                $this$lookAheadSuspend = (LookAheadSuspendSession)this.L$0;
                                ResultKt.throwOnFailure($result);
                                v1 = $result;
lbl27:
                                // 2 sources

                                if (!((Boolean)v1).booleanValue()) {
                                    this.$result.element = false;
                                    return Unit.INSTANCE;
                                }
lbl30:
                                // 3 sources

                                if (MultipartKt.access$tryEnsureDelimiter($this$lookAheadSuspend, this.$delimiter) == this.$delimiter.remaining()) return Unit.INSTANCE;
                                throw new IOException("Broken delimiter occurred");
                            }
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }

                    @NotNull
                    public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                        Function2<LookAheadSuspendSession, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                        function2.L$0 = value;
                        return (Continuation)((Object)function2);
                    }

                    @Nullable
                    public final Object invoke(@NotNull LookAheadSuspendSession p1, @Nullable Continuation<? super Unit> p2) {
                        return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                    }
                }, $continuation);
                v1 = v0;
                if (v0 != var6_5) return Boxing.boxBoolean(result.element);
                return var6_5;
            }
            case 1: {
                result = (Ref.BooleanRef)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v1 = $result;
                return Boxing.boxBoolean(result.element);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    private static final int tryEnsureDelimiter(LookAheadSession $this$tryEnsureDelimiter, ByteBuffer delimiter) {
        int found = MultipartKt.startsWithDelimiter($this$tryEnsureDelimiter, delimiter);
        if (found == -1) {
            throw new IOException("Failed to skip delimiter: actual bytes differ from delimiter bytes");
        }
        if (found < delimiter.remaining()) {
            return found;
        }
        $this$tryEnsureDelimiter.consumed(delimiter.remaining());
        return delimiter.remaining();
    }

    private static final boolean startsWith(ByteBuffer $this$startsWith, ByteBuffer prefix, int prefixSkip) {
        int size2 = Math.min($this$startsWith.remaining(), prefix.remaining() - prefixSkip);
        if (size2 <= 0) {
            return false;
        }
        int position = $this$startsWith.position();
        int prefixPosition = prefix.position() + prefixSkip;
        for (int i = 0; i < size2; ++i) {
            if ($this$startsWith.get(position + i) == prefix.get(prefixPosition + i)) continue;
            return false;
        }
        return true;
    }

    static /* synthetic */ boolean startsWith$default(ByteBuffer byteBuffer, ByteBuffer byteBuffer2, int n, int n2, Object object) {
        if ((n2 & 2) != 0) {
            n = 0;
        }
        return MultipartKt.startsWith(byteBuffer, byteBuffer2, n);
    }

    private static final int startsWithDelimiter(LookAheadSession $this$startsWithDelimiter, ByteBuffer delimiter) {
        ByteBuffer byteBuffer = $this$startsWithDelimiter.request(0, 1);
        if (byteBuffer == null) {
            return 0;
        }
        ByteBuffer buffer = byteBuffer;
        int index = MultipartKt.indexOfPartial(buffer, delimiter);
        if (index != 0) {
            return -1;
        }
        int found = Math.min(buffer.remaining() - index, delimiter.remaining());
        int notKnown = delimiter.remaining() - found;
        if (notKnown > 0) {
            ByteBuffer byteBuffer2 = $this$startsWithDelimiter.request(index + found, notKnown);
            if (byteBuffer2 == null) {
                return found;
            }
            ByteBuffer next = byteBuffer2;
            if (!MultipartKt.startsWith(next, delimiter, found)) {
                return -1;
            }
        }
        return delimiter.remaining();
    }

    private static final int indexOfPartial(ByteBuffer $this$indexOfPartial, ByteBuffer sub) {
        int subPosition = sub.position();
        int subSize = sub.remaining();
        byte first2 = sub.get(subPosition);
        int limit = $this$indexOfPartial.limit();
        block0: for (int idx = $this$indexOfPartial.position(); idx < limit; ++idx) {
            if ($this$indexOfPartial.get(idx) != first2) continue;
            for (int j2 = 1; j2 < subSize && idx + j2 != limit; ++j2) {
                if ($this$indexOfPartial.get(idx + j2) != sub.get(subPosition + j2)) continue block0;
            }
            return idx - $this$indexOfPartial.position();
        }
        return -1;
    }

    public static final /* synthetic */ Object access$parsePreambleImpl(ByteBuffer boundaryPrefixed, ByteReadChannel input2, BytePacketBuilder output2, long limit, Continuation $completion) {
        return MultipartKt.parsePreambleImpl(boundaryPrefixed, input2, output2, limit, $completion);
    }

    public static final /* synthetic */ Object access$parsePartHeadersImpl(ByteReadChannel input2, Continuation $completion) {
        return MultipartKt.parsePartHeadersImpl(input2, $completion);
    }

    public static final /* synthetic */ Object access$parsePartBodyImpl(ByteBuffer boundaryPrefixed, ByteReadChannel input2, ByteWriteChannel output2, HttpHeadersMap headers2, long limit, Continuation $completion) {
        return MultipartKt.parsePartBodyImpl(boundaryPrefixed, input2, output2, headers2, limit, $completion);
    }

    public static final /* synthetic */ Object access$skipBoundary(ByteBuffer boundaryPrefixed, ByteReadChannel input2, Continuation $completion) {
        return MultipartKt.skipBoundary(boundaryPrefixed, input2, $completion);
    }

    public static final /* synthetic */ ByteBuffer access$getBoundaryTrailingBuffer$p() {
        return BoundaryTrailingBuffer;
    }

    public static final /* synthetic */ ByteBuffer access$getCrLf$p() {
        return CrLf;
    }

    public static final /* synthetic */ Object access$copyUntilBoundary(String name, ByteBuffer boundaryPrefixed, ByteReadChannel input2, Function2 writeFully2, long limit, Continuation $completion) {
        return MultipartKt.copyUntilBoundary(name, boundaryPrefixed, input2, writeFully2, limit, $completion);
    }

    public static final /* synthetic */ int access$tryEnsureDelimiter(LookAheadSession $receiver, ByteBuffer delimiter) {
        return MultipartKt.tryEnsureDelimiter($receiver, delimiter);
    }

    public static final /* synthetic */ Object access$trySkipDelimiterSuspend(ByteReadChannel $receiver, ByteBuffer delimiter, Continuation $completion) {
        return MultipartKt.trySkipDelimiterSuspend($receiver, delimiter, $completion);
    }

    static {
        byte[] arrby;
        String $this$toByteArray_u24default$iv = "\r\n";
        Charset charset$iv = Charsets.UTF_8;
        boolean $i$f$toByteArray = false;
        if (Intrinsics.areEqual(charset$iv, Charsets.UTF_8)) {
            arrby = StringsKt.encodeToByteArray($this$toByteArray_u24default$iv);
        } else {
            CharsetEncoder charsetEncoder = charset$iv.newEncoder();
            Intrinsics.checkNotNullExpressionValue(charsetEncoder, "charset.newEncoder()");
            arrby = CharsetJVMKt.encodeToByteArray(charsetEncoder, $this$toByteArray_u24default$iv, 0, $this$toByteArray_u24default$iv.length());
        }
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrby);
        Intrinsics.checkNotNull(byteBuffer);
        CrLf = byteBuffer;
        ByteBuffer byteBuffer2 = ByteBuffer.allocate(8192);
        Intrinsics.checkNotNull(byteBuffer2);
        BoundaryTrailingBuffer = byteBuffer2;
    }
}

