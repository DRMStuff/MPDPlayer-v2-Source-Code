/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.http.cio;

import io.ktor.http.Headers;
import io.ktor.http.cio.CIOHeaders;
import io.ktor.http.cio.HttpHeadersMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;
import kotlin.ranges.RangesKt;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010&\n\u0002\u0010 \n\u0002\b\u0006\u0018\u00002\u00020\u0001:\u0001\u0017B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J \u0010\u0010\u001a\u001a\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\u00120\u00110\nH\u0016J\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0014\u001a\u00020\u000bH\u0096\u0002J\u0018\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u00122\u0006\u0010\u0014\u001a\u00020\u000bH\u0016J\b\u0010\u0016\u001a\u00020\u0006H\u0016J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u0016R\u0014\u0010\u0005\u001a\u00020\u00068VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R!\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\r\u00a8\u0006\u0018"}, d2={"Lio/ktor/http/cio/CIOHeaders;", "Lio/ktor/http/Headers;", "headers", "Lio/ktor/http/cio/HttpHeadersMap;", "(Lio/ktor/http/cio/HttpHeadersMap;)V", "caseInsensitiveName", "", "getCaseInsensitiveName", "()Z", "names", "", "", "getNames", "()Ljava/util/Set;", "names$delegate", "Lkotlin/Lazy;", "entries", "", "", "get", "name", "getAll", "isEmpty", "Entry", "ktor-http-cio"})
public final class CIOHeaders
implements Headers {
    @NotNull
    private final HttpHeadersMap headers;
    @NotNull
    private final Lazy names$delegate;

    public CIOHeaders(@NotNull HttpHeadersMap headers2) {
        Intrinsics.checkNotNullParameter(headers2, "headers");
        this.headers = headers2;
        this.names$delegate = LazyKt.lazy(LazyThreadSafetyMode.NONE, (Function0)new Function0<LinkedHashSet<String>>(this){
            final /* synthetic */ CIOHeaders this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            @NotNull
            public final LinkedHashSet<String> invoke() {
                LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>(CIOHeaders.access$getHeaders$p(this.this$0).getSize());
                CIOHeaders cIOHeaders = this.this$0;
                LinkedHashSet<String> $this$invoke_u24lambda_u2d0 = linkedHashSet;
                boolean bl = false;
                int n = CIOHeaders.access$getHeaders$p(cIOHeaders).getSize();
                for (int i = 0; i < n; ++i) {
                    $this$invoke_u24lambda_u2d0.add(((Object)CIOHeaders.access$getHeaders$p(cIOHeaders).nameAt(i)).toString());
                }
                return linkedHashSet;
            }
        });
    }

    private final Set<String> getNames() {
        Lazy lazy = this.names$delegate;
        return (Set)lazy.getValue();
    }

    @Override
    public boolean getCaseInsensitiveName() {
        return true;
    }

    @Override
    @NotNull
    public Set<String> names() {
        return this.getNames();
    }

    @Override
    @Nullable
    public String get(@NotNull String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        CharSequence charSequence = this.headers.get(name);
        return charSequence != null ? ((Object)charSequence).toString() : null;
    }

    @Override
    @Nullable
    public List<String> getAll(@NotNull String name) {
        List<String> list;
        Intrinsics.checkNotNullParameter(name, "name");
        List<String> it = list = SequencesKt.toList(SequencesKt.map(this.headers.getAll(name), getAll.1.INSTANCE));
        boolean bl = false;
        return !((Collection)it).isEmpty() ? list : null;
    }

    @Override
    public boolean isEmpty() {
        return this.headers.getSize() == 0;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    @NotNull
    public Set<Map.Entry<String, List<String>>> entries() {
        void $this$mapTo$iv$iv;
        Iterable $this$map$iv = RangesKt.until(0, this.headers.getSize());
        boolean $i$f$map = false;
        Iterable iterable = $this$map$iv;
        Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
        boolean $i$f$mapTo = false;
        Iterator iterator2 = $this$mapTo$iv$iv.iterator();
        while (iterator2.hasNext()) {
            void idx;
            int item$iv$iv;
            int n = item$iv$iv = ((IntIterator)iterator2).nextInt();
            Collection collection = destination$iv$iv;
            boolean bl = false;
            collection.add(new Entry((int)idx));
        }
        return CollectionsKt.toSet((List)destination$iv$iv);
    }

    @Override
    public boolean contains(@NotNull String name) {
        return Headers.DefaultImpls.contains(this, name);
    }

    @Override
    public boolean contains(@NotNull String name, @NotNull String value) {
        return Headers.DefaultImpls.contains(this, name, value);
    }

    @Override
    public void forEach(@NotNull Function2<? super String, ? super List<String>, Unit> body2) {
        Headers.DefaultImpls.forEach(this, body2);
    }

    @Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010&\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0000\n\u0002\u0010\b\n\u0002\b\b\b\u0082\u0004\u0018\u00002\u0014\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00030\u0001B\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u00020\u00028VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u000b\u0010\f\u00a8\u0006\r"}, d2={"Lio/ktor/http/cio/CIOHeaders$Entry;", "", "", "", "idx", "", "(Lio/ktor/http/cio/CIOHeaders;I)V", "key", "getKey", "()Ljava/lang/String;", "value", "getValue", "()Ljava/util/List;", "ktor-http-cio"})
    private final class Entry
    implements Map.Entry<String, List<? extends String>>,
    KMappedMarker {
        private final int idx;

        public Entry(int idx) {
            this.idx = idx;
        }

        @Override
        @NotNull
        public String getKey() {
            return ((Object)CIOHeaders.this.headers.nameAt(this.idx)).toString();
        }

        @Override
        @NotNull
        public List<String> getValue() {
            return CollectionsKt.listOf(((Object)CIOHeaders.this.headers.valueAt(this.idx)).toString());
        }

        @Override
        public List<String> setValue(List<String> newValue) {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }
}

