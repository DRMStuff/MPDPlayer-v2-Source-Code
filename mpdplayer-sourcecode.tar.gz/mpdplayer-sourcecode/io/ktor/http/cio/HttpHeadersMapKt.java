/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.http.cio;

import io.ktor.http.cio.HttpHeadersMap;
import io.ktor.utils.io.pool.DefaultPool;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=2, xi=48, d1={"\u00000\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a \u0010\b\u001a\u00020\t*\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\n\u0010\r\u001a\u00060\u000ej\u0002`\u000fH\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0003X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0003X\u0082T\u00a2\u0006\u0002\n\u0000\"\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2={"EMPTY_INT_LIST", "", "EXPECTED_HEADERS_QTY", "", "HEADER_ARRAY_POOL_SIZE", "HEADER_SIZE", "IntArrayPool", "Lio/ktor/utils/io/pool/DefaultPool;", "dumpTo", "", "Lio/ktor/http/cio/HttpHeadersMap;", "indent", "", "out", "Ljava/lang/Appendable;", "Lkotlin/text/Appendable;", "ktor-http-cio"})
public final class HttpHeadersMapKt {
    private static final int EXPECTED_HEADERS_QTY = 64;
    private static final int HEADER_SIZE = 8;
    private static final int HEADER_ARRAY_POOL_SIZE = 1000;
    @NotNull
    private static final int[] EMPTY_INT_LIST = new int[0];
    @NotNull
    private static final DefaultPool<int[]> IntArrayPool = new DefaultPool<int[]>(){

        @NotNull
        protected int[] produceInstance() {
            return new int[512];
        }
    };

    public static final void dumpTo(@NotNull HttpHeadersMap $this$dumpTo, @NotNull String indent, @NotNull Appendable out2) {
        Intrinsics.checkNotNullParameter($this$dumpTo, "<this>");
        Intrinsics.checkNotNullParameter(indent, "indent");
        Intrinsics.checkNotNullParameter(out2, "out");
        int n = $this$dumpTo.getSize();
        for (int i = 0; i < n; ++i) {
            out2.append(indent);
            out2.append($this$dumpTo.nameAt(i));
            out2.append(" => ");
            out2.append($this$dumpTo.valueAt(i));
            out2.append("\n");
        }
    }

    public static final /* synthetic */ DefaultPool access$getIntArrayPool$p() {
        return IntArrayPool;
    }

    public static final /* synthetic */ int[] access$getEMPTY_INT_LIST$p() {
        return EMPTY_INT_LIST;
    }
}

