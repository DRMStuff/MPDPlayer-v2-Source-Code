/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.utils.io.core.internal;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;
import kotlin.RequiresOptIn;

@Retention(value=RetentionPolicy.RUNTIME)
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0087\u0002\u0018\u00002\u00020\u0001B\u0000\u00a8\u0006\u0002"}, d2={"Lio/ktor/utils/io/core/internal/DangerousInternalIoApi;", "", "ktor-io"})
@RequiresOptIn(level=RequiresOptIn.Level.ERROR)
public @interface DangerousInternalIoApi {
}

