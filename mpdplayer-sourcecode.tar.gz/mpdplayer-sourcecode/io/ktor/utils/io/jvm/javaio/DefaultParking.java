/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.utils.io.jvm.javaio;

import io.ktor.utils.io.jvm.javaio.Parking;
import java.util.concurrent.locks.LockSupport;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\b\u00c2\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\b\u0010\b\u001a\u00020\u0002H\u0016J\u0010\u0010\t\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0002H\u0016\u00a8\u0006\n"}, d2={"Lio/ktor/utils/io/jvm/javaio/DefaultParking;", "Lio/ktor/utils/io/jvm/javaio/Parking;", "Ljava/lang/Thread;", "()V", "park", "", "timeNanos", "", "token", "unpark", "ktor-io"})
final class DefaultParking
implements Parking<Thread> {
    @NotNull
    public static final DefaultParking INSTANCE = new DefaultParking();

    private DefaultParking() {
    }

    @Override
    @NotNull
    public Thread token() {
        Thread thread2 = Thread.currentThread();
        Intrinsics.checkNotNullExpressionValue(thread2, "currentThread()");
        return thread2;
    }

    @Override
    public void park(long timeNanos) {
        if (!(timeNanos >= 0L)) {
            String string = "Failed requirement.";
            throw new IllegalArgumentException(string.toString());
        }
        LockSupport.parkNanos(timeNanos);
    }

    @Override
    public void unpark(@NotNull Thread token2) {
        Intrinsics.checkNotNullParameter(token2, "token");
        LockSupport.unpark(token2);
    }
}

