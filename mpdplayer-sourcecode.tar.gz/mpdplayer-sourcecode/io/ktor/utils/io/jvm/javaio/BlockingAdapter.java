/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.utils.io.jvm.javaio;

import io.ktor.utils.io.jvm.javaio.BlockingKt;
import io.ktor.utils.io.jvm.javaio.PollersKt;
import io.ktor.utils.io.jvm.javaio.UnsafeBlockingTrampoline;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.EventLoopKt;
import kotlinx.coroutines.Job;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\b\"\u0018\u00002\u00020\u0010B\u0013\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0001\u00a2\u0006\u0004\b\u0003\u0010\u0004J\u0017\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0005H\u0004\u00a2\u0006\u0004\b\b\u0010\tJ\u0013\u0010\n\u001a\u00020\u0007H\u00a4@\u00f8\u0001\u0000\u00a2\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000e\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\fH\u0002\u00a2\u0006\u0004\b\u000e\u0010\u000fJ\u001b\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u0005H\u0084H\u00f8\u0001\u0000\u00a2\u0006\u0004\b\u0011\u0010\u0012J\u001d\u0010\u0015\u001a\u00020\u00102\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00100\u0013H\u0002\u00a2\u0006\u0004\b\u0015\u0010\u000bJ\r\u0010\u0016\u001a\u00020\u0007\u00a2\u0006\u0004\b\u0016\u0010\u0017J\u0015\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u0010\u00a2\u0006\u0004\b\u0019\u0010\u001aJ%\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u0005\u00a2\u0006\u0004\b\u0019\u0010\u001fR\u0016\u0010!\u001a\u0004\u0018\u00010 8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b!\u0010\"R\u001a\u0010#\u001a\b\u0012\u0004\u0012\u00020\u00070\u00138\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\b#\u0010$R$\u0010\u001e\u001a\u00020\u00052\u0006\u0010%\u001a\u00020\u00058\u0004@BX\u0084\u000e\u00a2\u0006\f\n\u0004\b\u001e\u0010&\u001a\u0004\b'\u0010(R$\u0010\u001d\u001a\u00020\u00052\u0006\u0010%\u001a\u00020\u00058\u0004@BX\u0084\u000e\u00a2\u0006\f\n\u0004\b\u001d\u0010&\u001a\u0004\b)\u0010(R\u0019\u0010\u0002\u001a\u0004\u0018\u00010\u00018\u0006\u00a2\u0006\f\n\u0004\b\u0002\u0010*\u001a\u0004\b+\u0010,\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006-"}, d2={"Lio/ktor/utils/io/jvm/javaio/BlockingAdapter;", "Lkotlinx/coroutines/Job;", "parent", "<init>", "(Lkotlinx/coroutines/Job;)V", "", "rc", "", "finish", "(I)V", "loop", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Ljava/lang/Thread;", "thread", "parkingLoop", "(Ljava/lang/Thread;)V", "", "rendezvous", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlin/coroutines/Continuation;", "ucont", "rendezvousBlock", "shutdown", "()V", "jobToken", "submitAndAwait", "(Ljava/lang/Object;)I", "", "buffer", "offset", "length", "([BII)I", "Lkotlinx/coroutines/DisposableHandle;", "disposable", "Lkotlinx/coroutines/DisposableHandle;", "end", "Lkotlin/coroutines/Continuation;", "<set-?>", "I", "getLength", "()I", "getOffset", "Lkotlinx/coroutines/Job;", "getParent", "()Lkotlinx/coroutines/Job;", "ktor-io"})
abstract class BlockingAdapter {
    @Nullable
    private final Job parent;
    @NotNull
    private final Continuation<Unit> end;
    @NotNull
    volatile /* synthetic */ Object state;
    static final /* synthetic */ AtomicReferenceFieldUpdater state$FU;
    @NotNull
    volatile /* synthetic */ int result;
    @Nullable
    private final DisposableHandle disposable;
    private int offset;
    private int length;

    public BlockingAdapter(@Nullable Job parent) {
        Function1 block2;
        this.parent = parent;
        this.end = new Continuation<Unit>(this){
            @NotNull
            private final CoroutineContext context;
            final /* synthetic */ BlockingAdapter this$0;
            {
                this.this$0 = $receiver;
                this.context = $receiver.getParent() != null ? UnsafeBlockingTrampoline.INSTANCE.plus($receiver.getParent()) : (CoroutineContext)UnsafeBlockingTrampoline.INSTANCE;
            }

            @NotNull
            public CoroutineContext getContext() {
                return this.context;
            }

            public void resumeWith(@NotNull Object result2) {
                block8: {
                    Object before;
                    Throwable upd$iv;
                    Object cur$iv;
                    Object object = Result.exceptionOrNull-impl(result2);
                    if (object == null) {
                        object = Unit.INSTANCE;
                    }
                    Throwable value = object;
                    BlockingAdapter $this$getAndUpdate$iv = this.this$0;
                    boolean $i$f$getAndUpdate = false;
                    do {
                        Object current = cur$iv = $this$getAndUpdate$iv.state;
                        boolean bl = false;
                        Object object2 = current;
                        if ((object2 instanceof Thread ? true : object2 instanceof Continuation) ? true : Intrinsics.areEqual(object2, this)) continue;
                        return;
                    } while (!BlockingAdapter.state$FU.compareAndSet($this$getAndUpdate$iv, cur$iv, upd$iv = value));
                    Object object3 = before = cur$iv;
                    if (object3 instanceof Thread) {
                        PollersKt.getParkingImpl().unpark((Thread)before);
                    } else if (object3 instanceof Continuation) {
                        Throwable throwable = Result.exceptionOrNull-impl(result2);
                        if (throwable != null) {
                            Throwable it = throwable;
                            boolean bl = false;
                            ((Continuation)before).resumeWith(Result.constructor-impl(ResultKt.createFailure(it)));
                        }
                    }
                    if (Result.isFailure-impl(result2) && !(Result.exceptionOrNull-impl(result2) instanceof CancellationException)) {
                        Job job2 = this.this$0.getParent();
                        if (job2 != null) {
                            Job.DefaultImpls.cancel$default(job2, null, 1, null);
                        }
                    }
                    DisposableHandle disposableHandle = BlockingAdapter.access$getDisposable$p(this.this$0);
                    if (disposableHandle == null) break block8;
                    disposableHandle.dispose();
                }
            }
        };
        this.state = this;
        this.result = 0;
        Job job2 = this.parent;
        this.disposable = job2 != null ? job2.invokeOnCompletion((Function1<? super Throwable, Unit>)new Function1<Throwable, Unit>(this){
            final /* synthetic */ BlockingAdapter this$0;
            {
                this.this$0 = $receiver;
                super(1);
            }

            public final void invoke(@Nullable Throwable cause) {
                if (cause != null) {
                    BlockingAdapter.access$getEnd$p(this.this$0).resumeWith(Result.constructor-impl(ResultKt.createFailure(cause)));
                }
            }
        }) : null;
        Function1 function1 = block2 = (Function1)new Function1<Continuation<? super Unit>, Object>(this, null){
            int label;
            final /* synthetic */ BlockingAdapter this$0;
            {
                this.this$0 = $receiver;
                super(1, $completion);
            }

            /*
             * WARNING - void declaration
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        this.label = 1;
                        Object object3 = this.this$0.loop(this);
                        if (object3 != object2) return Unit.INSTANCE;
                        return object2;
                    }
                    case 1: {
                        void $result;
                        ResultKt.throwOnFailure($result);
                        Object object3 = $result;
                        return Unit.INSTANCE;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@NotNull Continuation<?> $completion) {
                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
            }

            @Nullable
            public final Object invoke(@Nullable Continuation<? super Unit> p1) {
                return (this.create(p1)).invokeSuspend(Unit.INSTANCE);
            }
        };
        Object object = this.end;
        ((Function1)TypeIntrinsics.beforeCheckcastToFunctionOfArity(function1, 1)).invoke(object);
        if (!(this.state != this)) {
            object = "Failed requirement.";
            throw new IllegalArgumentException(object.toString());
        }
    }

    public /* synthetic */ BlockingAdapter(Job job2, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            job2 = null;
        }
        this(job2);
    }

    @Nullable
    public final Job getParent() {
        return this.parent;
    }

    private static /* synthetic */ void getState$annotations() {
    }

    protected final int getOffset() {
        return this.offset;
    }

    protected final int getLength() {
        return this.length;
    }

    @Nullable
    protected abstract Object loop(@NotNull Continuation<? super Unit> var1);

    public final void shutdown() {
        DisposableHandle disposableHandle = this.disposable;
        if (disposableHandle != null) {
            disposableHandle.dispose();
        }
        this.end.resumeWith(Result.constructor-impl(ResultKt.createFailure(new CancellationException("Stream closed"))));
    }

    public final int submitAndAwait(@NotNull byte[] buffer, int offset, int length) {
        Intrinsics.checkNotNullParameter(buffer, "buffer");
        this.offset = offset;
        this.length = length;
        return this.submitAndAwait(buffer);
    }

    public final int submitAndAwait(@NotNull Object jobToken) {
        Thread upd$iv;
        Object cur$iv;
        Intrinsics.checkNotNullParameter(jobToken, "jobToken");
        Thread thread2 = Thread.currentThread();
        Continuation cont = null;
        BlockingAdapter $this$update$iv = this;
        boolean $i$f$update = false;
        do {
            Object object;
            Object value = cur$iv = $this$update$iv.state;
            boolean bl = false;
            Object object2 = value;
            if (object2 instanceof Continuation) {
                cont = (Continuation)value;
                object = thread2;
            } else {
                if (object2 instanceof Unit) {
                    return this.result;
                }
                if (object2 instanceof Throwable) {
                    throw (Throwable)value;
                }
                if (object2 instanceof Thread) {
                    throw new IllegalStateException("There is already thread owning adapter");
                }
                if (Intrinsics.areEqual(object2, this)) {
                    throw new IllegalStateException("Not yet started");
                }
                object = new NoWhenBranchMatchedException();
            }
            Thread thread3 = object;
            Intrinsics.checkNotNullExpressionValue(thread3, "when (value) {\n         \u2026Exception()\n            }");
            upd$iv = thread3;
        } while (!state$FU.compareAndSet($this$update$iv, cur$iv, upd$iv));
        Continuation continuation2 = cont;
        Intrinsics.checkNotNull(continuation2);
        continuation2.resumeWith(Result.constructor-impl(jobToken));
        Intrinsics.checkNotNullExpressionValue(thread2, "thread");
        this.parkingLoop(thread2);
        Object state2 = this.state;
        boolean bl = false;
        if (state2 instanceof Throwable) {
            throw (Throwable)state2;
        }
        return this.result;
    }

    private final void parkingLoop(Thread thread2) {
        if (this.state != thread2) {
            return;
        }
        if (!PollersKt.isParkingAllowed()) {
            BlockingKt.access$getADAPTER_LOGGER().warn("Blocking network thread detected. \nIt can possible lead to a performance decline or even a deadlock.\nPlease make sure you're using blocking IO primitives like InputStream and OutputStream only in \nthe context of Dispatchers.IO:\n```\nwithContext(Dispatchers.IO) {\n    myInputStream.read()\n}\n```");
        }
        while (true) {
            long nextEventTimeNanos = EventLoopKt.processNextEventInCurrentThread();
            if (this.state != thread2) break;
            if (nextEventTimeNanos <= 0L) continue;
            PollersKt.getParkingImpl().park(nextEventTimeNanos);
        }
    }

    @Nullable
    protected final Object rendezvous(int rc2, @NotNull Continuation<Object> $completion) {
        boolean $i$f$rendezvous = false;
        this.result = rc2;
        Continuation<Object> ucont = $completion;
        boolean bl = false;
        Object object = this.rendezvousBlock(ucont);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended($completion);
        }
        return object;
    }

    private final Object rendezvous$$forInline(int rc2, Continuation<Object> $completion) {
        boolean $i$f$rendezvous = false;
        this.result = rc2;
        InlineMarker.mark(0);
        Continuation<Object> ucont = $completion;
        boolean bl = false;
        Object object = this.rendezvousBlock(ucont);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended($completion);
        }
        InlineMarker.mark(1);
        return object;
    }

    private final Object rendezvousBlock(Continuation<Object> ucont) {
        Continuation<Object> continuation2;
        Continuation<Object> upd$iv;
        Object cur$iv;
        Object thread2 = null;
        BlockingAdapter $this$update$iv = this;
        boolean $i$f$update = false;
        do {
            Object value = cur$iv = $this$update$iv.state;
            boolean bl = false;
            Object object = value;
            if (object instanceof Thread) {
                thread2 = value;
                continuation2 = IntrinsicsKt.intercepted(ucont);
                continue;
            }
            if (Intrinsics.areEqual(object, this)) {
                continuation2 = IntrinsicsKt.intercepted(ucont);
                continue;
            }
            throw new IllegalStateException("Already suspended or in finished state");
        } while (!state$FU.compareAndSet($this$update$iv, cur$iv, upd$iv = continuation2));
        if (thread2 != null) {
            PollersKt.getParkingImpl().unpark((Thread)thread2);
        }
        return IntrinsicsKt.getCOROUTINE_SUSPENDED();
    }

    protected final void finish(int rc2) {
        this.result = rc2;
    }

    public BlockingAdapter() {
        this(null, 1, null);
    }

    public static final /* synthetic */ DisposableHandle access$getDisposable$p(BlockingAdapter $this) {
        return $this.disposable;
    }

    public static final /* synthetic */ Continuation access$getEnd$p(BlockingAdapter $this) {
        return $this.end;
    }

    static {
        state$FU = AtomicReferenceFieldUpdater.newUpdater(BlockingAdapter.class, Object.class, "state");
    }
}

