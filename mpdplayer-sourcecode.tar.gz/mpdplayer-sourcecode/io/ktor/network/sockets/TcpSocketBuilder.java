/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.network.sockets;

import io.ktor.network.selector.SelectorManager;
import io.ktor.network.sockets.Configurable;
import io.ktor.network.sockets.ConnectUtilsJvmKt;
import io.ktor.network.sockets.InetSocketAddress;
import io.ktor.network.sockets.ServerSocket;
import io.ktor.network.sockets.Socket;
import io.ktor.network.sockets.SocketAddress;
import io.ktor.network.sockets.SocketOptions;
import io.ktor.network.sockets.TcpSocketBuilder;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001B\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\u0006J-\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0019\b\u0002\u0010\u000f\u001a\u0013\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00120\u0010\u00a2\u0006\u0002\b\u0013J5\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\u0014\u001a\u00020\u00152\b\b\u0002\u0010\u0016\u001a\u00020\u00172\u0019\b\u0002\u0010\u000f\u001a\u0013\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00120\u0010\u00a2\u0006\u0002\b\u0013J4\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u000e2\u0019\b\u0002\u0010\u000f\u001a\u0013\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00120\u0010\u00a2\u0006\u0002\b\u0013H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001cJ<\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0019\b\u0002\u0010\u000f\u001a\u0013\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00120\u0010\u00a2\u0006\u0002\b\u0013H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001dR\u001a\u0010\u0005\u001a\u00020\u0002X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\u001e"}, d2={"Lio/ktor/network/sockets/TcpSocketBuilder;", "Lio/ktor/network/sockets/Configurable;", "Lio/ktor/network/sockets/SocketOptions;", "selector", "Lio/ktor/network/selector/SelectorManager;", "options", "(Lio/ktor/network/selector/SelectorManager;Lio/ktor/network/sockets/SocketOptions;)V", "getOptions", "()Lio/ktor/network/sockets/SocketOptions;", "setOptions", "(Lio/ktor/network/sockets/SocketOptions;)V", "bind", "Lio/ktor/network/sockets/ServerSocket;", "localAddress", "Lio/ktor/network/sockets/SocketAddress;", "configure", "Lkotlin/Function1;", "Lio/ktor/network/sockets/SocketOptions$AcceptorOptions;", "", "Lkotlin/ExtensionFunctionType;", "hostname", "", "port", "", "connect", "Lio/ktor/network/sockets/Socket;", "remoteAddress", "Lio/ktor/network/sockets/SocketOptions$TCPClientSocketOptions;", "(Lio/ktor/network/sockets/SocketAddress;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Ljava/lang/String;ILkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "ktor-network"})
public final class TcpSocketBuilder
implements Configurable<TcpSocketBuilder, SocketOptions> {
    @NotNull
    private final SelectorManager selector;
    @NotNull
    private SocketOptions options;

    public TcpSocketBuilder(@NotNull SelectorManager selector, @NotNull SocketOptions options2) {
        Intrinsics.checkNotNullParameter(selector, "selector");
        Intrinsics.checkNotNullParameter(options2, "options");
        this.selector = selector;
        this.options = options2;
    }

    @Override
    @NotNull
    public SocketOptions getOptions() {
        return this.options;
    }

    @Override
    public void setOptions(@NotNull SocketOptions socketOptions) {
        Intrinsics.checkNotNullParameter(socketOptions, "<set-?>");
        this.options = socketOptions;
    }

    @Nullable
    public final Object connect(@NotNull String hostname, int port2, @NotNull Function1<? super SocketOptions.TCPClientSocketOptions, Unit> configure, @NotNull Continuation<? super Socket> $completion) {
        return this.connect(new InetSocketAddress(hostname, port2), configure, $completion);
    }

    public static /* synthetic */ Object connect$default(TcpSocketBuilder tcpSocketBuilder, String string, int n, Function1 function1, Continuation continuation2, int n2, Object object) {
        if ((n2 & 4) != 0) {
            function1 = connect.2.INSTANCE;
        }
        return tcpSocketBuilder.connect(string, n, function1, continuation2);
    }

    @NotNull
    public final ServerSocket bind(@NotNull String hostname, int port2, @NotNull Function1<? super SocketOptions.AcceptorOptions, Unit> configure) {
        Intrinsics.checkNotNullParameter(hostname, "hostname");
        Intrinsics.checkNotNullParameter(configure, "configure");
        return this.bind(new InetSocketAddress(hostname, port2), configure);
    }

    public static /* synthetic */ ServerSocket bind$default(TcpSocketBuilder tcpSocketBuilder, String string, int n, Function1 function1, int n2, Object object) {
        if ((n2 & 1) != 0) {
            string = "0.0.0.0";
        }
        if ((n2 & 2) != 0) {
            n = 0;
        }
        if ((n2 & 4) != 0) {
            function1 = bind.1.INSTANCE;
        }
        return tcpSocketBuilder.bind(string, n, function1);
    }

    @Nullable
    public final Object connect(@NotNull SocketAddress remoteAddress, @NotNull Function1<? super SocketOptions.TCPClientSocketOptions, Unit> configure, @NotNull Continuation<? super Socket> $completion) {
        SocketOptions.TCPClientSocketOptions tCPClientSocketOptions = this.getOptions().peer$ktor_network().tcp$ktor_network();
        configure.invoke(tCPClientSocketOptions);
        return ConnectUtilsJvmKt.connect(this.selector, remoteAddress, tCPClientSocketOptions, $completion);
    }

    public static /* synthetic */ Object connect$default(TcpSocketBuilder tcpSocketBuilder, SocketAddress socketAddress, Function1 function1, Continuation continuation2, int n, Object object) {
        if ((n & 2) != 0) {
            function1 = connect.4.INSTANCE;
        }
        return tcpSocketBuilder.connect(socketAddress, function1, continuation2);
    }

    @NotNull
    public final ServerSocket bind(@Nullable SocketAddress localAddress, @NotNull Function1<? super SocketOptions.AcceptorOptions, Unit> configure) {
        Intrinsics.checkNotNullParameter(configure, "configure");
        SocketOptions.AcceptorOptions acceptorOptions = this.getOptions().peer$ktor_network().acceptor$ktor_network();
        configure.invoke(acceptorOptions);
        return ConnectUtilsJvmKt.bind(this.selector, localAddress, acceptorOptions);
    }

    public static /* synthetic */ ServerSocket bind$default(TcpSocketBuilder tcpSocketBuilder, SocketAddress socketAddress, Function1 function1, int n, Object object) {
        if ((n & 1) != 0) {
            socketAddress = null;
        }
        if ((n & 2) != 0) {
            function1 = bind.2.INSTANCE;
        }
        return tcpSocketBuilder.bind(socketAddress, function1);
    }

    @Override
    @NotNull
    public TcpSocketBuilder configure(@NotNull Function1<? super SocketOptions, Unit> block2) {
        return Configurable.DefaultImpls.configure(this, block2);
    }
}

