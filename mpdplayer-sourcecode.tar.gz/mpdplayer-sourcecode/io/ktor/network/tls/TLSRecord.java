/*
 * Decompiled with CFR 0.150.
 */
package io.ktor.network.tls;

import io.ktor.network.tls.TLSRecordType;
import io.ktor.network.tls.TLSVersion;
import io.ktor.utils.io.core.ByteReadPacket;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\b\u0000\u0018\u00002\u00020\u0001B#\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e\u00a8\u0006\u000f"}, d2={"Lio/ktor/network/tls/TLSRecord;", "", "type", "Lio/ktor/network/tls/TLSRecordType;", "version", "Lio/ktor/network/tls/TLSVersion;", "packet", "Lio/ktor/utils/io/core/ByteReadPacket;", "(Lio/ktor/network/tls/TLSRecordType;Lio/ktor/network/tls/TLSVersion;Lio/ktor/utils/io/core/ByteReadPacket;)V", "getPacket", "()Lio/ktor/utils/io/core/ByteReadPacket;", "getType", "()Lio/ktor/network/tls/TLSRecordType;", "getVersion", "()Lio/ktor/network/tls/TLSVersion;", "ktor-network-tls"})
public final class TLSRecord {
    @NotNull
    private final TLSRecordType type;
    @NotNull
    private final TLSVersion version;
    @NotNull
    private final ByteReadPacket packet;

    public TLSRecord(@NotNull TLSRecordType type2, @NotNull TLSVersion version2, @NotNull ByteReadPacket packet2) {
        Intrinsics.checkNotNullParameter((Object)type2, "type");
        Intrinsics.checkNotNullParameter((Object)version2, "version");
        Intrinsics.checkNotNullParameter(packet2, "packet");
        this.type = type2;
        this.version = version2;
        this.packet = packet2;
    }

    public /* synthetic */ TLSRecord(TLSRecordType tLSRecordType, TLSVersion tLSVersion, ByteReadPacket byteReadPacket, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            tLSRecordType = TLSRecordType.Handshake;
        }
        if ((n & 2) != 0) {
            tLSVersion = TLSVersion.TLS12;
        }
        if ((n & 4) != 0) {
            byteReadPacket = ByteReadPacket.Companion.getEmpty();
        }
        this(tLSRecordType, tLSVersion, byteReadPacket);
    }

    @NotNull
    public final TLSRecordType getType() {
        return this.type;
    }

    @NotNull
    public final TLSVersion getVersion() {
        return this.version;
    }

    @NotNull
    public final ByteReadPacket getPacket() {
        return this.packet;
    }

    public TLSRecord() {
        this(null, null, null, 7, null);
    }
}

