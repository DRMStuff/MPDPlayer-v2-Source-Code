/*
 * Decompiled with CFR 0.150.
 */
package org.json.simple;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONAware;
import org.json.simple.JSONStreamAware;
import org.json.simple.JSONValue;

public class JSONObject
extends HashMap
implements Map,
JSONAware,
JSONStreamAware {
    private static final long serialVersionUID = -503443796854799292L;

    public JSONObject() {
    }

    public JSONObject(Map map2) {
        super(map2);
    }

    public static void writeJSONString(Map map2, Writer out2) throws IOException {
        if (map2 == null) {
            out2.write("null");
            return;
        }
        boolean first2 = true;
        Iterator iter = map2.entrySet().iterator();
        out2.write(123);
        while (iter.hasNext()) {
            if (first2) {
                first2 = false;
            } else {
                out2.write(44);
            }
            Map.Entry entry = iter.next();
            out2.write(34);
            out2.write(JSONObject.escape(String.valueOf(entry.getKey())));
            out2.write(34);
            out2.write(58);
            JSONValue.writeJSONString(entry.getValue(), out2);
        }
        out2.write(125);
    }

    public void writeJSONString(Writer out2) throws IOException {
        JSONObject.writeJSONString(this, out2);
    }

    public static String toJSONString(Map map2) {
        if (map2 == null) {
            return "null";
        }
        StringBuffer sb = new StringBuffer();
        boolean first2 = true;
        Iterator iter = map2.entrySet().iterator();
        sb.append('{');
        while (iter.hasNext()) {
            if (first2) {
                first2 = false;
            } else {
                sb.append(',');
            }
            Map.Entry entry = iter.next();
            JSONObject.toJSONString(String.valueOf(entry.getKey()), entry.getValue(), sb);
        }
        sb.append('}');
        return sb.toString();
    }

    public String toJSONString() {
        return JSONObject.toJSONString(this);
    }

    private static String toJSONString(String key2, Object value, StringBuffer sb) {
        sb.append('\"');
        if (key2 == null) {
            sb.append("null");
        } else {
            JSONValue.escape(key2, sb);
        }
        sb.append('\"').append(':');
        sb.append(JSONValue.toJSONString(value));
        return sb.toString();
    }

    public String toString() {
        return this.toJSONString();
    }

    public static String toString(String key2, Object value) {
        StringBuffer sb = new StringBuffer();
        JSONObject.toJSONString(key2, value, sb);
        return sb.toString();
    }

    public static String escape(String s2) {
        return JSONValue.escape(s2);
    }
}

