/*
 * Decompiled with CFR 0.150.
 */
package org.apache.commons.codec;

public class EncoderException
extends Exception {
    private static final long serialVersionUID = 1L;

    public EncoderException() {
    }

    public EncoderException(String message2) {
        super(message2);
    }

    public EncoderException(String message2, Throwable cause) {
        super(message2, cause);
    }

    public EncoderException(Throwable cause) {
        super(cause);
    }
}

