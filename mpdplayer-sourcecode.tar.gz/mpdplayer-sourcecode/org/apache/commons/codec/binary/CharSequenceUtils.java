/*
 * Decompiled with CFR 0.150.
 */
package org.apache.commons.codec.binary;

public class CharSequenceUtils {
    static boolean regionMatches(CharSequence cs, boolean ignoreCase, int thisStart, CharSequence substring2, int start2, int length) {
        if (cs instanceof String && substring2 instanceof String) {
            return ((String)cs).regionMatches(ignoreCase, thisStart, (String)substring2, start2, length);
        }
        int index1 = thisStart;
        int index2 = start2;
        int tmpLen = length;
        while (tmpLen-- > 0) {
            char c2;
            char c1;
            if ((c1 = cs.charAt(index1++)) == (c2 = substring2.charAt(index2++))) continue;
            if (!ignoreCase) {
                return false;
            }
            if (Character.toUpperCase(c1) == Character.toUpperCase(c2) || Character.toLowerCase(c1) == Character.toLowerCase(c2)) continue;
            return false;
        }
        return true;
    }
}

