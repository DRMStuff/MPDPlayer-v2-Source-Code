/*
 * Decompiled with CFR 0.150.
 */
package org.decimal4j.mutable;

import java.math.BigDecimal;
import java.math.BigInteger;
import org.decimal4j.api.Decimal;
import org.decimal4j.api.DecimalArithmetic;
import org.decimal4j.base.AbstractMutableDecimal;
import org.decimal4j.exact.Multipliable17f;
import org.decimal4j.factory.Factory17f;
import org.decimal4j.immutable.Decimal17f;
import org.decimal4j.scale.Scale17f;

public final class MutableDecimal17f
extends AbstractMutableDecimal<Scale17f, MutableDecimal17f>
implements Cloneable {
    private static final long serialVersionUID = 1L;

    public MutableDecimal17f() {
        super(0L);
    }

    private MutableDecimal17f(long unscaledValue, Scale17f scale) {
        super(unscaledValue);
    }

    public MutableDecimal17f(String value) {
        this();
        this.set(value);
    }

    public MutableDecimal17f(long value) {
        this();
        this.set(value);
    }

    public MutableDecimal17f(double value) {
        this();
        this.set(value);
    }

    public MutableDecimal17f(BigInteger value) {
        this();
        this.set(value);
    }

    public MutableDecimal17f(BigDecimal value) {
        this();
        this.set(value);
    }

    public MutableDecimal17f(Decimal17f value) {
        this(value.unscaledValue(), Decimal17f.METRICS);
    }

    public MutableDecimal17f(Decimal<?> value) {
        this();
        this.setUnscaled(value.unscaledValue(), value.getScale());
    }

    @Override
    protected final MutableDecimal17f create(long unscaled) {
        return new MutableDecimal17f(unscaled, Decimal17f.METRICS);
    }

    protected final MutableDecimal17f[] createArray(int length) {
        return new MutableDecimal17f[length];
    }

    @Override
    protected final MutableDecimal17f self() {
        return this;
    }

    @Override
    public final Scale17f getScaleMetrics() {
        return Decimal17f.METRICS;
    }

    @Override
    public final int getScale() {
        return 17;
    }

    public Factory17f getFactory() {
        return Decimal17f.FACTORY;
    }

    @Override
    protected DecimalArithmetic getDefaultArithmetic() {
        return Decimal17f.DEFAULT_ARITHMETIC;
    }

    @Override
    protected DecimalArithmetic getDefaultCheckedArithmetic() {
        return Decimal17f.METRICS.getDefaultCheckedArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingDownArithmetic() {
        return Decimal17f.METRICS.getRoundingDownArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingFloorArithmetic() {
        return Decimal17f.METRICS.getRoundingFloorArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingHalfEvenArithmetic() {
        return Decimal17f.METRICS.getRoundingHalfEvenArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingUnnecessaryArithmetic() {
        return Decimal17f.METRICS.getRoundingUnnecessaryArithmetic();
    }

    @Override
    public MutableDecimal17f clone() {
        return new MutableDecimal17f(this.unscaledValue(), Decimal17f.METRICS);
    }

    public static MutableDecimal17f unscaled(long unscaledValue) {
        return new MutableDecimal17f(unscaledValue, Decimal17f.METRICS);
    }

    public static MutableDecimal17f zero() {
        return new MutableDecimal17f();
    }

    public static MutableDecimal17f ulp() {
        return new MutableDecimal17f(Decimal17f.ULP);
    }

    public static MutableDecimal17f one() {
        return new MutableDecimal17f(Decimal17f.ONE);
    }

    public static MutableDecimal17f two() {
        return new MutableDecimal17f(Decimal17f.TWO);
    }

    public static MutableDecimal17f three() {
        return new MutableDecimal17f(Decimal17f.THREE);
    }

    public static MutableDecimal17f four() {
        return new MutableDecimal17f(Decimal17f.FOUR);
    }

    public static MutableDecimal17f five() {
        return new MutableDecimal17f(Decimal17f.FIVE);
    }

    public static MutableDecimal17f six() {
        return new MutableDecimal17f(Decimal17f.SIX);
    }

    public static MutableDecimal17f seven() {
        return new MutableDecimal17f(Decimal17f.SEVEN);
    }

    public static MutableDecimal17f eight() {
        return new MutableDecimal17f(Decimal17f.EIGHT);
    }

    public static MutableDecimal17f nine() {
        return new MutableDecimal17f(Decimal17f.NINE);
    }

    public static MutableDecimal17f ten() {
        return new MutableDecimal17f(Decimal17f.TEN);
    }

    public static MutableDecimal17f minusOne() {
        return new MutableDecimal17f(Decimal17f.MINUS_ONE);
    }

    public static MutableDecimal17f half() {
        return new MutableDecimal17f(Decimal17f.HALF);
    }

    public static MutableDecimal17f tenth() {
        return new MutableDecimal17f(Decimal17f.TENTH);
    }

    public static MutableDecimal17f hundredth() {
        return new MutableDecimal17f(Decimal17f.HUNDREDTH);
    }

    public static MutableDecimal17f thousandth() {
        return new MutableDecimal17f(Decimal17f.THOUSANDTH);
    }

    public static MutableDecimal17f millionth() {
        return new MutableDecimal17f(Decimal17f.MILLIONTH);
    }

    public static MutableDecimal17f billionth() {
        return new MutableDecimal17f(Decimal17f.BILLIONTH);
    }

    public static MutableDecimal17f trillionth() {
        return new MutableDecimal17f(Decimal17f.TRILLIONTH);
    }

    public static MutableDecimal17f quadrillionth() {
        return new MutableDecimal17f(Decimal17f.QUADRILLIONTH);
    }

    public Multipliable17f multiplyExact() {
        return new Multipliable17f(this);
    }

    public Decimal17f toImmutableDecimal() {
        return Decimal17f.valueOf(this);
    }

    public MutableDecimal17f toMutableDecimal() {
        return this;
    }
}

