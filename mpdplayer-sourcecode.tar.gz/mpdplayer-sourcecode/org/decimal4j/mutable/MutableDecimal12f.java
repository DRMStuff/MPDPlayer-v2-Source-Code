/*
 * Decompiled with CFR 0.150.
 */
package org.decimal4j.mutable;

import java.math.BigDecimal;
import java.math.BigInteger;
import org.decimal4j.api.Decimal;
import org.decimal4j.api.DecimalArithmetic;
import org.decimal4j.base.AbstractMutableDecimal;
import org.decimal4j.exact.Multipliable12f;
import org.decimal4j.factory.Factory12f;
import org.decimal4j.immutable.Decimal12f;
import org.decimal4j.scale.Scale12f;

public final class MutableDecimal12f
extends AbstractMutableDecimal<Scale12f, MutableDecimal12f>
implements Cloneable {
    private static final long serialVersionUID = 1L;

    public MutableDecimal12f() {
        super(0L);
    }

    private MutableDecimal12f(long unscaledValue, Scale12f scale) {
        super(unscaledValue);
    }

    public MutableDecimal12f(String value) {
        this();
        this.set(value);
    }

    public MutableDecimal12f(long value) {
        this();
        this.set(value);
    }

    public MutableDecimal12f(double value) {
        this();
        this.set(value);
    }

    public MutableDecimal12f(BigInteger value) {
        this();
        this.set(value);
    }

    public MutableDecimal12f(BigDecimal value) {
        this();
        this.set(value);
    }

    public MutableDecimal12f(Decimal12f value) {
        this(value.unscaledValue(), Decimal12f.METRICS);
    }

    public MutableDecimal12f(Decimal<?> value) {
        this();
        this.setUnscaled(value.unscaledValue(), value.getScale());
    }

    @Override
    protected final MutableDecimal12f create(long unscaled) {
        return new MutableDecimal12f(unscaled, Decimal12f.METRICS);
    }

    protected final MutableDecimal12f[] createArray(int length) {
        return new MutableDecimal12f[length];
    }

    @Override
    protected final MutableDecimal12f self() {
        return this;
    }

    @Override
    public final Scale12f getScaleMetrics() {
        return Decimal12f.METRICS;
    }

    @Override
    public final int getScale() {
        return 12;
    }

    public Factory12f getFactory() {
        return Decimal12f.FACTORY;
    }

    @Override
    protected DecimalArithmetic getDefaultArithmetic() {
        return Decimal12f.DEFAULT_ARITHMETIC;
    }

    @Override
    protected DecimalArithmetic getDefaultCheckedArithmetic() {
        return Decimal12f.METRICS.getDefaultCheckedArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingDownArithmetic() {
        return Decimal12f.METRICS.getRoundingDownArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingFloorArithmetic() {
        return Decimal12f.METRICS.getRoundingFloorArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingHalfEvenArithmetic() {
        return Decimal12f.METRICS.getRoundingHalfEvenArithmetic();
    }

    @Override
    protected DecimalArithmetic getRoundingUnnecessaryArithmetic() {
        return Decimal12f.METRICS.getRoundingUnnecessaryArithmetic();
    }

    @Override
    public MutableDecimal12f clone() {
        return new MutableDecimal12f(this.unscaledValue(), Decimal12f.METRICS);
    }

    public static MutableDecimal12f unscaled(long unscaledValue) {
        return new MutableDecimal12f(unscaledValue, Decimal12f.METRICS);
    }

    public static MutableDecimal12f zero() {
        return new MutableDecimal12f();
    }

    public static MutableDecimal12f ulp() {
        return new MutableDecimal12f(Decimal12f.ULP);
    }

    public static MutableDecimal12f one() {
        return new MutableDecimal12f(Decimal12f.ONE);
    }

    public static MutableDecimal12f two() {
        return new MutableDecimal12f(Decimal12f.TWO);
    }

    public static MutableDecimal12f three() {
        return new MutableDecimal12f(Decimal12f.THREE);
    }

    public static MutableDecimal12f four() {
        return new MutableDecimal12f(Decimal12f.FOUR);
    }

    public static MutableDecimal12f five() {
        return new MutableDecimal12f(Decimal12f.FIVE);
    }

    public static MutableDecimal12f six() {
        return new MutableDecimal12f(Decimal12f.SIX);
    }

    public static MutableDecimal12f seven() {
        return new MutableDecimal12f(Decimal12f.SEVEN);
    }

    public static MutableDecimal12f eight() {
        return new MutableDecimal12f(Decimal12f.EIGHT);
    }

    public static MutableDecimal12f nine() {
        return new MutableDecimal12f(Decimal12f.NINE);
    }

    public static MutableDecimal12f ten() {
        return new MutableDecimal12f(Decimal12f.TEN);
    }

    public static MutableDecimal12f hundred() {
        return new MutableDecimal12f(Decimal12f.HUNDRED);
    }

    public static MutableDecimal12f thousand() {
        return new MutableDecimal12f(Decimal12f.THOUSAND);
    }

    public static MutableDecimal12f million() {
        return new MutableDecimal12f(Decimal12f.MILLION);
    }

    public static MutableDecimal12f minusOne() {
        return new MutableDecimal12f(Decimal12f.MINUS_ONE);
    }

    public static MutableDecimal12f half() {
        return new MutableDecimal12f(Decimal12f.HALF);
    }

    public static MutableDecimal12f tenth() {
        return new MutableDecimal12f(Decimal12f.TENTH);
    }

    public static MutableDecimal12f hundredth() {
        return new MutableDecimal12f(Decimal12f.HUNDREDTH);
    }

    public static MutableDecimal12f thousandth() {
        return new MutableDecimal12f(Decimal12f.THOUSANDTH);
    }

    public static MutableDecimal12f millionth() {
        return new MutableDecimal12f(Decimal12f.MILLIONTH);
    }

    public static MutableDecimal12f billionth() {
        return new MutableDecimal12f(Decimal12f.BILLIONTH);
    }

    public static MutableDecimal12f trillionth() {
        return new MutableDecimal12f(Decimal12f.TRILLIONTH);
    }

    public Multipliable12f multiplyExact() {
        return new Multipliable12f(this);
    }

    public Decimal12f toImmutableDecimal() {
        return Decimal12f.valueOf(this);
    }

    public MutableDecimal12f toMutableDecimal() {
        return this;
    }
}

