/*
 * Decompiled with CFR 0.150.
 */
package org.decimal4j.factory;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import org.decimal4j.api.Decimal;
import org.decimal4j.factory.DecimalFactory;
import org.decimal4j.factory.Factories;
import org.decimal4j.immutable.Decimal5f;
import org.decimal4j.mutable.MutableDecimal5f;
import org.decimal4j.scale.Scale5f;
import org.decimal4j.scale.ScaleMetrics;

public enum Factory5f implements DecimalFactory<Scale5f>
{
    INSTANCE;


    @Override
    public final Scale5f getScaleMetrics() {
        return Scale5f.INSTANCE;
    }

    @Override
    public final int getScale() {
        return 5;
    }

    @Override
    public final Class<Decimal5f> immutableType() {
        return Decimal5f.class;
    }

    @Override
    public final Class<MutableDecimal5f> mutableType() {
        return MutableDecimal5f.class;
    }

    @Override
    public final DecimalFactory<?> deriveFactory(int scale) {
        return Factories.getDecimalFactory(scale);
    }

    @Override
    public final <S extends ScaleMetrics> DecimalFactory<S> deriveFactory(S scaleMetrics) {
        return Factories.getDecimalFactory(scaleMetrics);
    }

    public final Decimal5f valueOf(long value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(float value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(float value, RoundingMode roundingMode) {
        return Decimal5f.valueOf(value, roundingMode);
    }

    public final Decimal5f valueOf(double value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(double value, RoundingMode roundingMode) {
        return Decimal5f.valueOf(value, roundingMode);
    }

    public final Decimal5f valueOf(BigInteger value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(BigDecimal value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(BigDecimal value, RoundingMode roundingMode) {
        return Decimal5f.valueOf(value, roundingMode);
    }

    public final Decimal5f valueOf(Decimal<?> value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f valueOf(Decimal<?> value, RoundingMode roundingMode) {
        return Decimal5f.valueOf(value, roundingMode);
    }

    public final Decimal5f parse(String value) {
        return Decimal5f.valueOf(value);
    }

    public final Decimal5f parse(String value, RoundingMode roundingMode) {
        return Decimal5f.valueOf(value, roundingMode);
    }

    public final Decimal5f valueOfUnscaled(long unscaledValue) {
        return Decimal5f.valueOfUnscaled(unscaledValue);
    }

    public final Decimal5f valueOfUnscaled(long unscaledValue, int scale) {
        return Decimal5f.valueOfUnscaled(unscaledValue, scale);
    }

    public final Decimal5f valueOfUnscaled(long unscaledValue, int scale, RoundingMode roundingMode) {
        return Decimal5f.valueOfUnscaled(unscaledValue, scale, roundingMode);
    }

    public final Decimal5f[] newArray(int length) {
        return new Decimal5f[length];
    }

    public final MutableDecimal5f newMutable() {
        return new MutableDecimal5f();
    }

    public final MutableDecimal5f[] newMutableArray(int length) {
        return new MutableDecimal5f[length];
    }
}

