/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql.statements;

import kotlin.Metadata;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004\u00a8\u0006\u0005"}, d2={"Lorg/jetbrains/exposed/sql/statements/StatementGroup;", "", "(Ljava/lang/String;I)V", "DDL", "DML", "exposed-core"})
public final class StatementGroup
extends Enum<StatementGroup> {
    public static final /* enum */ StatementGroup DDL = new StatementGroup();
    public static final /* enum */ StatementGroup DML = new StatementGroup();
    private static final /* synthetic */ StatementGroup[] $VALUES;

    public static StatementGroup[] values() {
        return (StatementGroup[])$VALUES.clone();
    }

    public static StatementGroup valueOf(String value) {
        return Enum.valueOf(StatementGroup.class, value);
    }

    static {
        $VALUES = arrstatementGroup = new StatementGroup[]{StatementGroup.DDL, StatementGroup.DML};
    }
}

