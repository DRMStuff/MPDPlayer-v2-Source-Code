/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.exposed.sql.Expression;
import org.jetbrains.exposed.sql.Query;
import org.jetbrains.exposed.sql.SizedIterable;
import org.jetbrains.exposed.sql.SortOrder;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000J\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\n\n\u0002\u0010(\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u00a2\u0006\u0002\u0010\u0004J\b\u0010\u0011\u001a\u00020\tH\u0002J\b\u0010\u0005\u001a\u00020\u0006H\u0002J\u000e\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0016J\b\u0010\u0013\u001a\u00020\tH\u0016J\b\u0010\u0014\u001a\u00020\u0006H\u0016J\u000e\u0010\u0015\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0016J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00028\u00000\u0017H\u0096\u0002J\u001e\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\tH\u0016J\u000e\u0010\u001c\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H\u0016JG\u0010\u001d\u001a\b\u0012\u0004\u0012\u00028\u00000\u000222\u0010\u001e\u001a\u001a\u0012\u0016\b\u0001\u0012\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030!\u0012\u0004\u0012\u00020\"0 0\u001f\"\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030!\u0012\u0004\u0012\u00020\"0 H\u0016\u00a2\u0006\u0002\u0010#R\u0012\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0007R\u0012\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\nR\u0016\u0010\u000b\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\fX\u0088\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002X\u0088\u000e\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\f8F\u00a2\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010\u00a8\u0006$"}, d2={"Lorg/jetbrains/exposed/sql/LazySizedCollection;", "T", "Lorg/jetbrains/exposed/sql/SizedIterable;", "_delegate", "(Lorg/jetbrains/exposed/sql/SizedIterable;)V", "_empty", "", "Ljava/lang/Boolean;", "_size", "", "Ljava/lang/Long;", "_wrapper", "", "delegate", "wrapper", "getWrapper", "()Ljava/util/List;", "_count", "copy", "count", "empty", "forUpdate", "iterator", "", "limit", "n", "", "offset", "notForUpdate", "orderBy", "order", "", "Lkotlin/Pair;", "Lorg/jetbrains/exposed/sql/Expression;", "Lorg/jetbrains/exposed/sql/SortOrder;", "([Lkotlin/Pair;)Lorg/jetbrains/exposed/sql/SizedIterable;", "exposed-core"})
public final class LazySizedCollection<T>
implements SizedIterable<T> {
    @NotNull
    private SizedIterable<? extends T> delegate;
    @Nullable
    private List<? extends T> _wrapper;
    @Nullable
    private Long _size;
    @Nullable
    private Boolean _empty;

    public LazySizedCollection(@NotNull SizedIterable<? extends T> _delegate) {
        Intrinsics.checkNotNullParameter(_delegate, "_delegate");
        this.delegate = _delegate;
    }

    @NotNull
    public final List<T> getWrapper() {
        if (this._wrapper == null) {
            this._wrapper = CollectionsKt.toList((Iterable)this.delegate);
        }
        List<? extends T> list = this._wrapper;
        Intrinsics.checkNotNull(list);
        return list;
    }

    @Override
    @NotNull
    public SizedIterable<T> limit(int n, long offset) {
        return new LazySizedCollection<T>(this.delegate.limit(n, offset));
    }

    @Override
    @NotNull
    public Iterator<T> iterator() {
        return this.getWrapper().iterator();
    }

    @Override
    public long count() {
        List<T> list = this._wrapper;
        return list != null ? (long)list.size() : this._count();
    }

    @Override
    public boolean empty() {
        List<T> list = this._wrapper;
        return list != null ? list.isEmpty() : this._empty();
    }

    @Override
    @NotNull
    public SizedIterable<T> forUpdate() {
        SizedIterable<? extends T> localDelegate = this.delegate;
        if (this._wrapper != null && localDelegate instanceof Query && ((Query)localDelegate).hasCustomForUpdateState() && !((Query)localDelegate).isForUpdate()) {
            throw new IllegalStateException("Impossible to change forUpdate state for loaded data");
        }
        if (this._wrapper == null) {
            this.delegate = this.delegate.forUpdate();
        }
        return this;
    }

    @Override
    @NotNull
    public SizedIterable<T> notForUpdate() {
        SizedIterable<? extends T> localDelegate = this.delegate;
        if (this._wrapper != null && localDelegate instanceof Query && ((Query)localDelegate).hasCustomForUpdateState() && ((Query)localDelegate).isForUpdate()) {
            throw new IllegalStateException("Impossible to change forUpdate state for loaded data");
        }
        if (this._wrapper == null) {
            this.delegate = this.delegate.notForUpdate();
        }
        return this;
    }

    private final long _count() {
        if (this._size == null) {
            Long l = this._size = Long.valueOf(this.delegate.count());
            long l2 = 0L;
            this._empty = l != null && l == l2;
        }
        Long l = this._size;
        Intrinsics.checkNotNull(l);
        return l;
    }

    private final boolean _empty() {
        if (this._empty == null) {
            this._empty = this.delegate.empty();
            if (Intrinsics.areEqual(this._empty, true)) {
                this._size = 0L;
            }
        }
        Boolean bl = this._empty;
        Intrinsics.checkNotNull(bl);
        return bl;
    }

    @Override
    @NotNull
    public SizedIterable<T> copy() {
        return new LazySizedCollection<T>(this.delegate.copy());
    }

    @Override
    @NotNull
    public SizedIterable<T> orderBy(Pair<? extends Expression<?>, ? extends SortOrder> ... order) {
        Intrinsics.checkNotNullParameter(order, "order");
        if (!(this._wrapper == null)) {
            boolean bl = false;
            String string = "Can't order already loaded data";
            throw new IllegalStateException(string.toString());
        }
        this.delegate = this.delegate.orderBy(Arrays.copyOf(order, order.length));
        return this;
    }
}

