/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.exposed.exceptions.UnsupportedByDialectException;
import org.jetbrains.exposed.sql.AbstractQuery;
import org.jetbrains.exposed.sql.Intersect;
import org.jetbrains.exposed.sql.QueryBuilder;
import org.jetbrains.exposed.sql.SetOperation;
import org.jetbrains.exposed.sql.vendors.DefaultKt;
import org.jetbrains.exposed.sql.vendors.MariaDBDialect;
import org.jetbrains.exposed.sql.vendors.MysqlDialect;
import org.jetbrains.exposed.sql.vendors.OracleDialect;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\u001d\u0012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003\u0012\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0003\u00a2\u0006\u0002\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0014J\u0010\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u0012H\u0016R\u0014\u0010\u0006\u001a\u00020\u00078VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\b\u0010\t\u00a8\u0006\u0013"}, d2={"Lorg/jetbrains/exposed/sql/Except;", "Lorg/jetbrains/exposed/sql/SetOperation;", "firstStatement", "Lorg/jetbrains/exposed/sql/AbstractQuery;", "secondStatement", "(Lorg/jetbrains/exposed/sql/AbstractQuery;Lorg/jetbrains/exposed/sql/AbstractQuery;)V", "operationName", "", "getOperationName", "()Ljava/lang/String;", "copy", "Lorg/jetbrains/exposed/sql/Intersect;", "prepareStatementSQL", "", "builder", "Lorg/jetbrains/exposed/sql/QueryBuilder;", "withDistinct", "value", "", "exposed-core"})
public final class Except
extends SetOperation {
    public Except(@NotNull AbstractQuery<?> firstStatement2, @NotNull AbstractQuery<?> secondStatement) {
        Intrinsics.checkNotNullParameter(firstStatement2, "firstStatement");
        Intrinsics.checkNotNullParameter(secondStatement, "secondStatement");
        super("EXCEPT", firstStatement2, secondStatement, null);
    }

    @Override
    @NotNull
    public String getOperationName() {
        return DefaultKt.getCurrentDialect() instanceof OracleDialect ? "MINUS" : "EXCEPT";
    }

    @NotNull
    public Intersect copy() {
        Intersect intersect;
        Intersect it = intersect = new Intersect(this.getFirstStatement(), this.getSecondStatement());
        boolean bl = false;
        this.copyTo(it);
        return intersect;
    }

    @Override
    @NotNull
    public SetOperation withDistinct(boolean value) {
        return this;
    }

    @Override
    protected void prepareStatementSQL(@NotNull QueryBuilder builder) {
        Intrinsics.checkNotNullParameter(builder, "builder");
        if (DefaultKt.getCurrentDialect() instanceof MysqlDialect && !(DefaultKt.getCurrentDialect() instanceof MariaDBDialect)) {
            throw new UnsupportedByDialectException(this.getOperationName() + " is unsupported", DefaultKt.getCurrentDialect());
        }
        super.prepareStatementSQL(builder);
    }
}

