/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import kotlin.ExperimentalUnsignedTypes;
import kotlin.Metadata;
import kotlin.UInt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.text.UStringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.exposed.sql.ColumnType;
import org.jetbrains.exposed.sql.statements.api.PreparedStatementApi;
import org.jetbrains.exposed.sql.vendors.DefaultKt;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0016J\"\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0016J\b\u0010\f\u001a\u00020\rH\u0016J \u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0005\u001a\u00020\u0004H\u0016\u00f8\u0001\u0000\u00f8\u0001\u0001\u00f8\u0001\u0002\u00a2\u0006\u0004\b\u0010\u0010\u0011\u0082\u0002\u000f\n\u0002\b\u0019\n\u0002\b!\n\u0005\b\u00a1\u001e0\u0001\u00a8\u0006\u0012"}, d2={"Lorg/jetbrains/exposed/sql/UIntegerColumnType;", "Lorg/jetbrains/exposed/sql/ColumnType;", "()V", "notNullValueToDB", "", "value", "setParameter", "", "stmt", "Lorg/jetbrains/exposed/sql/statements/api/PreparedStatementApi;", "index", "", "sqlType", "", "valueFromDB", "Lkotlin/UInt;", "valueFromDB-OGnWXxg", "(Ljava/lang/Object;)I", "exposed-core"})
@ExperimentalUnsignedTypes
public final class UIntegerColumnType
extends ColumnType {
    public UIntegerColumnType() {
        super(false, 1, null);
    }

    @Override
    @NotNull
    public String sqlType() {
        return DefaultKt.getCurrentDialect().getDataTypeProvider().uintegerType();
    }

    public int valueFromDB-OGnWXxg(@NotNull Object value) {
        UInt uInt;
        Intrinsics.checkNotNullParameter(value, "value");
        Object object = value;
        if (object instanceof UInt) {
            uInt = (UInt)value;
        } else if (object instanceof Integer) {
            Object object2 = value;
            int it = ((Number)object2).intValue();
            boolean bl = false;
            Integer n = (Integer)(it >= 0 ? object2 : null);
            uInt = n != null ? UInt.box-impl(UInt.constructor-impl(n)) : null;
        } else if (object instanceof Number) {
            Integer n = ((Number)value).intValue();
            int it = ((Number)n).intValue();
            boolean bl = false;
            Integer n2 = it >= 0 ? n : null;
            uInt = n2 != null ? UInt.box-impl(UInt.constructor-impl(n2)) : null;
        } else if (object instanceof String) {
            uInt = UInt.box-impl(UStringsKt.toUInt((String)value));
        } else {
            throw new IllegalStateException(("Unexpected value of type Int: " + value + " of " + Reflection.getOrCreateKotlinClass(value.getClass()).getQualifiedName()).toString());
        }
        if (uInt == null) {
            throw new IllegalStateException(("negative value but type is UInt: " + value).toString());
        }
        return uInt.unbox-impl();
    }

    @Override
    public void setParameter(@NotNull PreparedStatementApi stmt, int index, @Nullable Object value) {
        Intrinsics.checkNotNullParameter(stmt, "stmt");
        Object v = value instanceof UInt ? Integer.valueOf(((UInt)value).unbox-impl()) : value;
        super.setParameter(stmt, index, v);
    }

    @Override
    @NotNull
    public Object notNullValueToDB(@NotNull Object value) {
        Intrinsics.checkNotNullParameter(value, "value");
        Object v = value instanceof UInt ? Integer.valueOf(((UInt)value).unbox-impl()) : value;
        return super.notNullValueToDB(v);
    }
}

