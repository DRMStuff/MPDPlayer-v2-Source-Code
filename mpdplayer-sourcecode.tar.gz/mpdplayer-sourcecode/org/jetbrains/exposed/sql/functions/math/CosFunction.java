/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql.functions.math;

import java.math.BigDecimal;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.exposed.sql.CustomFunction;
import org.jetbrains.exposed.sql.DecimalColumnType;
import org.jetbrains.exposed.sql.Expression;
import org.jetbrains.exposed.sql.ExpressionWithColumnType;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000*\n\b\u0000\u0010\u0001*\u0004\u0018\u00010\u00022\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003B\u0013\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0006\u00a2\u0006\u0002\u0010\u0007\u00a8\u0006\b"}, d2={"Lorg/jetbrains/exposed/sql/functions/math/CosFunction;", "T", "", "Lorg/jetbrains/exposed/sql/CustomFunction;", "Ljava/math/BigDecimal;", "expression", "Lorg/jetbrains/exposed/sql/ExpressionWithColumnType;", "(Lorg/jetbrains/exposed/sql/ExpressionWithColumnType;)V", "exposed-core"})
public final class CosFunction<T extends Number>
extends CustomFunction<BigDecimal> {
    public CosFunction(@NotNull ExpressionWithColumnType<T> expression) {
        Intrinsics.checkNotNullParameter(expression, "expression");
        Expression[] arrexpression = new Expression[]{expression};
        super("COS", DecimalColumnType.Companion.getINSTANCE$exposed_core(), arrexpression);
    }
}

