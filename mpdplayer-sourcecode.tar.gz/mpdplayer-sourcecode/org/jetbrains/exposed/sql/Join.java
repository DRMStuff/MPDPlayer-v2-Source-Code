/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.exposed.sql.Column;
import org.jetbrains.exposed.sql.ColumnSet;
import org.jetbrains.exposed.sql.Expression;
import org.jetbrains.exposed.sql.ExpressionKt;
import org.jetbrains.exposed.sql.Join;
import org.jetbrains.exposed.sql.JoinType;
import org.jetbrains.exposed.sql.Op;
import org.jetbrains.exposed.sql.QueryBuilder;
import org.jetbrains.exposed.sql.SqlExpressionBuilder;
import org.jetbrains.exposed.sql.Table;
import org.jetbrains.exposed.sql.Transaction;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u00011Bd\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0007\u0012!\b\u0002\u0010\t\u001a\u001b\u0012\u0004\u0012\u00020\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f\u0018\u00010\n\u00a2\u0006\u0002\b\u000e\u00a2\u0006\u0002\u0010\u000fB\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0002\u0010\u0010J\u000e\u0010\u001c\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\u001dJ\u0011\u0010\u001e\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0001H\u0096\u0004J\u0018\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$H\u0016J:\u0010%\u001a$\u0012\u001e\u0012\u001c\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0013\u0012\u000e\u0012\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00130\u00120&\u0018\u00010\u00122\u0006\u0010'\u001a\u00020\u00012\u0006\u0010(\u001a\u00020\u0001H\u0002J\u0011\u0010)\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0001H\u0096\u0004J\u0018\u0010*\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0005H\u0002J\u0011\u0010+\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0001H\u0096\u0004J_\u0010,\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00052$\u0010-\u001a \u0012\u001c\u0012\u001a\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0007\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070&j\u0002`.0\u00122\u001f\u0010\t\u001a\u001b\u0012\u0004\u0012\u00020\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f\u0018\u00010\n\u00a2\u0006\u0002\b\u000eH\u0002JU\u0010,\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00072\f\u0010\b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00072\u001f\u0010\t\u001a\u001b\u0012\u0004\u0012\u00020\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f\u0018\u00010\n\u00a2\u0006\u0002\b\u000eH\u0016J\u0011\u0010/\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0001H\u0096\u0004J\u0011\u00100\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0001H\u0096\u0004R\u001e\u0010\u0011\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00130\u00128VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017X\u0080\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001b\u00a8\u00062"}, d2={"Lorg/jetbrains/exposed/sql/Join;", "Lorg/jetbrains/exposed/sql/ColumnSet;", "table", "otherTable", "joinType", "Lorg/jetbrains/exposed/sql/JoinType;", "onColumn", "Lorg/jetbrains/exposed/sql/Expression;", "otherColumn", "additionalConstraint", "Lkotlin/Function1;", "Lorg/jetbrains/exposed/sql/SqlExpressionBuilder;", "Lorg/jetbrains/exposed/sql/Op;", "", "Lkotlin/ExtensionFunctionType;", "(Lorg/jetbrains/exposed/sql/ColumnSet;Lorg/jetbrains/exposed/sql/ColumnSet;Lorg/jetbrains/exposed/sql/JoinType;Lorg/jetbrains/exposed/sql/Expression;Lorg/jetbrains/exposed/sql/Expression;Lkotlin/jvm/functions/Function1;)V", "(Lorg/jetbrains/exposed/sql/ColumnSet;)V", "columns", "", "Lorg/jetbrains/exposed/sql/Column;", "getColumns", "()Ljava/util/List;", "joinParts", "", "Lorg/jetbrains/exposed/sql/Join$JoinPart;", "getJoinParts$exposed_core", "getTable", "()Lorg/jetbrains/exposed/sql/ColumnSet;", "alreadyInJoin", "Lorg/jetbrains/exposed/sql/Table;", "crossJoin", "describe", "", "s", "Lorg/jetbrains/exposed/sql/Transaction;", "queryBuilder", "Lorg/jetbrains/exposed/sql/QueryBuilder;", "findKeys", "Lkotlin/Pair;", "a", "b", "fullJoin", "implicitJoin", "innerJoin", "join", "cond", "Lorg/jetbrains/exposed/sql/JoinCondition;", "leftJoin", "rightJoin", "JoinPart", "exposed-core"})
public final class Join
extends ColumnSet {
    @NotNull
    private final ColumnSet table;
    @NotNull
    private final List<JoinPart> joinParts;

    public Join(@NotNull ColumnSet table) {
        Intrinsics.checkNotNullParameter(table, "table");
        this.table = table;
        this.joinParts = new ArrayList();
    }

    @NotNull
    public final ColumnSet getTable() {
        return this.table;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    @NotNull
    public List<Column<?>> getColumns() {
        void var2_2;
        void $this$flatMapTo$iv;
        Iterable iterable = this.joinParts;
        Collection destination$iv = CollectionsKt.toMutableList((Collection)this.table.getColumns());
        boolean $i$f$flatMapTo = false;
        for (Object element$iv : $this$flatMapTo$iv) {
            JoinPart it = (JoinPart)element$iv;
            boolean bl = false;
            Iterable list$iv = it.getJoinPart().getColumns();
            CollectionsKt.addAll(destination$iv, list$iv);
        }
        return (List)var2_2;
    }

    @NotNull
    public final List<JoinPart> getJoinParts$exposed_core() {
        return this.joinParts;
    }

    public Join(@NotNull ColumnSet table, @NotNull ColumnSet otherTable, @NotNull JoinType joinType, @Nullable Expression<?> onColumn, @Nullable Expression<?> otherColumn, @Nullable Function1<? super SqlExpressionBuilder, ? extends Op<Boolean>> additionalConstraint) {
        Join join;
        Intrinsics.checkNotNullParameter(table, "table");
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        Intrinsics.checkNotNullParameter((Object)joinType, "joinType");
        this(table);
        if (onColumn != null && otherColumn != null) {
            join = this.join(otherTable, joinType, onColumn, otherColumn, additionalConstraint);
        } else {
            if (onColumn != null || otherColumn != null) {
                throw new IllegalStateException(("Can't prepare join on " + table + " and " + otherTable + " when only column from a one side provided.").toString());
            }
            join = additionalConstraint != null ? this.join(otherTable, joinType, CollectionsKt.emptyList(), additionalConstraint) : this.implicitJoin(otherTable, joinType);
        }
        Join newJoin = join;
        this.joinParts.addAll((Collection<JoinPart>)newJoin.joinParts);
    }

    public /* synthetic */ Join(ColumnSet columnSet, ColumnSet columnSet2, JoinType joinType, Expression expression, Expression expression2, Function1 function1, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 4) != 0) {
            joinType = JoinType.INNER;
        }
        if ((n & 8) != 0) {
            expression = null;
        }
        if ((n & 0x10) != 0) {
            expression2 = null;
        }
        if ((n & 0x20) != 0) {
            function1 = null;
        }
        this(columnSet, columnSet2, joinType, expression, expression2, function1);
    }

    @Override
    public void describe(@NotNull Transaction s2, @NotNull QueryBuilder queryBuilder) {
        Intrinsics.checkNotNullParameter(s2, "s");
        Intrinsics.checkNotNullParameter(queryBuilder, "queryBuilder");
        queryBuilder.invoke((Function1<? super QueryBuilder, Unit>)new Function1<QueryBuilder, Unit>(this, s2){
            final /* synthetic */ Join this$0;
            final /* synthetic */ Transaction $s;
            {
                this.this$0 = $receiver;
                this.$s = $s;
                super(1);
            }

            public final void invoke(@NotNull QueryBuilder $this$invoke) {
                Intrinsics.checkNotNullParameter($this$invoke, "$this$invoke");
                this.this$0.getTable().describe(this.$s, $this$invoke);
                for (JoinPart p : this.this$0.getJoinParts$exposed_core()) {
                    $this$invoke.append("" + ' ' + (Object)((Object)p.getJoinType()) + " JOIN ");
                    boolean isJoin = p.getJoinPart() instanceof Join;
                    if (isJoin) {
                        $this$invoke.append("(");
                    }
                    p.getJoinPart().describe(this.$s, $this$invoke);
                    if (isJoin) {
                        $this$invoke.append(")");
                    }
                    if (p.getJoinType() == JoinType.CROSS) continue;
                    $this$invoke.append(" ON ");
                    p.appendConditions($this$invoke);
                }
            }
        });
    }

    @Override
    @NotNull
    public Join join(@NotNull ColumnSet otherTable, @NotNull JoinType joinType, @Nullable Expression<?> onColumn, @Nullable Expression<?> otherColumn, @Nullable Function1<? super SqlExpressionBuilder, ? extends Op<Boolean>> additionalConstraint) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        Intrinsics.checkNotNullParameter((Object)joinType, "joinType");
        List cond = onColumn != null && otherColumn != null ? CollectionsKt.listOf(new Pair(onColumn, otherColumn)) : CollectionsKt.emptyList();
        return this.join(otherTable, joinType, cond, additionalConstraint);
    }

    @Override
    @NotNull
    public Join innerJoin(@NotNull ColumnSet otherTable) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        return this.implicitJoin(otherTable, JoinType.INNER);
    }

    @Override
    @NotNull
    public Join leftJoin(@NotNull ColumnSet otherTable) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        return this.implicitJoin(otherTable, JoinType.LEFT);
    }

    @Override
    @NotNull
    public Join rightJoin(@NotNull ColumnSet otherTable) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        return this.implicitJoin(otherTable, JoinType.RIGHT);
    }

    @Override
    @NotNull
    public Join fullJoin(@NotNull ColumnSet otherTable) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        return this.implicitJoin(otherTable, JoinType.FULL);
    }

    @Override
    @NotNull
    public Join crossJoin(@NotNull ColumnSet otherTable) {
        Intrinsics.checkNotNullParameter(otherTable, "otherTable");
        return this.implicitJoin(otherTable, JoinType.CROSS);
    }

    /*
     * WARNING - void declaration
     */
    private final Join implicitJoin(ColumnSet otherTable, JoinType joinType) {
        void $this$mapTo$iv$iv;
        void $this$map$iv;
        Pair it;
        void $this$filterTo$iv$iv;
        Object element$iv2;
        boolean bl;
        List<Pair<Column<?>, List<Column<?>>>> fkKeys;
        block8: {
            List<Pair<Column<Object>, List<Column<Object>>>> list = this.findKeys(this, otherTable);
            if (list == null && (list = this.findKeys(otherTable, this)) == null) {
                list = CollectionsKt.emptyList();
            }
            fkKeys = list;
            if (joinType != JoinType.CROSS && fkKeys.isEmpty()) {
                throw new IllegalStateException(("Cannot join with " + otherTable + " as there is no matching primary key/foreign key pair and constraint missing").toString());
            }
            Iterable $this$any$iv = fkKeys;
            boolean $i$f$any = false;
            if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                bl = false;
            } else {
                for (Object element$iv2 : $this$any$iv) {
                    Pair it2 = (Pair)element$iv2;
                    boolean bl2 = false;
                    if (!(((List)it2.getSecond()).size() > 1)) continue;
                    bl = true;
                    break block8;
                }
                bl = false;
            }
        }
        if (bl) {
            String references2 = CollectionsKt.joinToString$default(fkKeys, " & ", null, null, 0, null, implicitJoin.references.1.INSTANCE, 30, null);
            throw new IllegalStateException(("Cannot join with " + otherTable + " as there is multiple primary key <-> foreign key references.\n" + references2).toString());
        }
        Iterable $this$filter$iv = fkKeys;
        boolean $i$f$filter = false;
        element$iv2 = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            it = (Pair)element$iv$iv;
            boolean bl3 = false;
            if (!(((List)it.getSecond()).size() == 1)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        $this$filter$iv = (List)destination$iv$iv;
        boolean $i$f$map = false;
        $this$filterTo$iv$iv = $this$map$iv;
        destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
        boolean $i$f$mapTo = false;
        for (Object item$iv$iv : $this$mapTo$iv$iv) {
            it = (Pair)item$iv$iv;
            Collection collection = destination$iv$iv;
            boolean bl4 = false;
            collection.add(TuplesKt.to(it.getFirst(), CollectionsKt.single((List)it.getSecond())));
        }
        List cond = (List)destination$iv$iv;
        return this.join(otherTable, joinType, cond, null);
    }

    private final Join join(ColumnSet otherTable, JoinType joinType, List<? extends Pair<? extends Expression<?>, ? extends Expression<?>>> cond, Function1<? super SqlExpressionBuilder, ? extends Op<Boolean>> additionalConstraint) {
        Join join;
        Join it = join = new Join(this.table);
        boolean bl = false;
        it.joinParts.addAll((Collection<JoinPart>)this.joinParts);
        it.joinParts.add(new JoinPart(joinType, otherTable, cond, additionalConstraint));
        return join;
    }

    /*
     * WARNING - void declaration
     */
    private final List<Pair<Column<?>, List<Column<?>>>> findKeys(ColumnSet a, ColumnSet b) {
        List list;
        void $this$filterTo$iv$iv;
        Iterable $this$mapTo$iv$iv;
        Iterable $this$map$iv = a.getColumns();
        boolean $i$f$map = false;
        Iterable iterable = $this$map$iv;
        Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
        boolean $i$f$mapTo = false;
        for (Object item$iv$iv : $this$mapTo$iv$iv) {
            void $this$filterTo$iv$iv2;
            void $this$filter$iv;
            void a_pk;
            Column column = (Column)item$iv$iv;
            Collection collection = destination$iv$iv;
            boolean bl = false;
            Iterable iterable2 = b.getColumns();
            void var13_15 = a_pk;
            boolean $i$f$filter = false;
            void var15_17 = $this$filter$iv;
            Collection destination$iv$iv2 = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv2) {
                Column it = (Column)element$iv$iv;
                boolean bl2 = false;
                if (!Intrinsics.areEqual(it.getReferee(), a_pk)) continue;
                destination$iv$iv2.add(element$iv$iv);
            }
            collection.add(TuplesKt.to(var13_15, (List)destination$iv$iv2));
        }
        Iterable $this$filter$iv = (List)destination$iv$iv;
        boolean $i$f$filter = false;
        $this$mapTo$iv$iv = $this$filter$iv;
        destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Pair it = (Pair)element$iv$iv;
            boolean bl = false;
            boolean bl3 = !((Collection)it.getSecond()).isEmpty();
            if (!bl3) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        List it = list = (List)destination$iv$iv;
        boolean bl = false;
        return !((Collection)it).isEmpty() ? list : null;
    }

    public final boolean alreadyInJoin(@NotNull Table table) {
        boolean bl;
        block3: {
            Intrinsics.checkNotNullParameter(table, "table");
            Iterable $this$any$iv = this.joinParts;
            boolean $i$f$any = false;
            if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                bl = false;
            } else {
                for (Object element$iv : $this$any$iv) {
                    JoinPart it = (JoinPart)element$iv;
                    boolean bl2 = false;
                    if (!Intrinsics.areEqual(it.getJoinPart(), table)) continue;
                    bl = true;
                    break block3;
                }
                bl = false;
            }
        }
        return bl;
    }

    @Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B^\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012$\u0010\u0006\u001a \u0012\u001c\u0012\u001a\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t0\bj\u0002`\n0\u0007\u0012!\b\u0002\u0010\u000b\u001a\u001b\u0012\u0004\u0012\u00020\r\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e\u0018\u00010\f\u00a2\u0006\u0002\b\u0010\u00a2\u0006\u0002\u0010\u0011J\u000e\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dR*\u0010\u000b\u001a\u001b\u0012\u0004\u0012\u00020\r\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u000e\u0018\u00010\f\u00a2\u0006\u0002\b\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R/\u0010\u0006\u001a \u0012\u001c\u0012\u001a\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t0\bj\u0002`\n0\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019\u00a8\u0006\u001e"}, d2={"Lorg/jetbrains/exposed/sql/Join$JoinPart;", "", "joinType", "Lorg/jetbrains/exposed/sql/JoinType;", "joinPart", "Lorg/jetbrains/exposed/sql/ColumnSet;", "conditions", "", "Lkotlin/Pair;", "Lorg/jetbrains/exposed/sql/Expression;", "Lorg/jetbrains/exposed/sql/JoinCondition;", "additionalConstraint", "Lkotlin/Function1;", "Lorg/jetbrains/exposed/sql/SqlExpressionBuilder;", "Lorg/jetbrains/exposed/sql/Op;", "", "Lkotlin/ExtensionFunctionType;", "(Lorg/jetbrains/exposed/sql/JoinType;Lorg/jetbrains/exposed/sql/ColumnSet;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "getAdditionalConstraint", "()Lkotlin/jvm/functions/Function1;", "getConditions", "()Ljava/util/List;", "getJoinPart", "()Lorg/jetbrains/exposed/sql/ColumnSet;", "getJoinType", "()Lorg/jetbrains/exposed/sql/JoinType;", "appendConditions", "", "builder", "Lorg/jetbrains/exposed/sql/QueryBuilder;", "exposed-core"})
    public static final class JoinPart {
        @NotNull
        private final JoinType joinType;
        @NotNull
        private final ColumnSet joinPart;
        @NotNull
        private final List<Pair<Expression<?>, Expression<?>>> conditions;
        @Nullable
        private final Function1<SqlExpressionBuilder, Op<Boolean>> additionalConstraint;

        public JoinPart(@NotNull JoinType joinType, @NotNull ColumnSet joinPart, @NotNull List<? extends Pair<? extends Expression<?>, ? extends Expression<?>>> conditions, @Nullable Function1<? super SqlExpressionBuilder, ? extends Op<Boolean>> additionalConstraint) {
            Intrinsics.checkNotNullParameter((Object)joinType, "joinType");
            Intrinsics.checkNotNullParameter(joinPart, "joinPart");
            Intrinsics.checkNotNullParameter(conditions, "conditions");
            this.joinType = joinType;
            this.joinPart = joinPart;
            this.conditions = conditions;
            this.additionalConstraint = additionalConstraint;
            if (!(this.joinType == JoinType.CROSS || !((Collection)this.conditions).isEmpty() || this.additionalConstraint != null)) {
                boolean bl = false;
                String string = "Missing join condition on $" + this.joinPart;
                throw new IllegalArgumentException(string.toString());
            }
        }

        public /* synthetic */ JoinPart(JoinType joinType, ColumnSet columnSet, List list, Function1 function1, int n, DefaultConstructorMarker defaultConstructorMarker) {
            if ((n & 8) != 0) {
                function1 = null;
            }
            this(joinType, columnSet, list, function1);
        }

        @NotNull
        public final JoinType getJoinType() {
            return this.joinType;
        }

        @NotNull
        public final ColumnSet getJoinPart() {
            return this.joinPart;
        }

        @NotNull
        public final List<Pair<Expression<?>, Expression<?>>> getConditions() {
            return this.conditions;
        }

        @Nullable
        public final Function1<SqlExpressionBuilder, Op<Boolean>> getAdditionalConstraint() {
            return this.additionalConstraint;
        }

        public final void appendConditions(@NotNull QueryBuilder builder) {
            Intrinsics.checkNotNullParameter(builder, "builder");
            builder.invoke((Function1<? super QueryBuilder, Unit>)new Function1<QueryBuilder, Unit>(this){
                final /* synthetic */ JoinPart this$0;
                {
                    this.this$0 = $receiver;
                    super(1);
                }

                public final void invoke(@NotNull QueryBuilder $this$invoke) {
                    Intrinsics.checkNotNullParameter($this$invoke, "$this$invoke");
                    ExpressionKt.appendTo$default(this.this$0.getConditions(), $this$invoke, " AND ", null, null, appendConditions.1.INSTANCE, 12, null);
                    if (this.this$0.getAdditionalConstraint() != null) {
                        if (!((Collection)this.this$0.getConditions()).isEmpty()) {
                            $this$invoke.append(" AND ");
                        }
                        $this$invoke.append(" (");
                        $this$invoke.append((Expression)this.this$0.getAdditionalConstraint().invoke(SqlExpressionBuilder.INSTANCE));
                        $this$invoke.append(")");
                    }
                }
            });
        }
    }
}

