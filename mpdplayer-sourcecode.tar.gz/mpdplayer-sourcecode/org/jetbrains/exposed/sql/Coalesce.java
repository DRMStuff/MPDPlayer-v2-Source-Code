/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import java.util.Collection;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.exposed.sql.Coalesce;
import org.jetbrains.exposed.sql.Expression;
import org.jetbrains.exposed.sql.ExpressionWithColumnType;
import org.jetbrains.exposed.sql.Function;
import org.jetbrains.exposed.sql.QueryBuilder;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u0001*\n\b\u0001\u0010\u0002*\u0004\u0018\u0001H\u0001*\b\b\u0002\u0010\u0003*\u0002H\u00012\b\u0012\u0004\u0012\u0002H\u00030\u0004BG\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00010\u0006\u0012\u000e\u0010\u0007\u001a\n\u0012\u0006\b\u0001\u0012\u00028\u00000\b\u0012\"\u0010\t\u001a\u0012\u0012\u000e\b\u0001\u0012\n\u0012\u0006\b\u0001\u0012\u00028\u00000\b0\n\"\n\u0012\u0006\b\u0001\u0012\u00028\u00000\b\u00a2\u0006\u0002\u0010\u000bJ\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u0016\u0010\u0007\u001a\n\u0012\u0006\b\u0001\u0012\u00028\u00000\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00010\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\t\u001a\u0012\u0012\u000e\b\u0001\u0012\n\u0012\u0006\b\u0001\u0012\u00028\u00000\b0\nX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\f\u00a8\u0006\u0011"}, d2={"Lorg/jetbrains/exposed/sql/Coalesce;", "T", "S", "R", "Lorg/jetbrains/exposed/sql/Function;", "expr", "Lorg/jetbrains/exposed/sql/ExpressionWithColumnType;", "alternate", "Lorg/jetbrains/exposed/sql/Expression;", "others", "", "(Lorg/jetbrains/exposed/sql/ExpressionWithColumnType;Lorg/jetbrains/exposed/sql/Expression;[Lorg/jetbrains/exposed/sql/Expression;)V", "[Lorg/jetbrains/exposed/sql/Expression;", "toQueryBuilder", "", "queryBuilder", "Lorg/jetbrains/exposed/sql/QueryBuilder;", "exposed-core"})
public final class Coalesce<T, S extends T, R extends T>
extends Function<R> {
    @NotNull
    private final ExpressionWithColumnType<S> expr;
    @NotNull
    private final Expression<? extends T> alternate;
    @NotNull
    private final Expression<? extends T>[] others;

    public Coalesce(@NotNull ExpressionWithColumnType<S> expr, @NotNull Expression<? extends T> alternate, Expression<? extends T> ... others) {
        Intrinsics.checkNotNullParameter(expr, "expr");
        Intrinsics.checkNotNullParameter(alternate, "alternate");
        Intrinsics.checkNotNullParameter(others, "others");
        super(expr.getColumnType());
        this.expr = expr;
        this.alternate = alternate;
        this.others = others;
    }

    @Override
    public void toQueryBuilder(@NotNull QueryBuilder queryBuilder) {
        Intrinsics.checkNotNullParameter(queryBuilder, "queryBuilder");
        queryBuilder.invoke((Function1<? super QueryBuilder, Unit>)new Function1<QueryBuilder, Unit>(this){
            final /* synthetic */ Coalesce<T, S, R> this$0;
            {
                this.this$0 = $receiver;
                super(1);
            }

            public final void invoke(@NotNull QueryBuilder $this$invoke) {
                Intrinsics.checkNotNullParameter($this$invoke, "$this$invoke");
                Expression[] arrexpression = new Expression[]{Coalesce.access$getExpr$p(this.this$0), Coalesce.access$getAlternate$p(this.this$0)};
                $this$invoke.appendTo((Iterable)CollectionsKt.plus((Collection)CollectionsKt.listOf(arrexpression), Coalesce.access$getOthers$p(this.this$0)), (CharSequence)", ", (CharSequence)"COALESCE(", (CharSequence)")", (Function2)toQueryBuilder.1.INSTANCE);
            }
        });
    }

    public static final /* synthetic */ ExpressionWithColumnType access$getExpr$p(Coalesce $this) {
        return $this.expr;
    }

    public static final /* synthetic */ Expression access$getAlternate$p(Coalesce $this) {
        return $this.alternate;
    }

    public static final /* synthetic */ Expression[] access$getOthers$p(Coalesce $this) {
        return $this.others;
    }
}

