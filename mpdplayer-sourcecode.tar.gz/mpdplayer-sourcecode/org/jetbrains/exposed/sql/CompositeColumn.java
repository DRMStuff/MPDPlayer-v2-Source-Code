/*
 * Decompiled with CFR 0.150.
 */
package org.jetbrains.exposed.sql;

import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.exposed.sql.Column;
import org.jetbrains.exposed.sql.CompositeColumn;
import org.jetbrains.exposed.sql.Expression;
import org.jetbrains.exposed.sql.QueryBuilder;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b&\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u0005\u00a2\u0006\u0002\u0010\u0003J\u0012\u0010\n\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\f0\u000bH&J'\u0010\r\u001a\u0014\u0012\b\u0012\u0006\u0012\u0002\b\u00030\f\u0012\u0006\u0012\u0004\u0018\u00010\u000f0\u000e2\u0006\u0010\u0010\u001a\u00028\u0000H&\u00a2\u0006\u0002\u0010\u0011J'\u0010\u0012\u001a\u00028\u00002\u0018\u0010\u0013\u001a\u0014\u0012\b\u0012\u0006\u0012\u0002\b\u00030\f\u0012\u0006\u0012\u0004\u0018\u00010\u000f0\u000eH&\u00a2\u0006\u0002\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018H\u0016R\u001a\u0010\u0004\u001a\u00020\u0005X\u0080\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t\u00a8\u0006\u0019"}, d2={"Lorg/jetbrains/exposed/sql/CompositeColumn;", "T", "Lorg/jetbrains/exposed/sql/Expression;", "()V", "nullable", "", "getNullable$exposed_core", "()Z", "setNullable$exposed_core", "(Z)V", "getRealColumns", "", "Lorg/jetbrains/exposed/sql/Column;", "getRealColumnsWithValues", "", "", "compositeValue", "(Ljava/lang/Object;)Ljava/util/Map;", "restoreValueFromParts", "parts", "(Ljava/util/Map;)Ljava/lang/Object;", "toQueryBuilder", "", "queryBuilder", "Lorg/jetbrains/exposed/sql/QueryBuilder;", "exposed-core"})
public abstract class CompositeColumn<T>
extends Expression<T> {
    private boolean nullable;

    public final boolean getNullable$exposed_core() {
        return this.nullable;
    }

    public final void setNullable$exposed_core(boolean bl) {
        this.nullable = bl;
    }

    @NotNull
    public abstract Map<Column<?>, Object> getRealColumnsWithValues(T var1);

    @NotNull
    public abstract List<Column<?>> getRealColumns();

    public abstract T restoreValueFromParts(@NotNull Map<Column<?>, ? extends Object> var1);

    @Override
    public void toQueryBuilder(@NotNull QueryBuilder queryBuilder) {
        Intrinsics.checkNotNullParameter(queryBuilder, "queryBuilder");
        queryBuilder.invoke((Function1<? super QueryBuilder, Unit>)new Function1<QueryBuilder, Unit>(this){
            final /* synthetic */ CompositeColumn<T> this$0;
            {
                this.this$0 = $receiver;
                super(1);
            }

            public final void invoke(@NotNull QueryBuilder $this$invoke) {
                Intrinsics.checkNotNullParameter($this$invoke, "$this$invoke");
                QueryBuilder.appendTo$default($this$invoke, this.this$0.getRealColumns(), null, null, null, (Function2)toQueryBuilder.1.INSTANCE, 7, null);
            }
        });
    }
}

