/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.descriptors.annotations;

import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotated;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotations;
import org.jetbrains.annotations.NotNull;

public class AnnotatedImpl
implements Annotated {
    private final Annotations annotations;

    public AnnotatedImpl(@NotNull Annotations annotations2) {
        if (annotations2 == null) {
            AnnotatedImpl.$$$reportNull$$$0(0);
        }
        this.annotations = annotations2;
    }

    @Override
    @NotNull
    public Annotations getAnnotations() {
        Annotations annotations2 = this.annotations;
        if (annotations2 == null) {
            AnnotatedImpl.$$$reportNull$$$0(1);
        }
        return annotations2;
    }

    private static /* synthetic */ void $$$reportNull$$$0(int n) {
        RuntimeException runtimeException;
        Object[] arrobject;
        Object[] arrobject2;
        int n2;
        String string;
        switch (n) {
            default: {
                string = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
                break;
            }
            case 1: {
                string = "@NotNull method %s.%s must not return null";
                break;
            }
        }
        switch (n) {
            default: {
                n2 = 3;
                break;
            }
            case 1: {
                n2 = 2;
                break;
            }
        }
        Object[] arrobject3 = new Object[n2];
        switch (n) {
            default: {
                arrobject2 = arrobject3;
                arrobject3[0] = "annotations";
                break;
            }
            case 1: {
                arrobject2 = arrobject3;
                arrobject3[0] = "kotlin/reflect/jvm/internal/impl/descriptors/annotations/AnnotatedImpl";
                break;
            }
        }
        switch (n) {
            default: {
                arrobject = arrobject2;
                arrobject2[1] = "kotlin/reflect/jvm/internal/impl/descriptors/annotations/AnnotatedImpl";
                break;
            }
            case 1: {
                arrobject = arrobject2;
                arrobject2[1] = "getAnnotations";
                break;
            }
        }
        switch (n) {
            default: {
                arrobject = arrobject;
                arrobject[2] = "<init>";
                break;
            }
            case 1: {
                break;
            }
        }
        String string2 = String.format(string, arrobject);
        switch (n) {
            default: {
                runtimeException = new IllegalArgumentException(string2);
                break;
            }
            case 1: {
                runtimeException = new IllegalStateException(string2);
                break;
            }
        }
        throw runtimeException;
    }
}

