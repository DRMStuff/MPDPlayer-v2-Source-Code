/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.descriptors;

import kotlin.reflect.jvm.internal.impl.descriptors.VariableDescriptor;

public interface VariableDescriptorWithAccessors
extends VariableDescriptor {
    public boolean isDelegated();
}

