/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.descriptors.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import kotlin.jvm.functions.Function0;
import kotlin.reflect.jvm.internal.impl.builtins.KotlinBuiltIns;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassifierDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptorVisitor;
import kotlin.reflect.jvm.internal.impl.descriptors.SourceElement;
import kotlin.reflect.jvm.internal.impl.descriptors.SupertypeLoopChecker;
import kotlin.reflect.jvm.internal.impl.descriptors.TypeParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotations;
import kotlin.reflect.jvm.internal.impl.descriptors.impl.DeclarationDescriptorNonRootImpl;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.resolve.DescriptorEquivalenceForOverrides;
import kotlin.reflect.jvm.internal.impl.resolve.descriptorUtil.DescriptorUtilsKt;
import kotlin.reflect.jvm.internal.impl.resolve.scopes.LazyScopeAdapter;
import kotlin.reflect.jvm.internal.impl.resolve.scopes.MemberScope;
import kotlin.reflect.jvm.internal.impl.resolve.scopes.TypeIntersectionScope;
import kotlin.reflect.jvm.internal.impl.storage.NotNullLazyValue;
import kotlin.reflect.jvm.internal.impl.storage.StorageManager;
import kotlin.reflect.jvm.internal.impl.types.AbstractTypeConstructor;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.reflect.jvm.internal.impl.types.KotlinTypeFactory;
import kotlin.reflect.jvm.internal.impl.types.SimpleType;
import kotlin.reflect.jvm.internal.impl.types.TypeAttributes;
import kotlin.reflect.jvm.internal.impl.types.TypeConstructor;
import kotlin.reflect.jvm.internal.impl.types.Variance;
import kotlin.reflect.jvm.internal.impl.types.error.ErrorTypeKind;
import kotlin.reflect.jvm.internal.impl.types.error.ErrorUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractTypeParameterDescriptor
extends DeclarationDescriptorNonRootImpl
implements TypeParameterDescriptor {
    private final Variance variance;
    private final boolean reified;
    private final int index;
    private final NotNullLazyValue<TypeConstructor> typeConstructor;
    private final NotNullLazyValue<SimpleType> defaultType;
    private final StorageManager storageManager;

    protected AbstractTypeParameterDescriptor(final @NotNull StorageManager storageManager, @NotNull DeclarationDescriptor containingDeclaration, @NotNull Annotations annotations2, final @NotNull Name name, @NotNull Variance variance, boolean isReified, int index, @NotNull SourceElement source2, final @NotNull SupertypeLoopChecker supertypeLoopChecker) {
        if (storageManager == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(0);
        }
        if (containingDeclaration == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(1);
        }
        if (annotations2 == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(2);
        }
        if (name == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(3);
        }
        if (variance == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(4);
        }
        if (source2 == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(5);
        }
        if (supertypeLoopChecker == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(6);
        }
        super(containingDeclaration, annotations2, name, source2);
        this.variance = variance;
        this.reified = isReified;
        this.index = index;
        this.typeConstructor = storageManager.createLazyValue(new Function0<TypeConstructor>(){

            @Override
            public TypeConstructor invoke() {
                return new TypeParameterTypeConstructor(storageManager, supertypeLoopChecker);
            }
        });
        this.defaultType = storageManager.createLazyValue(new Function0<SimpleType>(){

            @Override
            public SimpleType invoke() {
                return KotlinTypeFactory.simpleTypeWithNonTrivialMemberScope(TypeAttributes.Companion.getEmpty(), AbstractTypeParameterDescriptor.this.getTypeConstructor(), Collections.emptyList(), false, new LazyScopeAdapter((Function0<? extends MemberScope>)new Function0<MemberScope>(){

                    @Override
                    public MemberScope invoke() {
                        return TypeIntersectionScope.create("Scope for type parameter " + name.asString(), AbstractTypeParameterDescriptor.this.getUpperBounds());
                    }
                }));
            }
        });
        this.storageManager = storageManager;
    }

    protected abstract void reportSupertypeLoopError(@NotNull KotlinType var1);

    @NotNull
    protected abstract List<KotlinType> resolveUpperBounds();

    @Override
    @NotNull
    public Variance getVariance() {
        Variance variance = this.variance;
        if (variance == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(7);
        }
        return variance;
    }

    @Override
    public boolean isReified() {
        return this.reified;
    }

    @Override
    public int getIndex() {
        return this.index;
    }

    @Override
    public boolean isCapturedFromOuterDeclaration() {
        return false;
    }

    @Override
    @NotNull
    public List<KotlinType> getUpperBounds() {
        Collection collection = ((TypeParameterTypeConstructor)this.getTypeConstructor()).getSupertypes();
        if (collection == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(8);
        }
        return collection;
    }

    @Override
    @NotNull
    public final TypeConstructor getTypeConstructor() {
        TypeConstructor typeConstructor2 = (TypeConstructor)this.typeConstructor.invoke();
        if (typeConstructor2 == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(9);
        }
        return typeConstructor2;
    }

    @Override
    @NotNull
    public SimpleType getDefaultType() {
        SimpleType simpleType2 = (SimpleType)this.defaultType.invoke();
        if (simpleType2 == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(10);
        }
        return simpleType2;
    }

    @Override
    @NotNull
    public TypeParameterDescriptor getOriginal() {
        TypeParameterDescriptor typeParameterDescriptor = (TypeParameterDescriptor)super.getOriginal();
        if (typeParameterDescriptor == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(11);
        }
        return typeParameterDescriptor;
    }

    @NotNull
    protected List<KotlinType> processBoundsWithoutCycles(@NotNull List<KotlinType> bounds) {
        if (bounds == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(12);
        }
        List<KotlinType> list = bounds;
        if (list == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(13);
        }
        return list;
    }

    @Override
    public <R, D> R accept(DeclarationDescriptorVisitor<R, D> visitor2, D data2) {
        return visitor2.visitTypeParameterDescriptor(this, data2);
    }

    @Override
    @NotNull
    public StorageManager getStorageManager() {
        StorageManager storageManager = this.storageManager;
        if (storageManager == null) {
            AbstractTypeParameterDescriptor.$$$reportNull$$$0(14);
        }
        return storageManager;
    }

    private static /* synthetic */ void $$$reportNull$$$0(int n) {
        RuntimeException runtimeException;
        Object[] arrobject;
        Object[] arrobject2;
        int n2;
        String string;
        switch (n) {
            default: {
                string = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
                break;
            }
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 13: 
            case 14: {
                string = "@NotNull method %s.%s must not return null";
                break;
            }
        }
        switch (n) {
            default: {
                n2 = 3;
                break;
            }
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 13: 
            case 14: {
                n2 = 2;
                break;
            }
        }
        Object[] arrobject3 = new Object[n2];
        switch (n) {
            default: {
                arrobject2 = arrobject3;
                arrobject3[0] = "storageManager";
                break;
            }
            case 1: {
                arrobject2 = arrobject3;
                arrobject3[0] = "containingDeclaration";
                break;
            }
            case 2: {
                arrobject2 = arrobject3;
                arrobject3[0] = "annotations";
                break;
            }
            case 3: {
                arrobject2 = arrobject3;
                arrobject3[0] = "name";
                break;
            }
            case 4: {
                arrobject2 = arrobject3;
                arrobject3[0] = "variance";
                break;
            }
            case 5: {
                arrobject2 = arrobject3;
                arrobject3[0] = "source";
                break;
            }
            case 6: {
                arrobject2 = arrobject3;
                arrobject3[0] = "supertypeLoopChecker";
                break;
            }
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 13: 
            case 14: {
                arrobject2 = arrobject3;
                arrobject3[0] = "kotlin/reflect/jvm/internal/impl/descriptors/impl/AbstractTypeParameterDescriptor";
                break;
            }
            case 12: {
                arrobject2 = arrobject3;
                arrobject3[0] = "bounds";
                break;
            }
        }
        switch (n) {
            default: {
                arrobject = arrobject2;
                arrobject2[1] = "kotlin/reflect/jvm/internal/impl/descriptors/impl/AbstractTypeParameterDescriptor";
                break;
            }
            case 7: {
                arrobject = arrobject2;
                arrobject2[1] = "getVariance";
                break;
            }
            case 8: {
                arrobject = arrobject2;
                arrobject2[1] = "getUpperBounds";
                break;
            }
            case 9: {
                arrobject = arrobject2;
                arrobject2[1] = "getTypeConstructor";
                break;
            }
            case 10: {
                arrobject = arrobject2;
                arrobject2[1] = "getDefaultType";
                break;
            }
            case 11: {
                arrobject = arrobject2;
                arrobject2[1] = "getOriginal";
                break;
            }
            case 13: {
                arrobject = arrobject2;
                arrobject2[1] = "processBoundsWithoutCycles";
                break;
            }
            case 14: {
                arrobject = arrobject2;
                arrobject2[1] = "getStorageManager";
                break;
            }
        }
        switch (n) {
            default: {
                arrobject = arrobject;
                arrobject[2] = "<init>";
                break;
            }
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 13: 
            case 14: {
                break;
            }
            case 12: {
                arrobject = arrobject;
                arrobject[2] = "processBoundsWithoutCycles";
                break;
            }
        }
        String string2 = String.format(string, arrobject);
        switch (n) {
            default: {
                runtimeException = new IllegalArgumentException(string2);
                break;
            }
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 13: 
            case 14: {
                runtimeException = new IllegalStateException(string2);
                break;
            }
        }
        throw runtimeException;
    }

    private class TypeParameterTypeConstructor
    extends AbstractTypeConstructor {
        private final SupertypeLoopChecker supertypeLoopChecker;

        public TypeParameterTypeConstructor(StorageManager storageManager, SupertypeLoopChecker supertypeLoopChecker) {
            if (storageManager == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(0);
            }
            super(storageManager);
            this.supertypeLoopChecker = supertypeLoopChecker;
        }

        @Override
        @NotNull
        protected Collection<KotlinType> computeSupertypes() {
            List<KotlinType> list = AbstractTypeParameterDescriptor.this.resolveUpperBounds();
            if (list == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(1);
            }
            return list;
        }

        @Override
        @NotNull
        public List<TypeParameterDescriptor> getParameters() {
            List<TypeParameterDescriptor> list = Collections.emptyList();
            if (list == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(2);
            }
            return list;
        }

        @Override
        public boolean isDenotable() {
            return true;
        }

        @Override
        @NotNull
        public ClassifierDescriptor getDeclarationDescriptor() {
            AbstractTypeParameterDescriptor abstractTypeParameterDescriptor = AbstractTypeParameterDescriptor.this;
            if (abstractTypeParameterDescriptor == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(3);
            }
            return abstractTypeParameterDescriptor;
        }

        @Override
        @NotNull
        public KotlinBuiltIns getBuiltIns() {
            KotlinBuiltIns kotlinBuiltIns = DescriptorUtilsKt.getBuiltIns(AbstractTypeParameterDescriptor.this);
            if (kotlinBuiltIns == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(4);
            }
            return kotlinBuiltIns;
        }

        public String toString() {
            return AbstractTypeParameterDescriptor.this.getName().toString();
        }

        @Override
        @NotNull
        protected SupertypeLoopChecker getSupertypeLoopChecker() {
            SupertypeLoopChecker supertypeLoopChecker = this.supertypeLoopChecker;
            if (supertypeLoopChecker == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(5);
            }
            return supertypeLoopChecker;
        }

        @Override
        protected void reportSupertypeLoopError(@NotNull KotlinType type2) {
            if (type2 == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(6);
            }
            AbstractTypeParameterDescriptor.this.reportSupertypeLoopError(type2);
        }

        @Override
        @NotNull
        protected List<KotlinType> processSupertypesWithoutCycles(@NotNull List<KotlinType> supertypes2) {
            if (supertypes2 == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(7);
            }
            List<KotlinType> list = AbstractTypeParameterDescriptor.this.processBoundsWithoutCycles(supertypes2);
            if (list == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(8);
            }
            return list;
        }

        @Override
        @Nullable
        protected KotlinType defaultSupertypeIfEmpty() {
            return ErrorUtils.createErrorType(ErrorTypeKind.CYCLIC_UPPER_BOUNDS, new String[0]);
        }

        @Override
        protected boolean isSameClassifier(@NotNull ClassifierDescriptor classifier2) {
            if (classifier2 == null) {
                TypeParameterTypeConstructor.$$$reportNull$$$0(9);
            }
            return classifier2 instanceof TypeParameterDescriptor && DescriptorEquivalenceForOverrides.INSTANCE.areTypeParametersEquivalent(AbstractTypeParameterDescriptor.this, (TypeParameterDescriptor)classifier2, true);
        }

        private static /* synthetic */ void $$$reportNull$$$0(int n) {
            RuntimeException runtimeException;
            Object[] arrobject;
            Object[] arrobject2;
            int n2;
            String string;
            switch (n) {
                default: {
                    string = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 8: {
                    string = "@NotNull method %s.%s must not return null";
                    break;
                }
            }
            switch (n) {
                default: {
                    n2 = 3;
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 8: {
                    n2 = 2;
                    break;
                }
            }
            Object[] arrobject3 = new Object[n2];
            switch (n) {
                default: {
                    arrobject2 = arrobject3;
                    arrobject3[0] = "storageManager";
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 8: {
                    arrobject2 = arrobject3;
                    arrobject3[0] = "kotlin/reflect/jvm/internal/impl/descriptors/impl/AbstractTypeParameterDescriptor$TypeParameterTypeConstructor";
                    break;
                }
                case 6: {
                    arrobject2 = arrobject3;
                    arrobject3[0] = "type";
                    break;
                }
                case 7: {
                    arrobject2 = arrobject3;
                    arrobject3[0] = "supertypes";
                    break;
                }
                case 9: {
                    arrobject2 = arrobject3;
                    arrobject3[0] = "classifier";
                    break;
                }
            }
            switch (n) {
                default: {
                    arrobject = arrobject2;
                    arrobject2[1] = "kotlin/reflect/jvm/internal/impl/descriptors/impl/AbstractTypeParameterDescriptor$TypeParameterTypeConstructor";
                    break;
                }
                case 1: {
                    arrobject = arrobject2;
                    arrobject2[1] = "computeSupertypes";
                    break;
                }
                case 2: {
                    arrobject = arrobject2;
                    arrobject2[1] = "getParameters";
                    break;
                }
                case 3: {
                    arrobject = arrobject2;
                    arrobject2[1] = "getDeclarationDescriptor";
                    break;
                }
                case 4: {
                    arrobject = arrobject2;
                    arrobject2[1] = "getBuiltIns";
                    break;
                }
                case 5: {
                    arrobject = arrobject2;
                    arrobject2[1] = "getSupertypeLoopChecker";
                    break;
                }
                case 8: {
                    arrobject = arrobject2;
                    arrobject2[1] = "processSupertypesWithoutCycles";
                    break;
                }
            }
            switch (n) {
                default: {
                    arrobject = arrobject;
                    arrobject[2] = "<init>";
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 8: {
                    break;
                }
                case 6: {
                    arrobject = arrobject;
                    arrobject[2] = "reportSupertypeLoopError";
                    break;
                }
                case 7: {
                    arrobject = arrobject;
                    arrobject[2] = "processSupertypesWithoutCycles";
                    break;
                }
                case 9: {
                    arrobject = arrobject;
                    arrobject[2] = "isSameClassifier";
                    break;
                }
            }
            String string2 = String.format(string, arrobject);
            switch (n) {
                default: {
                    runtimeException = new IllegalArgumentException(string2);
                    break;
                }
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: 
                case 8: {
                    runtimeException = new IllegalStateException(string2);
                    break;
                }
            }
            throw runtimeException;
        }
    }
}

