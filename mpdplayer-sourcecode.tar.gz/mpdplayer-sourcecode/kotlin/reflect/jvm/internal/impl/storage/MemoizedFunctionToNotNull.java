/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.storage;

import kotlin.jvm.functions.Function1;

public interface MemoizedFunctionToNotNull<P, R>
extends Function1<P, R> {
}

