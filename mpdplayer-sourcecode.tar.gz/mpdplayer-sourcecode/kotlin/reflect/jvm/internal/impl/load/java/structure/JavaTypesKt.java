/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.load.java.structure;

import kotlin.reflect.jvm.internal.impl.load.java.structure.JavaType;
import kotlin.reflect.jvm.internal.impl.load.java.structure.JavaWildcardType;
import org.jetbrains.annotations.Nullable;

public final class JavaTypesKt {
    public static final boolean isSuperWildcard(@Nullable JavaType $this$isSuperWildcard) {
        boolean bl;
        JavaWildcardType javaWildcardType = $this$isSuperWildcard instanceof JavaWildcardType ? (JavaWildcardType)$this$isSuperWildcard : null;
        if (javaWildcardType != null) {
            JavaWildcardType it = javaWildcardType;
            boolean bl2 = false;
            bl = it.getBound() != null && !it.isExtends();
        } else {
            bl = false;
        }
        return bl;
    }
}

