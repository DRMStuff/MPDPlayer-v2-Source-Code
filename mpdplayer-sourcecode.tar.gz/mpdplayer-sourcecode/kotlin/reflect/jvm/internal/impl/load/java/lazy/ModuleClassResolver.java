/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.load.java.lazy;

import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.load.java.structure.JavaClass;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface ModuleClassResolver {
    @Nullable
    public ClassDescriptor resolveClass(@NotNull JavaClass var1);
}

