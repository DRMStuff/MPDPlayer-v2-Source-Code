/*
 * Decompiled with CFR 0.150.
 */
package kotlin.reflect.jvm.internal.impl.metadata;

import kotlin.reflect.jvm.internal.impl.protobuf.GeneratedMessageLite;

public interface ProtoBuf$FunctionOrBuilder
extends GeneratedMessageLite.ExtendableMessageOrBuilder {
}

