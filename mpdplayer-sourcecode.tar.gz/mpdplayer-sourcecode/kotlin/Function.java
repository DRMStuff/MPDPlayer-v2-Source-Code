/*
 * Decompiled with CFR 0.150.
 */
package kotlin;

import kotlin.Metadata;

@Metadata(mv={1, 7, 1}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\bf\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u00020\u0002\u00a8\u0006\u0003"}, d2={"Lkotlin/Function;", "R", "", "kotlin-stdlib"})
public interface Function<R> {
}

