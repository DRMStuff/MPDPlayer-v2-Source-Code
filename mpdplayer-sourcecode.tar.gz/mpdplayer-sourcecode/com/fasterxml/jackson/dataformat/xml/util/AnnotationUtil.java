/*
 * Decompiled with CFR 0.150.
 */
package com.fasterxml.jackson.dataformat.xml.util;

import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;

public class AnnotationUtil {
    public static String findNamespaceAnnotation(MapperConfig<?> config2, AnnotationIntrospector ai, AnnotatedMember prop) {
        for (AnnotationIntrospector intr : ai.allIntrospectors()) {
            String ns;
            if (!(intr instanceof AnnotationIntrospector.XmlExtensions) || (ns = ((AnnotationIntrospector.XmlExtensions)((Object)intr)).findNamespace(config2, prop)) == null) continue;
            return ns;
        }
        return null;
    }

    public static Boolean findIsAttributeAnnotation(MapperConfig<?> config2, AnnotationIntrospector ai, AnnotatedMember prop) {
        for (AnnotationIntrospector intr : ai.allIntrospectors()) {
            Boolean b;
            if (!(intr instanceof AnnotationIntrospector.XmlExtensions) || (b = ((AnnotationIntrospector.XmlExtensions)((Object)intr)).isOutputAsAttribute(config2, prop)) == null) continue;
            return b;
        }
        return null;
    }

    public static Boolean findIsTextAnnotation(MapperConfig<?> config2, AnnotationIntrospector ai, AnnotatedMember prop) {
        for (AnnotationIntrospector intr : ai.allIntrospectors()) {
            Boolean b;
            if (!(intr instanceof AnnotationIntrospector.XmlExtensions) || (b = ((AnnotationIntrospector.XmlExtensions)((Object)intr)).isOutputAsText(config2, prop)) == null) continue;
            return b;
        }
        return null;
    }

    public static Boolean findIsCDataAnnotation(MapperConfig<?> config2, AnnotationIntrospector ai, AnnotatedMember prop) {
        for (AnnotationIntrospector intr : ai.allIntrospectors()) {
            Boolean b;
            if (!(intr instanceof AnnotationIntrospector.XmlExtensions) || (b = ((AnnotationIntrospector.XmlExtensions)((Object)intr)).isOutputAsCData(config2, prop)) == null) continue;
            return b;
        }
        return null;
    }
}

