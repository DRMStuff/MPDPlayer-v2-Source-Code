/*
 * Decompiled with CFR 0.150.
 */
package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.DeserializationConfig;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.KeyDeserializer;
import com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.databind.type.ArrayType;
import com.fasterxml.jackson.databind.type.CollectionLikeType;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.MapLikeType;
import com.fasterxml.jackson.databind.type.MapType;
import com.fasterxml.jackson.databind.type.ReferenceType;
import java.util.List;

public abstract class BeanDeserializerModifier {
    public List<BeanPropertyDefinition> updateProperties(DeserializationConfig config2, BeanDescription beanDesc, List<BeanPropertyDefinition> propDefs) {
        return propDefs;
    }

    public BeanDeserializerBuilder updateBuilder(DeserializationConfig config2, BeanDescription beanDesc, BeanDeserializerBuilder builder) {
        return builder;
    }

    public JsonDeserializer<?> modifyDeserializer(DeserializationConfig config2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyEnumDeserializer(DeserializationConfig config2, JavaType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyReferenceDeserializer(DeserializationConfig config2, ReferenceType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyArrayDeserializer(DeserializationConfig config2, ArrayType valueType, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyCollectionDeserializer(DeserializationConfig config2, CollectionType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyCollectionLikeDeserializer(DeserializationConfig config2, CollectionLikeType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyMapDeserializer(DeserializationConfig config2, MapType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public JsonDeserializer<?> modifyMapLikeDeserializer(DeserializationConfig config2, MapLikeType type2, BeanDescription beanDesc, JsonDeserializer<?> deserializer) {
        return deserializer;
    }

    public KeyDeserializer modifyKeyDeserializer(DeserializationConfig config2, JavaType type2, KeyDeserializer deserializer) {
        return deserializer;
    }
}

