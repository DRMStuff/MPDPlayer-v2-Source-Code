/*
 * Decompiled with CFR 0.150.
 */
package com.fasterxml.jackson.databind.ser;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerator;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.TokenStreamFactory;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.BeanDescription;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DatabindContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.PropertyMetadata;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.SerializationConfig;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
import com.fasterxml.jackson.databind.introspect.AnnotatedField;
import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.ser.AnyGetterWriter;
import com.fasterxml.jackson.databind.ser.BasicSerializerFactory;
import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
import com.fasterxml.jackson.databind.ser.BeanSerializerBuilder;
import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
import com.fasterxml.jackson.databind.ser.PropertyBuilder;
import com.fasterxml.jackson.databind.ser.ResolvableSerializer;
import com.fasterxml.jackson.databind.ser.SerializerFactory;
import com.fasterxml.jackson.databind.ser.Serializers;
import com.fasterxml.jackson.databind.ser.impl.FilteredBeanPropertyWriter;
import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
import com.fasterxml.jackson.databind.ser.impl.UnsupportedTypeSerializer;
import com.fasterxml.jackson.databind.ser.std.MapSerializer;
import com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer;
import com.fasterxml.jackson.databind.ser.std.ToEmptyObjectSerializer;
import com.fasterxml.jackson.databind.type.ReferenceType;
import com.fasterxml.jackson.databind.util.BeanUtil;
import com.fasterxml.jackson.databind.util.ClassUtil;
import com.fasterxml.jackson.databind.util.Converter;
import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class BeanSerializerFactory
extends BasicSerializerFactory
implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);

    protected BeanSerializerFactory(SerializerFactoryConfig config2) {
        super(config2);
    }

    @Override
    public SerializerFactory withConfig(SerializerFactoryConfig config2) {
        if (this._factoryConfig == config2) {
            return this;
        }
        if (this.getClass() != BeanSerializerFactory.class) {
            throw new IllegalStateException("Subtype of BeanSerializerFactory (" + this.getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': cannot instantiate subtype with additional serializer definitions");
        }
        return new BeanSerializerFactory(config2);
    }

    @Override
    protected Iterable<Serializers> customSerializers() {
        return this._factoryConfig.serializers();
    }

    @Override
    public JsonSerializer<Object> createSerializer(SerializerProvider prov, JavaType origType) throws JsonMappingException {
        boolean staticTyping;
        JavaType type2;
        SerializationConfig config2 = prov.getConfig();
        BeanDescription beanDesc = config2.introspect(origType);
        JsonSerializer<Object> ser = this.findSerializerFromAnnotation(prov, beanDesc.getClassInfo());
        if (ser != null) {
            return ser;
        }
        AnnotationIntrospector intr = config2.getAnnotationIntrospector();
        if (intr == null) {
            type2 = origType;
        } else {
            try {
                type2 = intr.refineSerializationType(config2, beanDesc.getClassInfo(), origType);
            }
            catch (JsonMappingException e) {
                return (JsonSerializer)prov.reportBadTypeDefinition(beanDesc, e.getMessage(), new Object[0]);
            }
        }
        if (type2 == origType) {
            staticTyping = false;
        } else {
            staticTyping = true;
            if (!type2.hasRawClass(origType.getRawClass())) {
                beanDesc = config2.introspect(type2);
            }
        }
        Converter<Object, Object> conv = beanDesc.findSerializationConverter();
        if (conv == null) {
            return this._createSerializer2(prov, type2, beanDesc, staticTyping);
        }
        JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
        if (!delegateType.hasRawClass(type2.getRawClass())) {
            beanDesc = config2.introspect(delegateType);
            ser = this.findSerializerFromAnnotation(prov, beanDesc.getClassInfo());
        }
        if (ser == null && !delegateType.isJavaLangObject()) {
            ser = this._createSerializer2(prov, delegateType, beanDesc, true);
        }
        return new StdDelegatingSerializer(conv, delegateType, ser);
    }

    protected JsonSerializer<?> _createSerializer2(SerializerProvider prov, JavaType type2, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
        JsonSerializer<Object> ser = null;
        SerializationConfig config2 = prov.getConfig();
        if (type2.isContainerType()) {
            if (!staticTyping) {
                staticTyping = this.usesStaticTyping(config2, beanDesc, null);
            }
            if ((ser = this.buildContainerSerializer(prov, type2, beanDesc, staticTyping)) != null) {
                return ser;
            }
        } else {
            if (type2.isReferenceType()) {
                ser = this.findReferenceSerializer(prov, (ReferenceType)type2, beanDesc, staticTyping);
            } else {
                Serializers serializers;
                Iterator<Object> iterator2 = this.customSerializers().iterator();
                while (iterator2.hasNext() && (ser = (serializers = iterator2.next()).findSerializer(config2, type2, beanDesc)) == null) {
                }
            }
            if (ser == null) {
                ser = this.findSerializerByAnnotations(prov, type2, beanDesc);
            }
        }
        if (ser == null && (ser = this.findSerializerByLookup(type2, config2, beanDesc, staticTyping)) == null && (ser = this.findSerializerByPrimaryType(prov, type2, beanDesc, staticTyping)) == null && (ser = this.findBeanOrAddOnSerializer(prov, type2, beanDesc, staticTyping)) == null) {
            ser = prov.getUnknownTypeSerializer(beanDesc.getBeanClass());
        }
        if (ser != null && this._factoryConfig.hasSerializerModifiers()) {
            for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
                ser = mod.modifySerializer(config2, beanDesc, ser);
            }
        }
        return ser;
    }

    @Deprecated
    public JsonSerializer<Object> findBeanSerializer(SerializerProvider prov, JavaType type2, BeanDescription beanDesc) throws JsonMappingException {
        return this.findBeanOrAddOnSerializer(prov, type2, beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
    }

    public JsonSerializer<Object> findBeanOrAddOnSerializer(SerializerProvider prov, JavaType type2, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
        if (!this.isPotentialBeanType(type2.getRawClass()) && !ClassUtil.isEnumType(type2.getRawClass())) {
            return null;
        }
        return this.constructBeanOrAddOnSerializer(prov, type2, beanDesc, staticTyping);
    }

    public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config2, AnnotatedMember accessor) throws JsonMappingException {
        TypeSerializer typeSer;
        AnnotationIntrospector ai = config2.getAnnotationIntrospector();
        TypeResolverBuilder<?> b = ai.findPropertyTypeResolver(config2, accessor, baseType);
        if (b == null) {
            typeSer = this.createTypeSerializer(config2, baseType);
        } else {
            Collection<NamedType> subtypes = config2.getSubtypeResolver().collectAndResolveSubtypesByClass(config2, accessor, baseType);
            typeSer = b.buildTypeSerializer(config2, baseType, subtypes);
        }
        return typeSer;
    }

    public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config2, AnnotatedMember accessor) throws JsonMappingException {
        TypeSerializer typeSer;
        JavaType contentType2 = containerType.getContentType();
        AnnotationIntrospector ai = config2.getAnnotationIntrospector();
        TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver(config2, accessor, containerType);
        if (b == null) {
            typeSer = this.createTypeSerializer(config2, contentType2);
        } else {
            Collection<NamedType> subtypes = config2.getSubtypeResolver().collectAndResolveSubtypesByClass(config2, accessor, contentType2);
            typeSer = b.buildTypeSerializer(config2, contentType2, subtypes);
        }
        return typeSer;
    }

    @Deprecated
    protected JsonSerializer<Object> constructBeanSerializer(SerializerProvider prov, BeanDescription beanDesc) throws JsonMappingException {
        return this.constructBeanOrAddOnSerializer(prov, beanDesc.getType(), beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
    }

    protected JsonSerializer<Object> constructBeanOrAddOnSerializer(SerializerProvider prov, JavaType type2, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
        if (beanDesc.getBeanClass() == Object.class) {
            return prov.getUnknownTypeSerializer(Object.class);
        }
        JsonSerializer<Object> ser = this._findUnsupportedTypeSerializer(prov, type2, beanDesc);
        if (ser != null) {
            return ser;
        }
        if (this._isUnserializableJacksonType(prov, type2)) {
            return new ToEmptyObjectSerializer(type2);
        }
        SerializationConfig config2 = prov.getConfig();
        BeanSerializerBuilder builder = this.constructBeanSerializerBuilder(beanDesc);
        builder.setConfig(config2);
        List<BeanPropertyWriter> props = this.findBeanProperties(prov, beanDesc, builder);
        props = props == null ? new ArrayList<BeanPropertyWriter>() : this.removeOverlappingTypeIds(prov, beanDesc, builder, props);
        prov.getAnnotationIntrospector().findAndAddVirtualProperties(config2, beanDesc.getClassInfo(), props);
        if (this._factoryConfig.hasSerializerModifiers()) {
            for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
                props = mod.changeProperties(config2, beanDesc, props);
            }
        }
        props = this.filterUnwantedJDKProperties(config2, beanDesc, props);
        props = this.filterBeanProperties(config2, beanDesc, props);
        if (this._factoryConfig.hasSerializerModifiers()) {
            for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
                props = mod.orderProperties(config2, beanDesc, props);
            }
        }
        builder.setObjectIdWriter(this.constructObjectIdHandler(prov, beanDesc, props));
        builder.setProperties(props);
        builder.setFilterId(this.findFilterId(config2, beanDesc));
        AnnotatedMember anyGetter = beanDesc.findAnyGetter();
        if (anyGetter != null) {
            JavaType anyType = anyGetter.getType();
            JavaType valueType = anyType.getContentType();
            TypeSerializer typeSer = this.createTypeSerializer(config2, valueType);
            MapSerializer anySer = this.findSerializerFromAnnotation(prov, anyGetter);
            if (anySer == null) {
                anySer = MapSerializer.construct((Set<String>)null, anyType, config2.isEnabled(MapperFeature.USE_STATIC_TYPING), typeSer, null, null, null);
            }
            PropertyName name = PropertyName.construct(anyGetter.getName());
            BeanProperty.Std anyProp = new BeanProperty.Std(name, valueType, null, anyGetter, PropertyMetadata.STD_OPTIONAL);
            builder.setAnyGetter(new AnyGetterWriter(anyProp, anyGetter, anySer));
        }
        this.processViews(config2, builder);
        if (this._factoryConfig.hasSerializerModifiers()) {
            for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
                builder = mod.updateBuilder(config2, beanDesc, builder);
            }
        }
        try {
            ser = builder.build();
        }
        catch (RuntimeException e) {
            return (JsonSerializer)prov.reportBadTypeDefinition(beanDesc, "Failed to construct BeanSerializer for %s: (%s) %s", beanDesc.getType(), e.getClass().getName(), e.getMessage());
        }
        if (ser == null) {
            if (type2.isRecordType()) {
                return builder.createDummy();
            }
            ser = this.findSerializerByAddonType(config2, type2, beanDesc, staticTyping);
            if (ser == null && beanDesc.hasKnownClassAnnotations()) {
                return builder.createDummy();
            }
        }
        return ser;
    }

    protected ObjectIdWriter constructObjectIdHandler(SerializerProvider prov, BeanDescription beanDesc, List<BeanPropertyWriter> props) throws JsonMappingException {
        ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
        if (objectIdInfo == null) {
            return null;
        }
        Class<? extends ObjectIdGenerator<?>> implClass = objectIdInfo.getGeneratorType();
        if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
            String propName = objectIdInfo.getPropertyName().getSimpleName();
            BeanPropertyWriter idProp = null;
            int i = 0;
            int len = props.size();
            while (true) {
                if (i == len) {
                    throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", ClassUtil.getTypeDescription(beanDesc.getType()), ClassUtil.name(propName)));
                }
                BeanPropertyWriter prop = props.get(i);
                if (propName.equals(prop.getName())) {
                    idProp = prop;
                    if (i <= 0) break;
                    props.remove(i);
                    props.add(0, idProp);
                    break;
                }
                ++i;
            }
            JavaType idType = idProp.getType();
            PropertyBasedObjectIdGenerator gen = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
            return ObjectIdWriter.construct(idType, null, gen, objectIdInfo.getAlwaysAsId());
        }
        JavaType type2 = prov.constructType(implClass);
        JavaType idType = prov.getTypeFactory().findTypeParameters(type2, ObjectIdGenerator.class)[0];
        ObjectIdGenerator<?> gen = prov.objectIdGeneratorInstance(beanDesc.getClassInfo(), objectIdInfo);
        return ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo.getAlwaysAsId());
    }

    protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews) {
        return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
    }

    protected PropertyBuilder constructPropertyBuilder(SerializationConfig config2, BeanDescription beanDesc) {
        return new PropertyBuilder(config2, beanDesc);
    }

    protected BeanSerializerBuilder constructBeanSerializerBuilder(BeanDescription beanDesc) {
        return new BeanSerializerBuilder(beanDesc);
    }

    protected boolean isPotentialBeanType(Class<?> type2) {
        return ClassUtil.canBeABeanType(type2) == null && !ClassUtil.isProxyType(type2);
    }

    protected List<BeanPropertyWriter> findBeanProperties(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder) throws JsonMappingException {
        List<BeanPropertyDefinition> properties2 = beanDesc.findProperties();
        SerializationConfig config2 = prov.getConfig();
        this.removeIgnorableTypes(config2, beanDesc, properties2);
        if (config2.isEnabled(MapperFeature.REQUIRE_SETTERS_FOR_GETTERS)) {
            this.removeSetterlessGetters(config2, beanDesc, properties2);
        }
        if (properties2.isEmpty()) {
            return null;
        }
        boolean staticTyping = this.usesStaticTyping(config2, beanDesc, null);
        PropertyBuilder pb = this.constructPropertyBuilder(config2, beanDesc);
        ArrayList<BeanPropertyWriter> result2 = new ArrayList<BeanPropertyWriter>(properties2.size());
        for (BeanPropertyDefinition property2 : properties2) {
            AnnotatedMember accessor = property2.getAccessor();
            if (property2.isTypeId()) {
                if (accessor == null) continue;
                builder.setTypeId(accessor);
                continue;
            }
            AnnotationIntrospector.ReferenceProperty refType = property2.findReferenceType();
            if (refType != null && refType.isBackReference()) continue;
            if (accessor instanceof AnnotatedMethod) {
                result2.add(this._constructWriter(prov, property2, pb, staticTyping, (AnnotatedMethod)accessor));
                continue;
            }
            result2.add(this._constructWriter(prov, property2, pb, staticTyping, (AnnotatedField)accessor));
        }
        return result2;
    }

    protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config2, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
        JsonIgnoreProperties.Value ignorals = config2.getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc.getClassInfo());
        Set<String> ignored = null;
        if (ignorals != null) {
            ignored = ignorals.findIgnoredForSerialization();
        }
        JsonIncludeProperties.Value inclusions = config2.getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc.getClassInfo());
        Set<String> included = null;
        if (inclusions != null) {
            included = inclusions.getIncluded();
        }
        if (included != null || ignored != null && !ignored.isEmpty()) {
            Iterator<BeanPropertyWriter> it = props.iterator();
            while (it.hasNext()) {
                if (!IgnorePropertiesUtil.shouldIgnore(it.next().getName(), ignored, included)) continue;
                it.remove();
            }
        }
        return props;
    }

    protected List<BeanPropertyWriter> filterUnwantedJDKProperties(SerializationConfig config2, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
        BeanPropertyWriter prop;
        AnnotatedMember m3;
        if (beanDesc.getType().isTypeOrSubTypeOf(CharSequence.class) && props.size() == 1 && (m3 = (prop = props.get(0)).getMember()) instanceof AnnotatedMethod && "isEmpty".equals(m3.getName()) && m3.getDeclaringClass() == CharSequence.class) {
            props.remove(0);
        }
        return props;
    }

    protected void processViews(SerializationConfig config2, BeanSerializerBuilder builder) {
        List<BeanPropertyWriter> props = builder.getProperties();
        boolean includeByDefault = config2.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
        int propCount = props.size();
        int viewsFound = 0;
        BeanPropertyWriter[] filtered2 = new BeanPropertyWriter[propCount];
        for (int i = 0; i < propCount; ++i) {
            BeanPropertyWriter bpw = props.get(i);
            Class<?>[] views = bpw.getViews();
            if (views == null || views.length == 0) {
                if (!includeByDefault) continue;
                filtered2[i] = bpw;
                continue;
            }
            ++viewsFound;
            filtered2[i] = this.constructFilteredBeanWriter(bpw, views);
        }
        if (includeByDefault && viewsFound == 0) {
            return;
        }
        builder.setFilteredProperties(filtered2);
    }

    protected void removeIgnorableTypes(SerializationConfig config2, BeanDescription beanDesc, List<BeanPropertyDefinition> properties2) {
        AnnotationIntrospector intr = config2.getAnnotationIntrospector();
        HashMap ignores = new HashMap();
        Iterator<BeanPropertyDefinition> it = properties2.iterator();
        while (it.hasNext()) {
            BeanPropertyDefinition property2 = it.next();
            AnnotatedMember accessor = property2.getAccessor();
            if (accessor == null) {
                it.remove();
                continue;
            }
            Class<?> type2 = property2.getRawPrimaryType();
            Boolean result2 = (Boolean)ignores.get(type2);
            if (result2 == null) {
                BeanDescription desc;
                AnnotatedClass ac;
                result2 = config2.getConfigOverride(type2).getIsIgnoredType();
                if (result2 == null && (result2 = intr.isIgnorableType(ac = (desc = config2.introspectClassAnnotations(type2)).getClassInfo())) == null) {
                    result2 = Boolean.FALSE;
                }
                ignores.put(type2, result2);
            }
            if (!result2.booleanValue()) continue;
            it.remove();
        }
    }

    protected void removeSetterlessGetters(SerializationConfig config2, BeanDescription beanDesc, List<BeanPropertyDefinition> properties2) {
        Iterator<BeanPropertyDefinition> it = properties2.iterator();
        while (it.hasNext()) {
            BeanPropertyDefinition property2 = it.next();
            if (property2.couldDeserialize() || property2.isExplicitlyIncluded()) continue;
            it.remove();
        }
    }

    protected List<BeanPropertyWriter> removeOverlappingTypeIds(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder, List<BeanPropertyWriter> props) {
        int end2 = props.size();
        block0: for (int i = 0; i < end2; ++i) {
            BeanPropertyWriter bpw = props.get(i);
            TypeSerializer td = bpw.getTypeSerializer();
            if (td == null || td.getTypeInclusion() != JsonTypeInfo.As.EXTERNAL_PROPERTY) continue;
            String n = td.getPropertyName();
            PropertyName typePropName = PropertyName.construct(n);
            for (BeanPropertyWriter w2 : props) {
                if (w2 == bpw || !w2.wouldConflictWithName(typePropName)) continue;
                bpw.assignTypeSerializer(null);
                continue block0;
            }
        }
        return props;
    }

    protected BeanPropertyWriter _constructWriter(SerializerProvider prov, BeanPropertyDefinition propDef, PropertyBuilder pb, boolean staticTyping, AnnotatedMember accessor) throws JsonMappingException {
        PropertyName name = propDef.getFullName();
        JavaType type2 = accessor.getType();
        BeanProperty.Std property2 = new BeanProperty.Std(name, type2, propDef.getWrapperName(), accessor, propDef.getMetadata());
        JsonSerializer<Object> annotatedSerializer = this.findSerializerFromAnnotation(prov, accessor);
        if (annotatedSerializer instanceof ResolvableSerializer) {
            ((ResolvableSerializer)((Object)annotatedSerializer)).resolve(prov);
        }
        annotatedSerializer = prov.handlePrimaryContextualization(annotatedSerializer, property2);
        TypeSerializer contentTypeSer = null;
        if (type2.isContainerType() || type2.isReferenceType()) {
            contentTypeSer = this.findPropertyContentTypeSerializer(type2, prov.getConfig(), accessor);
        }
        TypeSerializer typeSer = this.findPropertyTypeSerializer(type2, prov.getConfig(), accessor);
        return pb.buildWriter(prov, propDef, type2, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
    }

    protected JsonSerializer<?> _findUnsupportedTypeSerializer(SerializerProvider ctxt, JavaType type2, BeanDescription beanDesc) throws JsonMappingException {
        String errorMsg = BeanUtil.checkUnsupportedType(type2);
        if (errorMsg != null && ctxt.getConfig().findMixInClassFor(type2.getRawClass()) == null) {
            return new UnsupportedTypeSerializer(type2, errorMsg);
        }
        return null;
    }

    protected boolean _isUnserializableJacksonType(SerializerProvider ctxt, JavaType type2) {
        Class<?> raw = type2.getRawClass();
        return ObjectMapper.class.isAssignableFrom(raw) || ObjectReader.class.isAssignableFrom(raw) || ObjectWriter.class.isAssignableFrom(raw) || DatabindContext.class.isAssignableFrom(raw) || TokenStreamFactory.class.isAssignableFrom(raw) || JsonParser.class.isAssignableFrom(raw) || JsonGenerator.class.isAssignableFrom(raw);
    }
}

