/*
 * Decompiled with CFR 0.150.
 */
package com.fasterxml.jackson.module.kotlin;

import com.fasterxml.jackson.annotation.JsonValue;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(mv={1, 5, 1}, k=2, xi=48, d1={"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\u0012\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u0006\u0012\u0002\b\u00030\u0002H\u0002\u00a8\u0006\u0003"}, d2={"getStaticJsonValueGetter", "Ljava/lang/reflect/Method;", "Ljava/lang/Class;", "jackson-module-kotlin"})
public final class KotlinSerializersKt {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static final Method getStaticJsonValueGetter(Class<?> $this$getStaticJsonValueGetter) {
        var1_1 = $this$getStaticJsonValueGetter.getDeclaredMethods();
        Intrinsics.checkNotNullExpressionValue(var1_1, "this.declaredMethods");
        var1_1 = var1_1;
        var2_2 = false;
        var3_3 = var1_1;
        var4_4 = false;
        var5_5 = var3_3;
        var6_6 = var5_5.length;
        var7_7 = 0;
        while (true) {
            block6: {
                if (var7_7 >= var6_6) {
                    v0 = null;
                    return (Method)v0;
                }
                var8_8 = var5_5[var7_7];
                method = (Method)var8_8;
                $i$a$-find-KotlinSerializersKt$getStaticJsonValueGetter$1 = false;
                if (!Modifier.isStatic(method.getModifiers())) ** GOTO lbl-1000
                var11_11 = method.getAnnotations();
                Intrinsics.checkNotNullExpressionValue(var11_11, "method.annotations");
                $this$any$iv = var11_11;
                $i$f$any = false;
                for (Object element$iv : $this$any$iv) {
                    it = (Annotation)element$iv;
                    $i$a$-any-KotlinSerializersKt$getStaticJsonValueGetter$1$1 = false;
                    if (!(it instanceof JsonValue)) continue;
                    v1 = true;
                    break block6;
                }
                v1 = false;
            }
            if (v1) {
                v2 = true;
            } else lbl-1000:
            // 2 sources

            {
                v2 = false;
            }
            if (v2) {
                v0 = var8_8;
                return (Method)v0;
            }
            ++var7_7;
        }
    }

    public static final /* synthetic */ Method access$getStaticJsonValueGetter(Class $receiver) {
        return KotlinSerializersKt.getStaticJsonValueGetter($receiver);
    }
}

