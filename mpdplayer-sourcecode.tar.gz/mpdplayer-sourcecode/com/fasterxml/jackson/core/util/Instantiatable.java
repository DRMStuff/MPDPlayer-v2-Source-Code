/*
 * Decompiled with CFR 0.150.
 */
package com.fasterxml.jackson.core.util;

public interface Instantiatable<T> {
    public T createInstance();
}

