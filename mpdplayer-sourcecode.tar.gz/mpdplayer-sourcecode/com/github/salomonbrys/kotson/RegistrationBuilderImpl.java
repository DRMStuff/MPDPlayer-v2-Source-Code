/*
 * Decompiled with CFR 0.150.
 */
package com.github.salomonbrys.kotson;

import com.github.salomonbrys.kotson.DeserializerArg;
import com.github.salomonbrys.kotson.GsonBuilderKt;
import com.github.salomonbrys.kotson.RegistrationBuilder;
import com.github.salomonbrys.kotson.SerializerArg;
import com.github.salomonbrys.kotson.TypeAdapterBuilder;
import com.google.gson.JsonElement;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.lang.reflect.Type;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 1}, bv={1, 0, 0}, k=1, d1={"\u0000R\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0000\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00010\u0003:\u0001&BF\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012#\u0010\u0006\u001a\u001f\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00000\u0003\u0012\u0004\u0012\u00020\b0\u0007\u00a2\u0006\u0002\b\t\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\b0\u0007\u00a2\u0006\u0002\u0010\u000bJ\u0010\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0018\u001a\u00020\rH\u0002J\b\u0010\u0019\u001a\u00020\bH\u0002J\u001c\u0010\u001a\u001a\u00020\b2\u0012\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00028\u00000\u0007H\u0016J\u001e\u0010\u001c\u001a\u00020\b2\u0014\u0010\u001d\u001a\u0010\u0012\u0004\u0012\u00020\u001e\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u0007H\u0016J!\u0010\u001f\u001a\u00020\b2\u0017\u0010 \u001a\u0013\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00028\u00000\u0007\u00a2\u0006\u0002\b\tH\u0016J\"\u0010!\u001a\u00020\b2\u0018\u0010\"\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000#\u0012\u0004\u0012\u00020$0\u0007H\u0016J'\u0010%\u001a\u00020\b2\u001d\u0010 \u001a\u0019\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\b0\u0011\u00a2\u0006\u0002\b\tH\u0016R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R!\u0010\u000e\u001a\u0015\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0007\u00a2\u0006\u0002\b\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R'\u0010\u0010\u001a\u001b\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\b\u0018\u00010\u0011\u00a2\u0006\u0002\b\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R \u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\b0\u0007X\u0084\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016\u00a8\u0006'"}, d2={"Lcom/github/salomonbrys/kotson/RegistrationBuilderImpl;", "T", "", "Lcom/github/salomonbrys/kotson/RegistrationBuilder;", "registeredType", "Ljava/lang/reflect/Type;", "init", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "register", "(Ljava/lang/reflect/Type;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "_api", "Lcom/github/salomonbrys/kotson/RegistrationBuilderImpl$_API;", "_readFunction", "Lcom/google/gson/stream/JsonReader;", "_writeFunction", "Lkotlin/Function2;", "Lcom/google/gson/stream/JsonWriter;", "getRegister", "()Lkotlin/jvm/functions/Function1;", "getRegisteredType", "()Ljava/lang/reflect/Type;", "_checkApi", "api", "_registerTypeAdapter", "createInstances", "creator", "deserialize", "deserializer", "Lcom/github/salomonbrys/kotson/DeserializerArg;", "read", "function", "serialize", "serializer", "Lcom/github/salomonbrys/kotson/SerializerArg;", "Lcom/google/gson/JsonElement;", "write", "_API", "kotson_main"})
public final class RegistrationBuilderImpl<T>
implements RegistrationBuilder<T, T> {
    private _API _api;
    private Function1<? super JsonReader, ? extends T> _readFunction;
    private Function2<? super JsonWriter, ? super T, Unit> _writeFunction;
    @NotNull
    private final Type registeredType;
    @NotNull
    private final Function1<Object, Unit> register;

    private final void _checkApi(_API api) {
        if (this._api != null && Intrinsics.areEqual((Object)this._api, (Object)api) ^ true) {
            throw (Throwable)new IllegalArgumentException("You cannot use serialize/deserialize and read/write for the same type");
        }
        this._api = api;
    }

    @Override
    public void serialize(@NotNull Function1<? super SerializerArg<T>, ? extends JsonElement> serializer2) {
        Intrinsics.checkParameterIsNotNull(serializer2, "serializer");
        this._checkApi(_API.SD);
        this.register.invoke(GsonBuilderKt.jsonSerializer(serializer2));
    }

    @Override
    public void deserialize(@NotNull Function1<? super DeserializerArg, ? extends T> deserializer) {
        Intrinsics.checkParameterIsNotNull(deserializer, "deserializer");
        this._checkApi(_API.SD);
        this.register.invoke(GsonBuilderKt.jsonDeserializer(deserializer));
    }

    @Override
    public void createInstances(@NotNull Function1<? super Type, ? extends T> creator) {
        Intrinsics.checkParameterIsNotNull(creator, "creator");
        this.register.invoke(GsonBuilderKt.instanceCreator(creator));
    }

    private final void _registerTypeAdapter() {
        this._checkApi(_API.RW);
        Function1<? super JsonReader, ? extends T> readFunction = this._readFunction;
        Function2<? super JsonWriter, ? super T, Unit> writeFunction = this._writeFunction;
        if (readFunction == null || writeFunction == null) {
            return;
        }
        this.register.invoke(GsonBuilderKt.typeAdapter(new Function1<TypeAdapterBuilder<T, T>, Unit>(readFunction, writeFunction){
            final /* synthetic */ Function1 $readFunction;
            final /* synthetic */ Function2 $writeFunction;

            public final void invoke(@NotNull TypeAdapterBuilder<T, T> $receiver) {
                Intrinsics.checkParameterIsNotNull($receiver, "$receiver");
                $receiver.read(this.$readFunction);
                $receiver.write(this.$writeFunction);
            }
            {
                this.$readFunction = function1;
                this.$writeFunction = function2;
                super(1);
            }
        }));
        this._readFunction = null;
        this._writeFunction = null;
    }

    @Override
    public void read(@NotNull Function1<? super JsonReader, ? extends T> function) {
        Intrinsics.checkParameterIsNotNull(function, "function");
        this._readFunction = function;
        this._registerTypeAdapter();
    }

    @Override
    public void write(@NotNull Function2<? super JsonWriter, ? super T, Unit> function) {
        Intrinsics.checkParameterIsNotNull(function, "function");
        this._writeFunction = function;
        this._registerTypeAdapter();
    }

    @NotNull
    public final Type getRegisteredType() {
        return this.registeredType;
    }

    @NotNull
    protected final Function1<Object, Unit> getRegister() {
        return this.register;
    }

    public RegistrationBuilderImpl(@NotNull Type registeredType, @NotNull Function1<? super RegistrationBuilder<T, T>, Unit> init2, @NotNull Function1<Object, Unit> register2) {
        Intrinsics.checkParameterIsNotNull(registeredType, "registeredType");
        Intrinsics.checkParameterIsNotNull(init2, "init");
        Intrinsics.checkParameterIsNotNull(register2, "register");
        this.registeredType = registeredType;
        this.register = register2;
        init2.invoke(this);
        if (this._readFunction != null) {
            throw (Throwable)new IllegalArgumentException("You cannot define a read function without a write function");
        }
        if (this._writeFunction != null) {
            throw (Throwable)new IllegalArgumentException("You cannot define a write function without a read function");
        }
    }

    @Metadata(mv={1, 1, 1}, bv={1, 0, 0}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0084\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004\u00a8\u0006\u0005"}, d2={"Lcom/github/salomonbrys/kotson/RegistrationBuilderImpl$_API;", "", "(Ljava/lang/String;I)V", "SD", "RW", "kotson_main"})
    protected static final class _API
    extends Enum<_API> {
        public static final /* enum */ _API SD;
        public static final /* enum */ _API RW;
        private static final /* synthetic */ _API[] $VALUES;

        static {
            _API[] arr_API = new _API[2];
            _API[] arr_API2 = arr_API;
            arr_API[0] = SD = new _API();
            arr_API[1] = RW = new _API();
            $VALUES = arr_API;
        }

        public static _API[] values() {
            return (_API[])$VALUES.clone();
        }

        public static _API valueOf(String string) {
            return Enum.valueOf(_API.class, string);
        }
    }
}

