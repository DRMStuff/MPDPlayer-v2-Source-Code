/*
 * Decompiled with CFR 0.150.
 */
package com.github.salomonbrys.kotson;

import com.github.salomonbrys.kotson.MutableKt;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.properties.ReadWriteProperty;
import kotlin.reflect.KProperty;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 1}, bv={1, 0, 0}, k=1, d1={"\u0000@\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000*\u0004\b\u0000\u0010\u00012\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0006\u0012\u0004\u0018\u0001H\u00010\u0002BW\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0014\u0010\u0006\u001a\u0010\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u0007\u0012\u0014\u0010\t\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0012\u0004\u0012\u00020\b0\u0007\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\u0010\b\u0002\u0010\f\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\r\u00a2\u0006\u0002\u0010\u000eJ&\u0010\u000f\u001a\u0004\u0018\u00018\u00002\b\u0010\u0010\u001a\u0004\u0018\u00010\u00032\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u0012H\u0096\u0002\u00a2\u0006\u0002\u0010\u0013J.\u0010\u0014\u001a\u00020\u00152\b\u0010\u0010\u001a\u0004\u0018\u00010\u00032\n\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u00122\b\u0010\u0016\u001a\u0004\u0018\u00018\u0000H\u0096\u0002\u00a2\u0006\u0002\u0010\u0017R\u0016\u0010\f\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u0010\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00018\u00000\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0018"}, d2={"Lcom/github/salomonbrys/kotson/NullableJsonObjectDelegate;", "T", "Lkotlin/properties/ReadWriteProperty;", "", "_obj", "Lcom/google/gson/JsonObject;", "_get", "Lkotlin/Function1;", "Lcom/google/gson/JsonElement;", "_set", "_key", "", "_default", "Lkotlin/Function0;", "(Lcom/google/gson/JsonObject;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getValue", "thisRef", "property", "Lkotlin/reflect/KProperty;", "(Ljava/lang/Object;Lkotlin/reflect/KProperty;)Ljava/lang/Object;", "setValue", "", "value", "(Ljava/lang/Object;Lkotlin/reflect/KProperty;Ljava/lang/Object;)V", "kotson_main"})
public final class NullableJsonObjectDelegate<T>
implements ReadWriteProperty<Object, T> {
    private final JsonObject _obj;
    private final Function1<JsonElement, T> _get;
    private final Function1<T, JsonElement> _set;
    private final String _key;
    private final Function0<T> _default;

    @Override
    @Nullable
    public T getValue(@Nullable Object thisRef, @NotNull KProperty<?> property2) {
        Intrinsics.checkParameterIsNotNull(property2, "property");
        String string = this._key;
        if (string == null) {
            string = property2.getName();
        }
        JsonElement element = this._obj.get(string);
        if (element == null) {
            Function0<T> function0 = this._default;
            return (T)(function0 != null ? function0.invoke() : null);
        }
        return this._get.invoke(element);
    }

    @Override
    public void setValue(@Nullable Object thisRef, @NotNull KProperty<?> property2, @Nullable T value) {
        Intrinsics.checkParameterIsNotNull(property2, "property");
        JsonElement jsonElement = this._obj;
        String string = this._key;
        if (string == null) {
            string = property2.getName();
        }
        MutableKt.set(jsonElement, string, (Object)this._set.invoke(value));
    }

    public NullableJsonObjectDelegate(@NotNull JsonObject _obj, @NotNull Function1<? super JsonElement, ? extends T> _get, @NotNull Function1<? super T, ? extends JsonElement> _set, @Nullable String _key, @Nullable Function0<? extends T> _default) {
        Intrinsics.checkParameterIsNotNull(_obj, "_obj");
        Intrinsics.checkParameterIsNotNull(_get, "_get");
        Intrinsics.checkParameterIsNotNull(_set, "_set");
        this._obj = _obj;
        this._get = _get;
        this._set = _set;
        this._key = _key;
        this._default = _default;
    }

    public /* synthetic */ NullableJsonObjectDelegate(JsonObject jsonObject, Function1 function1, Function1 function12, String string, Function0 function0, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 8) != 0) {
            string = null;
        }
        if ((n & 0x10) != 0) {
            function0 = null;
        }
        this(jsonObject, function1, function12, string, function0);
    }
}

