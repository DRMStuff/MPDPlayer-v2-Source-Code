/*
 * Decompiled with CFR 0.150.
 */
package com.github.benmanes.caffeine.cache;

import com.github.benmanes.caffeine.cache.FWW;
import com.github.benmanes.caffeine.cache.Node;
import java.lang.ref.ReferenceQueue;

class FWWR<K, V>
extends FWW<K, V> {
    FWWR() {
    }

    FWWR(K key2, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        super(key2, keyReferenceQueue, value, valueReferenceQueue, weight, now);
    }

    FWWR(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        super(keyReference, value, valueReferenceQueue, weight, now);
    }

    @Override
    public final boolean casWriteTime(long expect, long update2) {
        return this.writeTime == expect && WRITE_TIME.compareAndSet(this, expect, update2);
    }

    @Override
    public Node<K, V> newNode(K key2, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        return new FWWR<K, V>(key2, keyReferenceQueue, value, valueReferenceQueue, weight, now);
    }

    @Override
    public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        return new FWWR<K, V>(keyReference, value, valueReferenceQueue, weight, now);
    }
}

