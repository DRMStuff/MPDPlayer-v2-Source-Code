/*
 * Decompiled with CFR 0.150.
 */
package com.github.benmanes.caffeine.cache;

import com.github.benmanes.caffeine.cache.Node;
import com.github.benmanes.caffeine.cache.PSAR;
import java.lang.ref.ReferenceQueue;

final class PSARMS<K, V>
extends PSAR<K, V> {
    int queueType;

    PSARMS() {
    }

    PSARMS(K key2, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        super(key2, keyReferenceQueue, value, valueReferenceQueue, weight, now);
    }

    PSARMS(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        super(keyReference, value, valueReferenceQueue, weight, now);
    }

    @Override
    public int getQueueType() {
        return this.queueType;
    }

    @Override
    public void setQueueType(int queueType) {
        this.queueType = queueType;
    }

    @Override
    public Node<K, V> newNode(K key2, ReferenceQueue<K> keyReferenceQueue, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        return new PSARMS<K, V>(key2, keyReferenceQueue, value, valueReferenceQueue, weight, now);
    }

    @Override
    public Node<K, V> newNode(Object keyReference, V value, ReferenceQueue<V> valueReferenceQueue, int weight, long now) {
        return new PSARMS<K, V>(keyReference, value, valueReferenceQueue, weight, now);
    }
}

