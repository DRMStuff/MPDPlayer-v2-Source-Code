/*
 * Decompiled with CFR 0.150.
 */
package com.github.benmanes.caffeine.cache;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.LocalCache;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;
import org.checkerframework.checker.nullness.qual.Nullable;

interface LocalManualCache<K, V>
extends Cache<K, V> {
    public LocalCache<K, V> cache();

    @Override
    default public long estimatedSize() {
        return this.cache().estimatedSize();
    }

    @Override
    default public void cleanUp() {
        this.cache().cleanUp();
    }

    @Override
    default public @Nullable V getIfPresent(K key2) {
        return this.cache().getIfPresent(key2, true);
    }

    @Override
    default public @Nullable V get(K key2, Function<? super K, ? extends V> mappingFunction) {
        return this.cache().computeIfAbsent((K)key2, mappingFunction);
    }

    @Override
    default public Map<K, V> getAllPresent(Iterable<? extends K> keys2) {
        return this.cache().getAllPresent(keys2);
    }

    @Override
    default public Map<K, V> getAll(Iterable<? extends K> keys2, Function<? super Set<? extends K>, ? extends Map<? extends K, ? extends V>> mappingFunction) {
        Objects.requireNonNull(mappingFunction);
        LinkedHashSet<K> keysToLoad = new LinkedHashSet<K>();
        Map<K, V> found = this.cache().getAllPresent(keys2);
        LinkedHashMap<K, V> result2 = new LinkedHashMap<K, V>(found.size());
        for (K key2 : keys2) {
            V value = found.get(key2);
            if (value == null) {
                keysToLoad.add(key2);
            }
            result2.put(key2, value);
        }
        if (keysToLoad.isEmpty()) {
            return found;
        }
        this.bulkLoad(keysToLoad, result2, mappingFunction);
        return Collections.unmodifiableMap(result2);
    }

    default public void bulkLoad(Set<K> keysToLoad, Map<K, V> result2, Function<? super Set<? extends K>, ? extends Map<? extends K, ? extends V>> mappingFunction) {
        boolean success = false;
        long startTime = this.cache().statsTicker().read();
        try {
            Map<Object, Object> loaded = mappingFunction.apply(keysToLoad);
            loaded.forEach((arg_0, arg_1) -> this.cache().put(arg_0, arg_1));
            for (K key2 : keysToLoad) {
                V value = loaded.get(key2);
                if (value == null) {
                    result2.remove(key2);
                    continue;
                }
                result2.put(key2, value);
            }
            success = !loaded.isEmpty();
        }
        catch (RuntimeException e) {
            throw e;
        }
        catch (Exception e) {
            throw new CompletionException(e);
        }
        finally {
            long loadTime = this.cache().statsTicker().read() - startTime;
            if (success) {
                this.cache().statsCounter().recordLoadSuccess(loadTime);
            } else {
                this.cache().statsCounter().recordLoadFailure(loadTime);
            }
        }
    }

    @Override
    default public void put(K key2, V value) {
        this.cache().put(key2, value);
    }

    @Override
    default public void putAll(Map<? extends K, ? extends V> map2) {
        this.cache().putAll(map2);
    }

    @Override
    default public void invalidate(K key2) {
        this.cache().remove(key2);
    }

    @Override
    default public void invalidateAll(Iterable<? extends K> keys2) {
        this.cache().invalidateAll(keys2);
    }

    @Override
    default public void invalidateAll() {
        this.cache().clear();
    }

    @Override
    default public CacheStats stats() {
        return this.cache().statsCounter().snapshot();
    }

    @Override
    default public ConcurrentMap<K, V> asMap() {
        return this.cache();
    }
}

