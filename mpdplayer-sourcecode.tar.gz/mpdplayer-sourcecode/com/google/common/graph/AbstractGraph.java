/*
 * Decompiled with CFR 0.150.
 */
package com.google.common.graph;

import com.google.common.annotations.Beta;
import com.google.common.graph.AbstractBaseGraph;
import com.google.common.graph.Graph;
import org.checkerframework.checker.nullness.qual.Nullable;

@Beta
public abstract class AbstractGraph<N>
extends AbstractBaseGraph<N>
implements Graph<N> {
    @Override
    public final boolean equals(@Nullable Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Graph)) {
            return false;
        }
        Graph other = (Graph)obj;
        return this.isDirected() == other.isDirected() && this.nodes().equals(other.nodes()) && this.edges().equals(other.edges());
    }

    @Override
    public final int hashCode() {
        return this.edges().hashCode();
    }

    public String toString() {
        boolean bl = this.isDirected();
        boolean bl2 = this.allowsSelfLoops();
        String string = String.valueOf(this.nodes());
        String string2 = String.valueOf(this.edges());
        return new StringBuilder(59 + String.valueOf(string).length() + String.valueOf(string2).length()).append("isDirected: ").append(bl).append(", allowsSelfLoops: ").append(bl2).append(", nodes: ").append(string).append(", edges: ").append(string2).toString();
    }
}

