/*
 * Decompiled with CFR 0.150.
 */
package com.google.common.primitives;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class IntsMethodsForWeb {
    IntsMethodsForWeb() {
    }
}

