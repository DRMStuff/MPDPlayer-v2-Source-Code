/*
 * Decompiled with CFR 0.150.
 */
package com.google.common.collect;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Ordering;
import java.util.Comparator;
import java.util.List;
import java.util.RandomAccess;
import org.checkerframework.checker.nullness.qual.Nullable;

@GwtCompatible
@Beta
final class SortedLists {
    private SortedLists() {
    }

    public static <E extends Comparable> int binarySearch(List<? extends E> list, E e, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
        Preconditions.checkNotNull(e);
        return SortedLists.binarySearch(list, e, Ordering.natural(), presentBehavior, absentBehavior);
    }

    public static <E, K extends Comparable> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key2, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
        return SortedLists.binarySearch(list, keyFunction, key2, Ordering.natural(), presentBehavior, absentBehavior);
    }

    public static <E, K> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key2, Comparator<? super K> keyComparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
        return SortedLists.binarySearch(Lists.transform(list, keyFunction), key2, keyComparator, presentBehavior, absentBehavior);
    }

    public static <E> int binarySearch(List<? extends E> list, @Nullable E key2, Comparator<? super E> comparator2, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior) {
        Preconditions.checkNotNull(comparator2);
        Preconditions.checkNotNull(list);
        Preconditions.checkNotNull(presentBehavior);
        Preconditions.checkNotNull(absentBehavior);
        if (!(list instanceof RandomAccess)) {
            list = Lists.newArrayList(list);
        }
        int lower = 0;
        int upper = list.size() - 1;
        while (lower <= upper) {
            int middle = lower + upper >>> 1;
            int c = comparator2.compare(key2, list.get(middle));
            if (c < 0) {
                upper = middle - 1;
                continue;
            }
            if (c > 0) {
                lower = middle + 1;
                continue;
            }
            return lower + presentBehavior.resultIndex(comparator2, key2, list.subList(lower, upper + 1), middle - lower);
        }
        return absentBehavior.resultIndex(lower);
    }

    static abstract class KeyAbsentBehavior
    extends Enum<KeyAbsentBehavior> {
        public static final /* enum */ KeyAbsentBehavior NEXT_LOWER = new KeyAbsentBehavior(){

            @Override
            int resultIndex(int higherIndex) {
                return higherIndex - 1;
            }
        };
        public static final /* enum */ KeyAbsentBehavior NEXT_HIGHER = new KeyAbsentBehavior(){

            @Override
            public int resultIndex(int higherIndex) {
                return higherIndex;
            }
        };
        public static final /* enum */ KeyAbsentBehavior INVERTED_INSERTION_INDEX = new KeyAbsentBehavior(){

            @Override
            public int resultIndex(int higherIndex) {
                return ~higherIndex;
            }
        };
        private static final /* synthetic */ KeyAbsentBehavior[] $VALUES;

        public static KeyAbsentBehavior[] values() {
            return (KeyAbsentBehavior[])$VALUES.clone();
        }

        public static KeyAbsentBehavior valueOf(String name) {
            return Enum.valueOf(KeyAbsentBehavior.class, name);
        }

        abstract int resultIndex(int var1);

        private static /* synthetic */ KeyAbsentBehavior[] $values() {
            return new KeyAbsentBehavior[]{NEXT_LOWER, NEXT_HIGHER, INVERTED_INSERTION_INDEX};
        }

        static {
            $VALUES = KeyAbsentBehavior.$values();
        }
    }

    static abstract class KeyPresentBehavior
    extends Enum<KeyPresentBehavior> {
        public static final /* enum */ KeyPresentBehavior ANY_PRESENT = new KeyPresentBehavior(){

            @Override
            <E> int resultIndex(Comparator<? super E> comparator2, E key2, List<? extends E> list, int foundIndex) {
                return foundIndex;
            }
        };
        public static final /* enum */ KeyPresentBehavior LAST_PRESENT = new KeyPresentBehavior(){

            @Override
            <E> int resultIndex(Comparator<? super E> comparator2, E key2, List<? extends E> list, int foundIndex) {
                int lower = foundIndex;
                int upper = list.size() - 1;
                while (lower < upper) {
                    int middle = lower + upper + 1 >>> 1;
                    int c = comparator2.compare(list.get(middle), key2);
                    if (c > 0) {
                        upper = middle - 1;
                        continue;
                    }
                    lower = middle;
                }
                return lower;
            }
        };
        public static final /* enum */ KeyPresentBehavior FIRST_PRESENT = new KeyPresentBehavior(){

            @Override
            <E> int resultIndex(Comparator<? super E> comparator2, E key2, List<? extends E> list, int foundIndex) {
                int lower = 0;
                int upper = foundIndex;
                while (lower < upper) {
                    int middle = lower + upper >>> 1;
                    int c = comparator2.compare(list.get(middle), key2);
                    if (c < 0) {
                        lower = middle + 1;
                        continue;
                    }
                    upper = middle;
                }
                return lower;
            }
        };
        public static final /* enum */ KeyPresentBehavior FIRST_AFTER = new KeyPresentBehavior(){

            @Override
            public <E> int resultIndex(Comparator<? super E> comparator2, E key2, List<? extends E> list, int foundIndex) {
                return LAST_PRESENT.resultIndex(comparator2, key2, list, foundIndex) + 1;
            }
        };
        public static final /* enum */ KeyPresentBehavior LAST_BEFORE = new KeyPresentBehavior(){

            @Override
            public <E> int resultIndex(Comparator<? super E> comparator2, E key2, List<? extends E> list, int foundIndex) {
                return FIRST_PRESENT.resultIndex(comparator2, key2, list, foundIndex) - 1;
            }
        };
        private static final /* synthetic */ KeyPresentBehavior[] $VALUES;

        public static KeyPresentBehavior[] values() {
            return (KeyPresentBehavior[])$VALUES.clone();
        }

        public static KeyPresentBehavior valueOf(String name) {
            return Enum.valueOf(KeyPresentBehavior.class, name);
        }

        abstract <E> int resultIndex(Comparator<? super E> var1, E var2, List<? extends E> var3, int var4);

        private static /* synthetic */ KeyPresentBehavior[] $values() {
            return new KeyPresentBehavior[]{ANY_PRESENT, LAST_PRESENT, FIRST_PRESENT, FIRST_AFTER, LAST_BEFORE};
        }

        static {
            $VALUES = KeyPresentBehavior.$values();
        }
    }
}

