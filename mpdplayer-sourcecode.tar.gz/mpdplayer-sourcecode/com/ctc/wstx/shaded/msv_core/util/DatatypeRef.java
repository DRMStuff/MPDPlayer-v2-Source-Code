/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.shaded.msv_core.util;

import com.ctc.wstx.shaded.msv.relaxng_datatype.Datatype;

public class DatatypeRef {
    public Datatype[] types = null;
}

