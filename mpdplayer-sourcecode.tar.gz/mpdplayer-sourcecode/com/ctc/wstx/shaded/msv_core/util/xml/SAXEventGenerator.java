/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.shaded.msv_core.util.xml;

import com.ctc.wstx.shaded.msv_core.util.xml.DOMVisitor;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.LocatorImpl;

public class SAXEventGenerator {
    public static void parse(Document dom, final ContentHandler handler2) throws SAXException {
        DOMVisitor visitor2 = new DOMVisitor(){

            public void visit(Element e) {
                int attLen = e.getAttributes().getLength();
                AttributesImpl atts = new AttributesImpl();
                for (int i = 0; i < attLen; ++i) {
                    Attr a = (Attr)e.getAttributes().item(i);
                    String uri2 = a.getNamespaceURI();
                    String local2 = a.getLocalName();
                    if (uri2 == null) {
                        uri2 = "";
                    }
                    if (local2 == null) {
                        local2 = a.getName();
                    }
                    atts.addAttribute(uri2, local2, a.getName(), null, a.getValue());
                }
                try {
                    String uri3 = e.getNamespaceURI();
                    String local3 = e.getLocalName();
                    if (uri3 == null) {
                        uri3 = "";
                    }
                    if (local3 == null) {
                        local3 = e.getNodeName();
                    }
                    handler2.startElement(uri3, local3, e.getNodeName(), atts);
                    super.visit(e);
                    handler2.endElement(uri3, local3, e.getNodeName());
                }
                catch (SAXException x) {
                    throw new SAXWrapper(x);
                }
            }

            public void visitNode(Node n) {
                if (n.getNodeType() == 3 || n.getNodeType() == 4) {
                    String text = n.getNodeValue();
                    try {
                        handler2.characters(text.toCharArray(), 0, text.length());
                    }
                    catch (SAXException x) {
                        throw new SAXWrapper(x);
                    }
                }
                super.visitNode(n);
            }
        };
        handler2.setDocumentLocator(new LocatorImpl());
        handler2.startDocument();
        try {
            visitor2.visit(dom);
        }
        catch (SAXWrapper w) {
            throw w.e;
        }
        handler2.endDocument();
    }

    private static class SAXWrapper
    extends RuntimeException {
        SAXException e;

        SAXWrapper(SAXException e) {
            this.e = e;
        }
    }
}

