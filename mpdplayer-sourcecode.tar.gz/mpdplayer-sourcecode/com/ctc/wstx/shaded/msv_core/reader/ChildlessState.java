/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.shaded.msv_core.reader;

import com.ctc.wstx.shaded.msv_core.reader.SimpleState;
import com.ctc.wstx.shaded.msv_core.reader.State;
import com.ctc.wstx.shaded.msv_core.util.StartTagInfo;

public class ChildlessState
extends SimpleState {
    protected final State createChildState(StartTagInfo tag) {
        return null;
    }
}

