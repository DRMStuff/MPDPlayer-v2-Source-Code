/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.shaded.msv_core.grammar.xmlschema;

import com.ctc.wstx.shaded.msv_core.grammar.xmlschema.Field;
import com.ctc.wstx.shaded.msv_core.grammar.xmlschema.IdentityConstraint;
import com.ctc.wstx.shaded.msv_core.grammar.xmlschema.XPath;

public class KeyConstraint
extends IdentityConstraint {
    private static final long serialVersionUID = 1L;

    public KeyConstraint(String namespaceURI, String localName, XPath[] selector, Field[] fields2) {
        super(namespaceURI, localName, selector, fields2);
    }
}

