/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.shaded.msv.org_isorelax.verifier.impl;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class ForkContentHandler
implements ContentHandler {
    private final ContentHandler lhs;
    private final ContentHandler rhs;

    public ForkContentHandler(ContentHandler contenthandler, ContentHandler contenthandler1) {
        this.lhs = contenthandler;
        this.rhs = contenthandler1;
    }

    public static ContentHandler create(ContentHandler[] acontenthandler) {
        if (acontenthandler.length == 0) {
            throw new IllegalArgumentException();
        }
        ContentHandler obj = acontenthandler[0];
        for (int i = 1; i < acontenthandler.length; ++i) {
            obj = new ForkContentHandler(obj, acontenthandler[i]);
        }
        return obj;
    }

    public void setDocumentLocator(Locator locator) {
        this.lhs.setDocumentLocator(locator);
        this.rhs.setDocumentLocator(locator);
    }

    public void startDocument() throws SAXException {
        this.lhs.startDocument();
        this.rhs.startDocument();
    }

    public void endDocument() throws SAXException {
        this.lhs.endDocument();
        this.rhs.endDocument();
    }

    public void startPrefixMapping(String s2, String s1) throws SAXException {
        this.lhs.startPrefixMapping(s2, s1);
        this.rhs.startPrefixMapping(s2, s1);
    }

    public void endPrefixMapping(String s2) throws SAXException {
        this.lhs.endPrefixMapping(s2);
        this.rhs.endPrefixMapping(s2);
    }

    public void startElement(String s2, String s1, String s22, Attributes attributes2) throws SAXException {
        this.lhs.startElement(s2, s1, s22, attributes2);
        this.rhs.startElement(s2, s1, s22, attributes2);
    }

    public void endElement(String s2, String s1, String s22) throws SAXException {
        this.lhs.endElement(s2, s1, s22);
        this.rhs.endElement(s2, s1, s22);
    }

    public void characters(char[] ac, int i, int j2) throws SAXException {
        this.lhs.characters(ac, i, j2);
        this.rhs.characters(ac, i, j2);
    }

    public void ignorableWhitespace(char[] ac, int i, int j2) throws SAXException {
        this.lhs.ignorableWhitespace(ac, i, j2);
        this.rhs.ignorableWhitespace(ac, i, j2);
    }

    public void processingInstruction(String s2, String s1) throws SAXException {
        this.lhs.processingInstruction(s2, s1);
        this.rhs.processingInstruction(s2, s1);
    }

    public void skippedEntity(String s2) throws SAXException {
        this.lhs.skippedEntity(s2);
        this.rhs.skippedEntity(s2);
    }
}

