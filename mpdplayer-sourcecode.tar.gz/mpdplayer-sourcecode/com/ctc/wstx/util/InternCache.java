/*
 * Decompiled with CFR 0.150.
 */
package com.ctc.wstx.util;

import java.util.LinkedHashMap;
import java.util.Map;

public final class InternCache
extends LinkedHashMap<String, String> {
    private static final int DEFAULT_SIZE = 64;
    private static final int MAX_SIZE = 660;
    private static final InternCache sInstance = new InternCache();

    private InternCache() {
        super(64, 0.6666f, false);
    }

    public static InternCache getInstance() {
        return sInstance;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String intern(String input2) {
        String result2;
        InternCache internCache = this;
        synchronized (internCache) {
            result2 = (String)this.get(input2);
        }
        if (result2 == null) {
            result2 = input2.intern();
            internCache = this;
            synchronized (internCache) {
                this.put(result2, result2);
            }
        }
        return result2;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
        return this.size() > 660;
    }
}

