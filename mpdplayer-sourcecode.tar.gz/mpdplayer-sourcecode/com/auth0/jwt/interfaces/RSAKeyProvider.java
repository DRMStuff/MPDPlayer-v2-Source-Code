/*
 * Decompiled with CFR 0.150.
 */
package com.auth0.jwt.interfaces;

import com.auth0.jwt.interfaces.KeyProvider;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

public interface RSAKeyProvider
extends KeyProvider<RSAPublicKey, RSAPrivateKey> {
}

