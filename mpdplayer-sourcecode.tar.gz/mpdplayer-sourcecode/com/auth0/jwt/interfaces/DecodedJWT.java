/*
 * Decompiled with CFR 0.150.
 */
package com.auth0.jwt.interfaces;

import com.auth0.jwt.interfaces.Header;
import com.auth0.jwt.interfaces.Payload;

public interface DecodedJWT
extends Payload,
Header {
    public String getToken();

    public String getHeader();

    public String getPayload();

    public String getSignature();
}

