/*
 * Decompiled with CFR 0.150.
 */
package com.zlab.route;

import com.zlab.route.LogsRouteKt;
import io.ktor.server.routing.Route;
import io.ktor.server.routing.RoutingBuilderKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 7, 1}, k=2, xi=48, d1={"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u00a8\u0006\u0003"}, d2={"logs", "", "Lio/ktor/server/routing/Route;", "player"})
public final class LogsRouteKt {
    public static final void logs(@NotNull Route $this$logs) {
        Intrinsics.checkNotNullParameter($this$logs, "<this>");
        RoutingBuilderKt.route($this$logs, "logs", logs.1.INSTANCE);
    }
}

