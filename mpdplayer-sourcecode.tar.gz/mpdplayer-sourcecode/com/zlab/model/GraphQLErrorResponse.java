/*
 * Decompiled with CFR 0.150.
 */
package com.zlab.model;

import com.zlab.exception.QlException;
import com.zlab.exception.QlException$;
import com.zlab.model.GraphQLErrorResponse$;
import java.util.List;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.ArrayListSerializer;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Serializable
@Metadata(mv={1, 7, 1}, k=1, xi=48, d1={"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0087\b\u0018\u0000 \u001f2\u00060\u0001j\u0002`\u0002:\u0002\u001e\u001fB)\b\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u000e\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u00a2\u0006\u0002\u0010\nB\u0013\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0010\u000bJ\u000f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H\u00c6\u0003J\u0019\u0010\u000f\u001a\u00020\u00002\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H\u00c6\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u00d6\u0003J\t\u0010\u0014\u001a\u00020\u0004H\u00d6\u0001J\t\u0010\u0015\u001a\u00020\u0016H\u00d6\u0001J!\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u00c7\u0001R\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r\u00a8\u0006 "}, d2={"Lcom/zlab/model/GraphQLErrorResponse;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "seen1", "", "errors", "", "Lcom/zlab/exception/QlException;", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/util/List;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Ljava/util/List;)V", "getErrors", "()Ljava/util/List;", "component1", "copy", "equals", "", "other", "", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "$serializer", "Companion", "player"})
public final class GraphQLErrorResponse
extends Exception {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @NotNull
    private final List<QlException> errors;

    public GraphQLErrorResponse(@NotNull List<? extends QlException> errors) {
        Intrinsics.checkNotNullParameter(errors, "errors");
        this.errors = errors;
    }

    @NotNull
    public final List<QlException> getErrors() {
        return this.errors;
    }

    @NotNull
    public final List<QlException> component1() {
        return this.errors;
    }

    @NotNull
    public final GraphQLErrorResponse copy(@NotNull List<? extends QlException> errors) {
        Intrinsics.checkNotNullParameter(errors, "errors");
        return new GraphQLErrorResponse(errors);
    }

    public static /* synthetic */ GraphQLErrorResponse copy$default(GraphQLErrorResponse graphQLErrorResponse, List list, int n, Object object) {
        if ((n & 1) != 0) {
            list = graphQLErrorResponse.errors;
        }
        return graphQLErrorResponse.copy(list);
    }

    @Override
    @NotNull
    public String toString() {
        return "GraphQLErrorResponse(errors=" + this.errors + ")";
    }

    public int hashCode() {
        return ((Object)this.errors).hashCode();
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GraphQLErrorResponse)) {
            return false;
        }
        GraphQLErrorResponse graphQLErrorResponse = (GraphQLErrorResponse)other;
        return Intrinsics.areEqual(this.errors, graphQLErrorResponse.errors);
    }

    @JvmStatic
    public static final void write$Self(@NotNull GraphQLErrorResponse self, @NotNull CompositeEncoder output2, @NotNull SerialDescriptor serialDesc) {
        Intrinsics.checkNotNullParameter(self, "self");
        Intrinsics.checkNotNullParameter(output2, "output");
        Intrinsics.checkNotNullParameter(serialDesc, "serialDesc");
        output2.encodeSerializableElement(serialDesc, 0, new ArrayListSerializer(QlException$.serializer.INSTANCE), self.errors);
    }

    @Deprecated(message="This synthesized declaration should not be used directly", replaceWith=@ReplaceWith(expression="", imports={}), level=DeprecationLevel.HIDDEN)
    public /* synthetic */ GraphQLErrorResponse(int seen1, List errors, SerializationConstructorMarker serializationConstructorMarker) {
        if (1 != (1 & seen1)) {
            PluginExceptionsKt.throwMissingFieldException(seen1, 1, $serializer.INSTANCE.getDescriptor());
        }
        this.errors = errors;
    }

    @Metadata(mv={1, 7, 1}, k=1, xi=48, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u00c6\u0001\u00a8\u0006\u0006"}, d2={"Lcom/zlab/model/GraphQLErrorResponse$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/zlab/model/GraphQLErrorResponse;", "player"})
    public static final class Companion {
        private Companion() {
        }

        @NotNull
        public final KSerializer<GraphQLErrorResponse> serializer() {
            return $serializer.INSTANCE;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

