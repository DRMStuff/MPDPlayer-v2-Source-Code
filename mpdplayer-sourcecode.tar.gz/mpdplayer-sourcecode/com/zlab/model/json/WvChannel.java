/*
 * Decompiled with CFR 0.150.
 */
package com.zlab.model.json;

import com.zlab.model.json.WvChannel$;
import com.zlab.model.json.WvKey;
import com.zlab.model.json.WvKey$;
import java.util.List;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.Serializable;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.internal.ArrayListSerializer;
import kotlinx.serialization.internal.IntSerializer;
import kotlinx.serialization.internal.PluginExceptionsKt;
import kotlinx.serialization.internal.SerializationConstructorMarker;
import kotlinx.serialization.internal.StringSerializer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Serializable
@Metadata(mv={1, 7, 1}, k=1, xi=48, d1={"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0087\b\u0018\u0000 22\u00020\u0001:\u000212B[\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0006\u0012\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u000e\u00a2\u0006\u0002\u0010\u000fBI\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0006\u0012\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0002\u0010\u0010J\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003\u00a2\u0006\u0002\u0010\u0012J\t\u0010\u001e\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\u001f\u001a\u00020\u0006H\u00c6\u0003J\u000b\u0010 \u001a\u0004\u0018\u00010\u0006H\u00c6\u0003J\u000f\u0010!\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u00c6\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\u0006H\u00c6\u0003JV\u0010#\u001a\u00020\u00002\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00062\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0006H\u00c6\u0001\u00a2\u0006\u0002\u0010$J\u0013\u0010%\u001a\u00020&2\b\u0010'\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010(\u001a\u00020\u0003H\u00d6\u0001J\t\u0010)\u001a\u00020\u0006H\u00d6\u0001J!\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020\u00002\u0006\u0010-\u001a\u00020.2\u0006\u0010/\u001a\u000200H\u00c7\u0001R\u0015\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0011\u0010\u0012R \u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0013\u0010\b\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0011\u0010\u0007\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019\u00a8\u00063"}, d2={"Lcom/zlab/model/json/WvChannel;", "", "seen1", "", "id", "title", "", "url", "licUrl", "keys", "", "Lcom/zlab/model/json/WvKey;", "pssh", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V", "getId", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getKeys", "()Ljava/util/List;", "setKeys", "(Ljava/util/List;)V", "getLicUrl", "()Ljava/lang/String;", "getPssh", "getTitle", "getUrl", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lcom/zlab/model/json/WvChannel;", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "$serializer", "Companion", "player"})
public final class WvChannel {
    @NotNull
    public static final Companion Companion = new Companion(null);
    @Nullable
    private final Integer id;
    @NotNull
    private final String title;
    @NotNull
    private final String url;
    @Nullable
    private final String licUrl;
    @NotNull
    private List<WvKey> keys;
    @Nullable
    private final String pssh;

    public WvChannel(@Nullable Integer id2, @NotNull String title, @NotNull String url2, @Nullable String licUrl, @NotNull List<WvKey> keys2, @Nullable String pssh) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(url2, "url");
        Intrinsics.checkNotNullParameter(keys2, "keys");
        this.id = id2;
        this.title = title;
        this.url = url2;
        this.licUrl = licUrl;
        this.keys = keys2;
        this.pssh = pssh;
    }

    public /* synthetic */ WvChannel(Integer n, String string, String string2, String string3, List list, String string4, int n2, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n2 & 1) != 0) {
            n = null;
        }
        if ((n2 & 8) != 0) {
            string3 = null;
        }
        if ((n2 & 0x10) != 0) {
            list = CollectionsKt.emptyList();
        }
        if ((n2 & 0x20) != 0) {
            string4 = null;
        }
        this(n, string, string2, string3, list, string4);
    }

    @Nullable
    public final Integer getId() {
        return this.id;
    }

    @NotNull
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    public final String getUrl() {
        return this.url;
    }

    @Nullable
    public final String getLicUrl() {
        return this.licUrl;
    }

    @NotNull
    public final List<WvKey> getKeys() {
        return this.keys;
    }

    public final void setKeys(@NotNull List<WvKey> list) {
        Intrinsics.checkNotNullParameter(list, "<set-?>");
        this.keys = list;
    }

    @Nullable
    public final String getPssh() {
        return this.pssh;
    }

    @Nullable
    public final Integer component1() {
        return this.id;
    }

    @NotNull
    public final String component2() {
        return this.title;
    }

    @NotNull
    public final String component3() {
        return this.url;
    }

    @Nullable
    public final String component4() {
        return this.licUrl;
    }

    @NotNull
    public final List<WvKey> component5() {
        return this.keys;
    }

    @Nullable
    public final String component6() {
        return this.pssh;
    }

    @NotNull
    public final WvChannel copy(@Nullable Integer id2, @NotNull String title, @NotNull String url2, @Nullable String licUrl, @NotNull List<WvKey> keys2, @Nullable String pssh) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(url2, "url");
        Intrinsics.checkNotNullParameter(keys2, "keys");
        return new WvChannel(id2, title, url2, licUrl, keys2, pssh);
    }

    public static /* synthetic */ WvChannel copy$default(WvChannel wvChannel, Integer n, String string, String string2, String string3, List list, String string4, int n2, Object object) {
        if ((n2 & 1) != 0) {
            n = wvChannel.id;
        }
        if ((n2 & 2) != 0) {
            string = wvChannel.title;
        }
        if ((n2 & 4) != 0) {
            string2 = wvChannel.url;
        }
        if ((n2 & 8) != 0) {
            string3 = wvChannel.licUrl;
        }
        if ((n2 & 0x10) != 0) {
            list = wvChannel.keys;
        }
        if ((n2 & 0x20) != 0) {
            string4 = wvChannel.pssh;
        }
        return wvChannel.copy(n, string, string2, string3, list, string4);
    }

    @NotNull
    public String toString() {
        return "WvChannel(id=" + this.id + ", title=" + this.title + ", url=" + this.url + ", licUrl=" + this.licUrl + ", keys=" + this.keys + ", pssh=" + this.pssh + ")";
    }

    public int hashCode() {
        int result2 = this.id == null ? 0 : ((Object)this.id).hashCode();
        result2 = result2 * 31 + this.title.hashCode();
        result2 = result2 * 31 + this.url.hashCode();
        result2 = result2 * 31 + (this.licUrl == null ? 0 : this.licUrl.hashCode());
        result2 = result2 * 31 + ((Object)this.keys).hashCode();
        result2 = result2 * 31 + (this.pssh == null ? 0 : this.pssh.hashCode());
        return result2;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof WvChannel)) {
            return false;
        }
        WvChannel wvChannel = (WvChannel)other;
        if (!Intrinsics.areEqual(this.id, wvChannel.id)) {
            return false;
        }
        if (!Intrinsics.areEqual(this.title, wvChannel.title)) {
            return false;
        }
        if (!Intrinsics.areEqual(this.url, wvChannel.url)) {
            return false;
        }
        if (!Intrinsics.areEqual(this.licUrl, wvChannel.licUrl)) {
            return false;
        }
        if (!Intrinsics.areEqual(this.keys, wvChannel.keys)) {
            return false;
        }
        return Intrinsics.areEqual(this.pssh, wvChannel.pssh);
    }

    @JvmStatic
    public static final void write$Self(@NotNull WvChannel self, @NotNull CompositeEncoder output2, @NotNull SerialDescriptor serialDesc) {
        Intrinsics.checkNotNullParameter(self, "self");
        Intrinsics.checkNotNullParameter(output2, "output");
        Intrinsics.checkNotNullParameter(serialDesc, "serialDesc");
        if (output2.shouldEncodeElementDefault(serialDesc, 0) ? true : self.id != null) {
            output2.encodeNullableSerializableElement(serialDesc, 0, IntSerializer.INSTANCE, self.id);
        }
        output2.encodeStringElement(serialDesc, 1, self.title);
        output2.encodeStringElement(serialDesc, 2, self.url);
        if (output2.shouldEncodeElementDefault(serialDesc, 3) ? true : self.licUrl != null) {
            output2.encodeNullableSerializableElement(serialDesc, 3, StringSerializer.INSTANCE, self.licUrl);
        }
        if (output2.shouldEncodeElementDefault(serialDesc, 4) ? true : !Intrinsics.areEqual(self.keys, CollectionsKt.emptyList())) {
            output2.encodeSerializableElement(serialDesc, 4, new ArrayListSerializer(WvKey$.serializer.INSTANCE), self.keys);
        }
        if (output2.shouldEncodeElementDefault(serialDesc, 5) ? true : self.pssh != null) {
            output2.encodeNullableSerializableElement(serialDesc, 5, StringSerializer.INSTANCE, self.pssh);
        }
    }

    @Deprecated(message="This synthesized declaration should not be used directly", replaceWith=@ReplaceWith(expression="", imports={}), level=DeprecationLevel.HIDDEN)
    public /* synthetic */ WvChannel(int seen1, Integer id2, String title, String url2, String licUrl, List keys2, String pssh, SerializationConstructorMarker serializationConstructorMarker) {
        if (6 != (6 & seen1)) {
            PluginExceptionsKt.throwMissingFieldException(seen1, 6, $serializer.INSTANCE.getDescriptor());
        }
        this.id = (seen1 & 1) == 0 ? null : id2;
        this.title = title;
        this.url = url2;
        this.licUrl = (seen1 & 8) == 0 ? null : licUrl;
        this.keys = (seen1 & 0x10) == 0 ? CollectionsKt.emptyList() : keys2;
        this.pssh = (seen1 & 0x20) == 0 ? null : pssh;
    }

    @Metadata(mv={1, 7, 1}, k=1, xi=48, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u00c6\u0001\u00a8\u0006\u0006"}, d2={"Lcom/zlab/model/json/WvChannel$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/zlab/model/json/WvChannel;", "player"})
    public static final class Companion {
        private Companion() {
        }

        @NotNull
        public final KSerializer<WvChannel> serializer() {
            return $serializer.INSTANCE;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

