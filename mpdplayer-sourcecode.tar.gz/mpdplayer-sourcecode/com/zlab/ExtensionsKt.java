/*
 * Decompiled with CFR 0.150.
 */
package com.zlab;

import com.apurebase.kgraphql.Context;
import com.apurebase.kgraphql.schema.Publisher;
import com.apurebase.kgraphql.schema.dsl.SchemaBuilder;
import com.apurebase.kgraphql.schema.dsl.operations.AbstractOperationDSL;
import com.apurebase.kgraphql.schema.dsl.operations.MutationDSL;
import com.apurebase.kgraphql.schema.dsl.operations.QueryDSL;
import com.zlab.ExtensionsKt;
import com.zlab.api.response.ApiResponse;
import com.zlab.enum.Role;
import com.zlab.enum.TRACK;
import com.zlab.exception.InvalidActionForRoleException;
import com.zlab.exception.UnAuthorizedUserException;
import com.zlab.model.PlayableChannel;
import io.ktor.http.content.OutgoingContent;
import io.ktor.server.application.ApplicationCall;
import io.ktor.server.auth.jwt.JWTPayloadHolder;
import io.ktor.server.auth.jwt.JWTPrincipal;
import io.ktor.server.response.ResponseTypeKt;
import io.ktor.util.CryptoKt;
import io.ktor.util.pipeline.PipelineContext;
import io.ktor.util.reflect.TypeInfoJvmKt;
import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.TypesJVMKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

@Metadata(mv={1, 7, 1}, k=2, xi=48, d1={"\u0000\u008e\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000f\n\u0002\u0010\u001c\n\u0002\b\b\u001a\u000e\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003\u001a\u000e\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0003\u001a\u000e\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0003\u001a\u0016\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\f\u001a\u0014\u0010\r\u001a\u00020\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00030\u0010\u001a6\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00162\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00032\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00120\u0019\u001a\u001a\u0010\u001a\u001a\u00020\u0012*\u00020\u001b2\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001d0\u0010H\u0002\u001a;\u0010\u001e\u001a\u00020\u001f*\u00020 2\u0006\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001d0\u00102\u0017\u0010!\u001a\u0013\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020\u00120\"\u00a2\u0006\u0002\b$\u001a;\u0010%\u001a\u00020\u001f*\u00020 2\u0006\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001d0\u00102\u0017\u0010!\u001a\u0013\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00120\"\u00a2\u0006\u0002\b$\u001a=\u0010'\u001a\u00020\u0012*\f\u0012\u0002\b\u0003\u0012\u0004\u0012\u00020)0(2\u001c\u0010\u0018\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120*\u0012\u0006\u0012\u0004\u0018\u00010+0\"H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010,\u001aE\u0010-\u001a\u0002H.\"\u0004\b\u0000\u0010.\"\u000e\b\u0001\u0010/*\b\u0012\u0004\u0012\u0002H/00*\b\u0012\u0004\u0012\u0002H.012\u0012\u00102\u001a\u000e\u0012\u0004\u0012\u0002H.\u0012\u0004\u0012\u0002H/0\"H\u0086\b\u00f8\u0001\u0001\u00a2\u0006\u0002\u00103\u001a6\u00104\u001a\u00020\u0012*\u00020\u00012\u0006\u00105\u001a\u00020\u00032\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00142\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00162\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0003\u001a6\u00106\u001a\u00020\u0012*\u00020\u00012\u0006\u00105\u001a\u00020\u00032\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00142\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00162\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0003\u001a(\u00107\u001a\u00020\u0012*\u00020\u00012\u0006\u00105\u001a\u00020\u00032\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0003\u001a(\u00108\u001a\u00020\u0012*\u00020\u00012\u0006\u00105\u001a\u00020\u00032\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u0003\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b\u009920\u0001\u00a8\u00069"}, d2={"getLogger", "Lorg/slf4j/Logger;", "name", "", "passToHash", "pass", "prepareUrl", "url", "round", "", "value", "places", "", "runCommand", "Ljava/lang/ProcessBuilder;", "cmd", "", "withMDC", "", "channel", "Lcom/zlab/model/PlayableChannel;", "track", "Lcom/zlab/enum/TRACK;", "operation", "block", "Lkotlin/Function0;", "authenticate", "Lcom/apurebase/kgraphql/schema/dsl/operations/AbstractOperationDSL;", "forRoles", "Lcom/zlab/enum/Role;", "authenticatedMutation", "Lcom/apurebase/kgraphql/schema/Publisher;", "Lcom/apurebase/kgraphql/schema/dsl/SchemaBuilder;", "init", "Lkotlin/Function1;", "Lcom/apurebase/kgraphql/schema/dsl/operations/MutationDSL;", "Lkotlin/ExtensionFunctionType;", "authenticatedQuery", "Lcom/apurebase/kgraphql/schema/dsl/operations/QueryDSL;", "errorAwareResponse", "Lio/ktor/util/pipeline/PipelineContext;", "Lio/ktor/server/application/ApplicationCall;", "Lkotlin/coroutines/Continuation;", "", "(Lio/ktor/util/pipeline/PipelineContext;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "findClosest", "T", "R", "", "", "selector", "(Ljava/lang/Iterable;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "showDebug", "msg", "showError", "showInfo", "showWarning", "player"})
public final class ExtensionsKt {
    @NotNull
    public static final ProcessBuilder runCommand(@NotNull List<String> cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        URI currentRelativePath = Paths.get("", new String[0]).toAbsolutePath().toUri();
        ProcessBuilder processBuilder = new ProcessBuilder(cmd).redirectOutput(ProcessBuilder.Redirect.PIPE).redirectError(ProcessBuilder.Redirect.PIPE).directory(new File(currentRelativePath));
        Intrinsics.checkNotNullExpressionValue(processBuilder, "ProcessBuilder(cmd)\n    \u2026ile(currentRelativePath))");
        return processBuilder;
    }

    public static final void showWarning(@NotNull Logger $this$showWarning, @NotNull String msg, @Nullable PlayableChannel channel2, @Nullable String operation) {
        Intrinsics.checkNotNullParameter($this$showWarning, "<this>");
        Intrinsics.checkNotNullParameter(msg, "msg");
        ExtensionsKt.withMDC(channel2, null, operation, new Function0<Unit>($this$showWarning, msg){
            final /* synthetic */ Logger $this_showWarning;
            final /* synthetic */ String $msg;
            {
                this.$this_showWarning = $receiver;
                this.$msg = $msg;
                super(0);
            }

            public final void invoke() {
                this.$this_showWarning.warn(this.$msg);
            }
        });
    }

    public static /* synthetic */ void showWarning$default(Logger logger, String string, PlayableChannel playableChannel, String string2, int n, Object object) {
        if ((n & 4) != 0) {
            string2 = null;
        }
        ExtensionsKt.showWarning(logger, string, playableChannel, string2);
    }

    public static final void showInfo(@NotNull Logger $this$showInfo, @NotNull String msg, @Nullable PlayableChannel channel2, @Nullable String operation) {
        Intrinsics.checkNotNullParameter($this$showInfo, "<this>");
        Intrinsics.checkNotNullParameter(msg, "msg");
        ExtensionsKt.withMDC(channel2, null, operation, new Function0<Unit>($this$showInfo, msg){
            final /* synthetic */ Logger $this_showInfo;
            final /* synthetic */ String $msg;
            {
                this.$this_showInfo = $receiver;
                this.$msg = $msg;
                super(0);
            }

            public final void invoke() {
                this.$this_showInfo.info(this.$msg);
            }
        });
    }

    public static /* synthetic */ void showInfo$default(Logger logger, String string, PlayableChannel playableChannel, String string2, int n, Object object) {
        if ((n & 4) != 0) {
            string2 = null;
        }
        ExtensionsKt.showInfo(logger, string, playableChannel, string2);
    }

    public static final void showError(@NotNull Logger $this$showError, @NotNull String msg, @Nullable PlayableChannel channel2, @Nullable TRACK track, @Nullable String operation) {
        Intrinsics.checkNotNullParameter($this$showError, "<this>");
        Intrinsics.checkNotNullParameter(msg, "msg");
        ExtensionsKt.withMDC(channel2, track, operation, new Function0<Unit>($this$showError, msg){
            final /* synthetic */ Logger $this_showError;
            final /* synthetic */ String $msg;
            {
                this.$this_showError = $receiver;
                this.$msg = $msg;
                super(0);
            }

            public final void invoke() {
                this.$this_showError.error(this.$msg);
            }
        });
    }

    public static /* synthetic */ void showError$default(Logger logger, String string, PlayableChannel playableChannel, TRACK tRACK, String string2, int n, Object object) {
        if ((n & 2) != 0) {
            playableChannel = null;
        }
        if ((n & 4) != 0) {
            tRACK = null;
        }
        if ((n & 8) != 0) {
            string2 = null;
        }
        ExtensionsKt.showError(logger, string, playableChannel, tRACK, string2);
    }

    public static final void showDebug(@NotNull Logger $this$showDebug, @NotNull String msg, @Nullable PlayableChannel channel2, @Nullable TRACK track, @Nullable String operation) {
        Intrinsics.checkNotNullParameter($this$showDebug, "<this>");
        Intrinsics.checkNotNullParameter(msg, "msg");
        ExtensionsKt.withMDC(channel2, track, operation, new Function0<Unit>($this$showDebug, msg){
            final /* synthetic */ Logger $this_showDebug;
            final /* synthetic */ String $msg;
            {
                this.$this_showDebug = $receiver;
                this.$msg = $msg;
                super(0);
            }

            public final void invoke() {
                this.$this_showDebug.debug(this.$msg);
            }
        });
    }

    public static /* synthetic */ void showDebug$default(Logger logger, String string, PlayableChannel playableChannel, TRACK tRACK, String string2, int n, Object object) {
        if ((n & 2) != 0) {
            playableChannel = null;
        }
        if ((n & 4) != 0) {
            tRACK = null;
        }
        if ((n & 8) != 0) {
            string2 = null;
        }
        ExtensionsKt.showDebug(logger, string, playableChannel, tRACK, string2);
    }

    public static final void withMDC(@Nullable PlayableChannel channel2, @Nullable TRACK track, @Nullable String operation, @NotNull Function0<Unit> block2) {
        Object it;
        Intrinsics.checkNotNullParameter(block2, "block");
        PlayableChannel playableChannel = channel2;
        if (playableChannel != null) {
            it = playableChannel;
            boolean bl = false;
            MDC.put("channel", channel2.getName());
            MDC.put("id", String.valueOf(channel2.getId()));
        }
        TRACK tRACK = track;
        if (tRACK != null) {
            it = tRACK;
            boolean bl = false;
            MDC.put("track", ((Enum)it).name());
        }
        String string = operation;
        if (string != null) {
            it = string;
            boolean bl = false;
            MDC.put("operation", operation);
        }
        block2.invoke();
        MDC.clear();
    }

    public static /* synthetic */ void withMDC$default(PlayableChannel playableChannel, TRACK tRACK, String string, Function0 function0, int n, Object object) {
        if ((n & 2) != 0) {
            tRACK = null;
        }
        if ((n & 4) != 0) {
            string = null;
        }
        ExtensionsKt.withMDC(playableChannel, tRACK, string, function0);
    }

    @NotNull
    public static final Logger getLogger(@NotNull String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        Logger logger = LoggerFactory.getLogger("Main." + name);
        Intrinsics.checkNotNullExpressionValue(logger, "getLogger(\"Main.$name\")");
        return logger;
    }

    @NotNull
    public static final String prepareUrl(@NotNull String url2) {
        String string;
        Intrinsics.checkNotNullParameter(url2, "url");
        String it = string = StringsKt.replace$default(url2, "[now]", String.valueOf(Instant.now().getEpochSecond() - (long)100), false, 4, null);
        boolean bl = false;
        System.out.println((Object)("New url: " + it));
        return string;
    }

    public static final <T, R extends Comparable<? super R>> T findClosest(@NotNull Iterable<? extends T> $this$findClosest, @NotNull Function1<? super T, ? extends R> selector) {
        Intrinsics.checkNotNullParameter($this$findClosest, "<this>");
        Intrinsics.checkNotNullParameter(selector, "selector");
        boolean $i$f$findClosest = false;
        Iterator<T> iterator2 = $this$findClosest.iterator();
        T minElem = iterator2.next();
        if (!iterator2.hasNext()) {
            return minElem;
        }
        Comparable minValue = (Comparable)selector.invoke(minElem);
        do {
            T e;
            Comparable v;
            if (minValue.compareTo(v = (Comparable)selector.invoke(e = iterator2.next())) <= 0) continue;
            minElem = e;
            minValue = v;
        } while (iterator2.hasNext());
        return minElem;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public static final Object errorAwareResponse(@NotNull PipelineContext<?, ApplicationCall> var0, @NotNull Function1<? super Continuation<? super Unit>, ? extends Object> var1_1, @NotNull Continuation<? super Unit> var2_2) {
        if (!(var2_2 instanceof errorAwareResponse.1)) ** GOTO lbl-1000
        var11_3 = var2_2;
        if ((var11_3.label & -2147483648) != 0) {
            var11_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super errorAwareResponse.1>)var2_2){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ExtensionsKt.errorAwareResponse(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var12_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $continuation.L$0 = $this$errorAwareResponse;
                $continuation.label = 1;
                v0 = block.invoke($continuation);
                ** if (v0 != var12_5) goto lbl19
lbl18:
                // 1 sources

                return var12_5;
lbl19:
                // 1 sources

                ** GOTO lbl26
            }
            case 1: {
                $this$errorAwareResponse = (PipelineContext)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl26:
                // 2 sources

                $this$call$iv = $this$errorAwareResponse;
                $i$f$getCall = false;
                $this$respond$iv = (ApplicationCall)$this$call$iv.getContext();
                message$iv = new ApiResponse(true, null, 2, null);
                $i$f$respondWithType = false;
                if (!(message$iv instanceof OutgoingContent) && !(message$iv instanceof byte[])) {
                    $i$f$typeInfo = false;
                    kType$iv$iv = Reflection.typeOf(ApiResponse.class);
                    reifiedType$iv$iv = TypesJVMKt.getJavaType(kType$iv$iv);
                    ResponseTypeKt.setResponseType($this$respond$iv.getResponse(), TypeInfoJvmKt.typeInfoImpl(reifiedType$iv$iv, Reflection.getOrCreateKotlinClass(ApiResponse.class), kType$iv$iv));
                }
                $continuation.L$0 = $this$errorAwareResponse;
                $continuation.label = 2;
                v1 = $this$respond$iv.getResponse().getPipeline().execute($this$respond$iv, (Object)message$iv, $continuation);
                ** if (v1 != var12_5) goto lbl41
lbl40:
                // 1 sources

                return var12_5;
lbl41:
                // 1 sources

                ** GOTO lbl49
            }
            case 2: {
                $i$f$respondWithType = false;
                $this$errorAwareResponse = (PipelineContext)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v1 = $result;
lbl49:
                    // 2 sources

                    $this$errorAwareResponse.finish();
                    ** GOTO lbl83
                }
                catch (Exception e) {
                    e.printStackTrace();
                    $this$call$iv = $this$errorAwareResponse;
                    $i$f$getCall = false;
                    $this$respond$iv = (ApplicationCall)$this$call$iv.getContext();
                    message$iv = new ApiResponse(false, e.getLocalizedMessage());
                    $i$f$respondWithType = false;
                    if (!(message$iv instanceof OutgoingContent) && !(message$iv instanceof byte[])) {
                        $i$f$typeInfo = false;
                        kType$iv$iv = Reflection.typeOf(ApiResponse.class);
                        reifiedType$iv$iv = TypesJVMKt.getJavaType(kType$iv$iv);
                        ResponseTypeKt.setResponseType($this$respond$iv.getResponse(), TypeInfoJvmKt.typeInfoImpl(reifiedType$iv$iv, Reflection.getOrCreateKotlinClass(ApiResponse.class), kType$iv$iv));
                    }
                    $continuation.L$0 = $this$errorAwareResponse;
                    $continuation.label = 3;
                    v2 = $this$respond$iv.getResponse().getPipeline().execute($this$respond$iv, message$iv, $continuation);
                    ** if (v2 != var12_5) goto lbl69
lbl68:
                    // 1 sources

                    return var12_5;
lbl69:
                    // 1 sources

                    ** GOTO lbl83
                }
            }
            case 3: {
                $i$f$respondWithType = false;
                $this$errorAwareResponse = (PipelineContext)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v2 = $result;
                ** GOTO lbl83
                {
                    catch (Throwable var3_8) {
                        throw var3_8;
                    }
                }
                finally {
                    $this$errorAwareResponse.finish();
                }
lbl83:
                // 3 sources

                return Unit.INSTANCE;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @NotNull
    public static final String passToHash(@NotNull String pass2) {
        Intrinsics.checkNotNullParameter(pass2, "pass");
        byte[] arrby = pass2.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(arrby, "this as java.lang.String).getBytes(charset)");
        return CryptoKt.hex(CryptoKt.sha1(arrby));
    }

    private static final void authenticate(AbstractOperationDSL $this$authenticate, List<? extends Role> forRoles) throws InvalidActionForRoleException, UnAuthorizedUserException {
        $this$authenticate.accessRule((Function1<? super Context, ? extends Exception>)new Function1<Context, Exception>(forRoles){
            final /* synthetic */ List<Role> $forRoles;
            {
                this.$forRoles = $forRoles;
                super(1);
            }

            @Nullable
            public final Exception invoke(@NotNull Context it) {
                Intrinsics.checkNotNullParameter(it, "it");
                Context this_$iv = it;
                boolean $i$f$get = false;
                Object object = (JWTPrincipal)this_$iv.get(Reflection.getOrCreateKotlinClass(JWTPrincipal.class));
                String string = object != null && (object = ((JWTPayloadHolder)object).getPayload()) != null && (object = object.getClaim("role")) != null ? object.asString() : null;
                if (string == null) {
                    return new UnAuthorizedUserException();
                }
                String roleStr = string;
                Role role = Role.valueOf(roleStr);
                if (!this.$forRoles.contains((Object)((Object)role))) {
                    return new InvalidActionForRoleException();
                }
                return null;
            }
        });
    }

    @NotNull
    public static final Publisher authenticatedQuery(@NotNull SchemaBuilder $this$authenticatedQuery, @NotNull String name, @NotNull List<? extends Role> forRoles, @NotNull Function1<? super QueryDSL, Unit> init2) {
        Intrinsics.checkNotNullParameter($this$authenticatedQuery, "<this>");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(forRoles, "forRoles");
        Intrinsics.checkNotNullParameter(init2, "init");
        return $this$authenticatedQuery.query(name, (Function1<? super QueryDSL, Unit>)new Function1<QueryDSL, Unit>(forRoles, init2){
            final /* synthetic */ List<Role> $forRoles;
            final /* synthetic */ Function1<QueryDSL, Unit> $init;
            {
                this.$forRoles = $forRoles;
                this.$init = $init;
                super(1);
            }

            public final void invoke(@NotNull QueryDSL $this$query) {
                Intrinsics.checkNotNullParameter($this$query, "$this$query");
                ExtensionsKt.access$authenticate($this$query, this.$forRoles);
                this.$init.invoke($this$query);
            }
        });
    }

    public static /* synthetic */ Publisher authenticatedQuery$default(SchemaBuilder schemaBuilder, String string, List list, Function1 function1, int n, Object object) {
        if ((n & 2) != 0) {
            list = CollectionsKt.listOf(Role.ADMIN);
        }
        return ExtensionsKt.authenticatedQuery(schemaBuilder, string, list, function1);
    }

    @NotNull
    public static final Publisher authenticatedMutation(@NotNull SchemaBuilder $this$authenticatedMutation, @NotNull String name, @NotNull List<? extends Role> forRoles, @NotNull Function1<? super MutationDSL, Unit> init2) {
        Intrinsics.checkNotNullParameter($this$authenticatedMutation, "<this>");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(forRoles, "forRoles");
        Intrinsics.checkNotNullParameter(init2, "init");
        return $this$authenticatedMutation.mutation(name, (Function1<? super MutationDSL, Unit>)new Function1<MutationDSL, Unit>(forRoles, init2){
            final /* synthetic */ List<Role> $forRoles;
            final /* synthetic */ Function1<MutationDSL, Unit> $init;
            {
                this.$forRoles = $forRoles;
                this.$init = $init;
                super(1);
            }

            public final void invoke(@NotNull MutationDSL $this$mutation) {
                Intrinsics.checkNotNullParameter($this$mutation, "$this$mutation");
                ExtensionsKt.access$authenticate($this$mutation, this.$forRoles);
                this.$init.invoke($this$mutation);
            }
        });
    }

    public static /* synthetic */ Publisher authenticatedMutation$default(SchemaBuilder schemaBuilder, String string, List list, Function1 function1, int n, Object object) {
        if ((n & 2) != 0) {
            list = CollectionsKt.listOf(Role.ADMIN);
        }
        return ExtensionsKt.authenticatedMutation(schemaBuilder, string, list, function1);
    }

    public static final double round(double value, int places) {
        if (!(places >= 0)) {
            String string = "Failed requirement.";
            throw new IllegalArgumentException(string.toString());
        }
        BigDecimal bigDecimal = BigDecimal.valueOf(value);
        Intrinsics.checkNotNullExpressionValue(bigDecimal, "valueOf(value)");
        BigDecimal bd = bigDecimal;
        BigDecimal bigDecimal2 = bd.setScale(places, RoundingMode.HALF_UP);
        Intrinsics.checkNotNullExpressionValue(bigDecimal2, "bd.setScale(places, RoundingMode.HALF_UP)");
        bd = bigDecimal2;
        return bd.doubleValue();
    }

    public static final /* synthetic */ void access$authenticate(AbstractOperationDSL $receiver, List forRoles) {
        ExtensionsKt.authenticate($receiver, forRoles);
    }
}

