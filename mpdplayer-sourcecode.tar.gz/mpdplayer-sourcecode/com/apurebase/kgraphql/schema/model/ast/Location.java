/*
 * Decompiled with CFR 0.150.
 */
package com.apurebase.kgraphql.schema.model.ast;

import com.apurebase.kgraphql.schema.model.ast.Source;
import com.apurebase.kgraphql.schema.model.ast.Token;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u001f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007B-\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u000bJ\u0006\u0010\u0014\u001a\u00020\u0015R\u0011\u0010\n\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000f\u00a8\u0006\u0017"}, d2={"Lcom/apurebase/kgraphql/schema/model/ast/Location;", "", "startToken", "Lcom/apurebase/kgraphql/schema/model/ast/Token;", "endToken", "source", "Lcom/apurebase/kgraphql/schema/model/ast/Source;", "(Lcom/apurebase/kgraphql/schema/model/ast/Token;Lcom/apurebase/kgraphql/schema/model/ast/Token;Lcom/apurebase/kgraphql/schema/model/ast/Source;)V", "start", "", "end", "(IILcom/apurebase/kgraphql/schema/model/ast/Token;Lcom/apurebase/kgraphql/schema/model/ast/Token;Lcom/apurebase/kgraphql/schema/model/ast/Source;)V", "getEnd", "()I", "getEndToken", "()Lcom/apurebase/kgraphql/schema/model/ast/Token;", "getSource", "()Lcom/apurebase/kgraphql/schema/model/ast/Source;", "getStart", "getStartToken", "printLocation", "", "Companion", "kgraphql"})
public final class Location {
    @NotNull
    public static final Companion Companion = new Companion(null);
    private final int start;
    private final int end;
    @NotNull
    private final Token startToken;
    @NotNull
    private final Token endToken;
    @NotNull
    private final Source source;

    public Location(int start2, int end2, @NotNull Token startToken, @NotNull Token endToken, @NotNull Source source2) {
        Intrinsics.checkNotNullParameter(startToken, "startToken");
        Intrinsics.checkNotNullParameter(endToken, "endToken");
        Intrinsics.checkNotNullParameter(source2, "source");
        this.start = start2;
        this.end = end2;
        this.startToken = startToken;
        this.endToken = endToken;
        this.source = source2;
    }

    public final int getStart() {
        return this.start;
    }

    public final int getEnd() {
        return this.end;
    }

    @NotNull
    public final Token getStartToken() {
        return this.startToken;
    }

    @NotNull
    public final Token getEndToken() {
        return this.endToken;
    }

    @NotNull
    public final Source getSource() {
        return this.source;
    }

    public Location(@NotNull Token startToken, @NotNull Token endToken, @NotNull Source source2) {
        Intrinsics.checkNotNullParameter(startToken, "startToken");
        Intrinsics.checkNotNullParameter(endToken, "endToken");
        Intrinsics.checkNotNullParameter(source2, "source");
        this(startToken.getStart(), endToken.getEnd(), startToken, endToken, source2);
    }

    @NotNull
    public final String printLocation() {
        return this.source.print(Companion.getLocation(this.source, this.start));
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b\u00a8\u0006\t"}, d2={"Lcom/apurebase/kgraphql/schema/model/ast/Location$Companion;", "", "()V", "getLocation", "Lcom/apurebase/kgraphql/schema/model/ast/Source$LocationSource;", "source", "Lcom/apurebase/kgraphql/schema/model/ast/Source;", "position", "", "kgraphql"})
    public static final class Companion {
        private Companion() {
        }

        /*
         * WARNING - void declaration
         */
        @NotNull
        public final Source.LocationSource getLocation(@NotNull Source source2, int position) {
            void $this$mapTo$iv$iv;
            Intrinsics.checkNotNullParameter(source2, "source");
            String string = "\\r\\n|[\\n\\r]";
            boolean bl = false;
            Regex lineRegexp = new Regex(string);
            int line = 0;
            line = 1;
            int column = 0;
            column = position + 1;
            Iterable $this$map$iv = SequencesKt.toList(Regex.findAll$default(lineRegexp, source2.getBody(), 0, 2, null));
            boolean $i$f$map = false;
            Iterable iterable = $this$map$iv;
            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
            boolean $i$f$mapTo = false;
            for (Object item$iv$iv : $this$mapTo$iv$iv) {
                void it;
                MatchResult matchResult = (MatchResult)item$iv$iv;
                Collection collection = destination$iv$iv;
                boolean bl2 = false;
                if (it.getRange().getFirst() < position) {
                    ++line;
                    column = position + 1 - (it.getRange().getFirst() + it.getValue().length());
                }
                Unit unit = Unit.INSTANCE;
                collection.add(unit);
            }
            List cfr_ignored_0 = (List)destination$iv$iv;
            return new Source.LocationSource(line, column);
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

