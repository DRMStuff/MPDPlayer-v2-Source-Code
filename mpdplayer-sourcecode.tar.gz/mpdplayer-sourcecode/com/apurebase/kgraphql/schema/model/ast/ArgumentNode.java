/*
 * Decompiled with CFR 0.150.
 */
package com.apurebase.kgraphql.schema.model.ast;

import com.apurebase.kgraphql.schema.model.ast.ASTNode;
import com.apurebase.kgraphql.schema.model.ast.Location;
import com.apurebase.kgraphql.schema.model.ast.NameNode;
import com.apurebase.kgraphql.schema.model.ast.ValueNode;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0011\u001a\u00020\u0007H\u00c6\u0003J)\u0010\u0012\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007H\u00c6\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u00d6\u0003J\t\u0010\u0017\u001a\u00020\u0018H\u00d6\u0001J\t\u0010\u0019\u001a\u00020\u001aH\u00d6\u0001R\u0016\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e\u00a8\u0006\u001b"}, d2={"Lcom/apurebase/kgraphql/schema/model/ast/ArgumentNode;", "Lcom/apurebase/kgraphql/schema/model/ast/ASTNode;", "loc", "Lcom/apurebase/kgraphql/schema/model/ast/Location;", "name", "Lcom/apurebase/kgraphql/schema/model/ast/NameNode;", "value", "Lcom/apurebase/kgraphql/schema/model/ast/ValueNode;", "(Lcom/apurebase/kgraphql/schema/model/ast/Location;Lcom/apurebase/kgraphql/schema/model/ast/NameNode;Lcom/apurebase/kgraphql/schema/model/ast/ValueNode;)V", "getLoc", "()Lcom/apurebase/kgraphql/schema/model/ast/Location;", "getName", "()Lcom/apurebase/kgraphql/schema/model/ast/NameNode;", "getValue", "()Lcom/apurebase/kgraphql/schema/model/ast/ValueNode;", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "kgraphql"})
public final class ArgumentNode
extends ASTNode {
    @Nullable
    private final Location loc;
    @NotNull
    private final NameNode name;
    @NotNull
    private final ValueNode value;

    public ArgumentNode(@Nullable Location loc, @NotNull NameNode name, @NotNull ValueNode value) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(value, "value");
        this.loc = loc;
        this.name = name;
        this.value = value;
    }

    @Override
    @Nullable
    public Location getLoc() {
        return this.loc;
    }

    @NotNull
    public final NameNode getName() {
        return this.name;
    }

    @NotNull
    public final ValueNode getValue() {
        return this.value;
    }

    @Nullable
    public final Location component1() {
        return this.getLoc();
    }

    @NotNull
    public final NameNode component2() {
        return this.name;
    }

    @NotNull
    public final ValueNode component3() {
        return this.value;
    }

    @NotNull
    public final ArgumentNode copy(@Nullable Location loc, @NotNull NameNode name, @NotNull ValueNode value) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(value, "value");
        return new ArgumentNode(loc, name, value);
    }

    public static /* synthetic */ ArgumentNode copy$default(ArgumentNode argumentNode, Location location, NameNode nameNode, ValueNode valueNode, int n, Object object) {
        if ((n & 1) != 0) {
            location = argumentNode.getLoc();
        }
        if ((n & 2) != 0) {
            nameNode = argumentNode.name;
        }
        if ((n & 4) != 0) {
            valueNode = argumentNode.value;
        }
        return argumentNode.copy(location, nameNode, valueNode);
    }

    @NotNull
    public String toString() {
        return "ArgumentNode(loc=" + this.getLoc() + ", name=" + this.name + ", value=" + this.value + ')';
    }

    public int hashCode() {
        int result2 = this.getLoc() == null ? 0 : this.getLoc().hashCode();
        result2 = result2 * 31 + this.name.hashCode();
        result2 = result2 * 31 + this.value.hashCode();
        return result2;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ArgumentNode)) {
            return false;
        }
        ArgumentNode argumentNode = (ArgumentNode)other;
        if (!Intrinsics.areEqual(this.getLoc(), argumentNode.getLoc())) {
            return false;
        }
        if (!Intrinsics.areEqual(this.name, argumentNode.name)) {
            return false;
        }
        return Intrinsics.areEqual(this.value, argumentNode.value);
    }
}

