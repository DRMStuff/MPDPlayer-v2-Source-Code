/*
 * Decompiled with CFR 0.150.
 */
package com.apurebase.kgraphql.schema.model;

import com.apurebase.kgraphql.schema.model.BaseOperationDef;
import com.apurebase.kgraphql.schema.model.DescribedDef;
import com.apurebase.kgraphql.schema.model.FunctionWrapper;
import com.apurebase.kgraphql.schema.model.InputValueDef;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000N\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000*\u0004\b\u0000\u0010\u00012\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u0002H\u00010\u00022\u00020\u0004B\u007f\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0006\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0006\u0012&\b\u0002\u0010\r\u001a \u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0004\u0012\u00020\u000f\u0012\f\u0012\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u0018\u00010\u000e\u0012\u0012\b\u0002\u0010\u0012\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00140\u0013\u0012\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0016\u00a2\u0006\u0002\u0010\u0017R\u0016\u0010\f\u001a\u0004\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0016\u0010\t\u001a\u0004\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0014\u0010\n\u001a\u00020\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u001b\u00a8\u0006\u001c"}, d2={"Lcom/apurebase/kgraphql/schema/model/MutationDef;", "R", "Lcom/apurebase/kgraphql/schema/model/BaseOperationDef;", "", "Lcom/apurebase/kgraphql/schema/model/DescribedDef;", "name", "", "resolver", "Lcom/apurebase/kgraphql/schema/model/FunctionWrapper;", "description", "isDeprecated", "", "deprecationReason", "accessRule", "Lkotlin/Function2;", "Lcom/apurebase/kgraphql/Context;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "inputValues", "", "Lcom/apurebase/kgraphql/schema/model/InputValueDef;", "explicitReturnType", "Lkotlin/reflect/KType;", "(Ljava/lang/String;Lcom/apurebase/kgraphql/schema/model/FunctionWrapper;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function2;Ljava/util/List;Lkotlin/reflect/KType;)V", "getDeprecationReason", "()Ljava/lang/String;", "getDescription", "()Z", "kgraphql"})
public final class MutationDef<R>
extends BaseOperationDef
implements DescribedDef {
    @Nullable
    private final String description;
    private final boolean isDeprecated;
    @Nullable
    private final String deprecationReason;

    public MutationDef(@NotNull String name, @NotNull FunctionWrapper<R> resolver, @Nullable String description2, boolean isDeprecated, @Nullable String deprecationReason, @Nullable Function2 accessRule2, @NotNull List<? extends InputValueDef<?>> inputValues, @Nullable KType explicitReturnType) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(resolver, "resolver");
        Intrinsics.checkNotNullParameter(inputValues, "inputValues");
        super(name, resolver, inputValues, accessRule2, explicitReturnType);
        this.description = description2;
        this.isDeprecated = isDeprecated;
        this.deprecationReason = deprecationReason;
    }

    public /* synthetic */ MutationDef(String string, FunctionWrapper functionWrapper, String string2, boolean bl, String string3, Function2 function2, List list, KType kType, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 0x20) != 0) {
            function2 = null;
        }
        if ((n & 0x40) != 0) {
            list = CollectionsKt.emptyList();
        }
        if ((n & 0x80) != 0) {
            kType = null;
        }
        this(string, functionWrapper, string2, bl, string3, function2, list, kType);
    }

    @Override
    @Nullable
    public String getDescription() {
        return this.description;
    }

    @Override
    public boolean isDeprecated() {
        return this.isDeprecated;
    }

    @Override
    @Nullable
    public String getDeprecationReason() {
        return this.deprecationReason;
    }
}

