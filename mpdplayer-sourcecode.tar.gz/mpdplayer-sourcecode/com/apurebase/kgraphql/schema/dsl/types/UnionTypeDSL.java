/*
 * Decompiled with CFR 0.150.
 */
package com.apurebase.kgraphql.schema.dsl.types;

import com.apurebase.kgraphql.schema.dsl.ItemDSL;
import com.apurebase.kgraphql.schema.dsl.types.TypeDSL;
import com.apurebase.kgraphql.schema.dsl.types.UnionTypeDSL;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0015\u0010\u0011\u001a\u00020\u000b\"\n\b\u0000\u0010\u0012\u0018\u0001*\u00020\u0013H\u0086\bJ\u001e\u0010\u0011\u001a\u00020\u000b\"\b\b\u0000\u0010\u0012*\u00020\u00132\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00120\u0005R\u001e\u0010\u0003\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00050\u0004X\u0080\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R/\u0010\b\u001a\u0017\u0012\b\u0012\u0006\u0012\u0002\b\u00030\n\u0012\u0004\u0012\u00020\u000b0\t\u00a2\u0006\u0002\b\fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010\u00a8\u0006\u0015"}, d2={"Lcom/apurebase/kgraphql/schema/dsl/types/UnionTypeDSL;", "Lcom/apurebase/kgraphql/schema/dsl/ItemDSL;", "()V", "possibleTypes", "", "Lkotlin/reflect/KClass;", "getPossibleTypes$kgraphql", "()Ljava/util/Set;", "subTypeBlock", "Lkotlin/Function1;", "Lcom/apurebase/kgraphql/schema/dsl/types/TypeDSL;", "", "Lkotlin/ExtensionFunctionType;", "getSubTypeBlock", "()Lkotlin/jvm/functions/Function1;", "setSubTypeBlock", "(Lkotlin/jvm/functions/Function1;)V", "type", "T", "", "kClass", "kgraphql"})
public final class UnionTypeDSL
extends ItemDSL {
    @NotNull
    private final Set<KClass<?>> possibleTypes;
    @NotNull
    private Function1<? super TypeDSL<?>, Unit> subTypeBlock;

    public UnionTypeDSL() {
        boolean bl = false;
        this.possibleTypes = new LinkedHashSet();
        this.subTypeBlock = subTypeBlock.1.INSTANCE;
    }

    @NotNull
    public final Set<KClass<?>> getPossibleTypes$kgraphql() {
        return this.possibleTypes;
    }

    @NotNull
    public final Function1<TypeDSL<?>, Unit> getSubTypeBlock() {
        return this.subTypeBlock;
    }

    public final void setSubTypeBlock(@NotNull Function1<? super TypeDSL<?>, Unit> function1) {
        Intrinsics.checkNotNullParameter(function1, "<set-?>");
        this.subTypeBlock = function1;
    }

    public final <T> void type(@NotNull KClass<T> kClass) {
        Intrinsics.checkNotNullParameter(kClass, "kClass");
        this.possibleTypes.add(kClass);
    }

    public final /* synthetic */ <T> void type() {
        boolean $i$f$type = false;
        Intrinsics.reifiedOperationMarker(4, "T");
        this.type(Reflection.getOrCreateKotlinClass(Object.class));
    }
}

