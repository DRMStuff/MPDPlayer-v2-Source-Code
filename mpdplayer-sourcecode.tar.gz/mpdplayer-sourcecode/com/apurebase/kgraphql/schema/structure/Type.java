/*
 * Decompiled with CFR 0.150.
 */
package com.apurebase.kgraphql.schema.structure;

import com.apurebase.kgraphql.Context;
import com.apurebase.kgraphql.schema.execution.Execution;
import com.apurebase.kgraphql.schema.introspection.TypeKind;
import com.apurebase.kgraphql.schema.introspection.__EnumValue;
import com.apurebase.kgraphql.schema.introspection.__Field;
import com.apurebase.kgraphql.schema.introspection.__InputValue;
import com.apurebase.kgraphql.schema.introspection.__Type;
import com.apurebase.kgraphql.schema.introspection.__TypeKt;
import com.apurebase.kgraphql.schema.model.EnumValueDef;
import com.apurebase.kgraphql.schema.model.TypeDef;
import com.apurebase.kgraphql.schema.scalar.ScalarCoercion;
import com.apurebase.kgraphql.schema.structure.EnumValue;
import com.apurebase.kgraphql.schema.structure.Field;
import com.apurebase.kgraphql.schema.structure.InputValue;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.ranges.RangesKt;
import kotlin.reflect.KClass;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeProjection;
import kotlin.reflect.full.KClassifiers;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000f\bf\u0018\u00002\u00020\u0001:\f\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f !\"#J\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH\u0096\u0002J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tH\u0016J\b\u0010\f\u001a\u00020\u000bH\u0016J\u0012\u0010\r\u001a\u00020\u000b2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u000bH\u0016J\b\u0010\u0011\u001a\u00020\u000bH\u0016J\b\u0010\u0012\u001a\u00020\u000bH\u0016J\b\u0010\u0013\u001a\u00020\u000bH\u0016J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0000H\u0016J\b\u0010\u0017\u001a\u00020\u0000H\u0016R\u0018\u0010\u0002\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005\u00a8\u0006$"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type;", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "get", "Lcom/apurebase/kgraphql/schema/structure/Field;", "name", "", "hasField", "", "isElementNullable", "isInstance", "value", "", "isList", "isNotList", "isNotNullable", "isNullable", "toKType", "Lkotlin/reflect/KType;", "unwrapList", "unwrapped", "AList", "ComplexType", "Enum", "Input", "Interface", "NonNull", "Object", "OperationObject", "Scalar", "Union", "_Context", "_ExecutionNode", "kgraphql"})
public interface Type
extends __Type {
    public boolean hasField(@NotNull String var1);

    @Nullable
    public Field get(@NotNull String var1);

    @NotNull
    public Type unwrapped();

    public boolean isNullable();

    public boolean isNotNullable();

    @NotNull
    public Type unwrapList();

    public boolean isList();

    public boolean isNotList();

    public boolean isElementNullable();

    public boolean isInstance(@Nullable java.lang.Object var1);

    @NotNull
    public KType toKType();

    @Nullable
    public KClass<?> getKClass();

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\b&\u0018\u00002\u00020\u0001B\u0013\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0002\u0010\u0005J\u0013\u0010\u0010\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0011\u001a\u00020\rH\u0096\u0002J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0011\u001a\u00020\rH\u0016R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001c\u0010\b\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0007R\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00040\f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f\u00a8\u0006\u0014"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$ComplexType;", "Lcom/apurebase/kgraphql/schema/structure/Type;", "allFields", "", "Lcom/apurebase/kgraphql/schema/structure/Field;", "(Ljava/util/List;)V", "getAllFields", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "fieldsByName", "", "", "getFieldsByName", "()Ljava/util/Map;", "get", "name", "hasField", "", "kgraphql"})
    public static abstract class ComplexType
    implements Type {
        @NotNull
        private final List<Field> allFields;
        @NotNull
        private final Map<String, Field> fieldsByName;
        @Nullable
        private final List<__Field> fields;

        /*
         * WARNING - void declaration
         */
        public ComplexType(@NotNull List<? extends Field> allFields) {
            void $this$filterNotTo$iv$iv;
            void $this$filterNot$iv;
            java.lang.Object object;
            void $this$associateByTo$iv$iv;
            Iterable $this$associateBy$iv;
            Intrinsics.checkNotNullParameter(allFields, "allFields");
            this.allFields = allFields;
            Iterable iterable = this.allFields;
            ComplexType complexType = this;
            boolean $i$f$associateBy = false;
            int capacity$iv22 = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$associateBy$iv, 10)), 16);
            void var5_7 = $this$associateBy$iv;
            Map destination$iv$iv = new LinkedHashMap(capacity$iv22);
            boolean $i$f$associateByTo = false;
            for (java.lang.Object element$iv$iv : $this$associateByTo$iv$iv) {
                void it;
                Field field = (Field)element$iv$iv;
                object = destination$iv$iv;
                boolean bl = false;
                String string = it.getName();
                object.put(string, element$iv$iv);
            }
            object = destination$iv$iv;
            complexType.fieldsByName = object;
            $this$associateBy$iv = this.allFields;
            complexType = this;
            boolean $i$f$filterNot = false;
            void capacity$iv22 = $this$filterNot$iv;
            Collection destination$iv$iv2 = new ArrayList();
            boolean $i$f$filterNotTo = false;
            for (java.lang.Object element$iv$iv : $this$filterNotTo$iv$iv) {
                Field it = (Field)element$iv$iv;
                boolean bl = false;
                if (StringsKt.startsWith$default(it.getName(), "__", false, 2, null)) continue;
                destination$iv$iv2.add(element$iv$iv);
            }
            complexType.fields = object = (List)destination$iv$iv2;
        }

        @NotNull
        public final List<Field> getAllFields() {
            return this.allFields;
        }

        @NotNull
        public final Map<String, Field> getFieldsByName() {
            return this.fieldsByName;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        public boolean hasField(@NotNull String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            return this.fieldsByName.get(name) != null;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            return this.fieldsByName.get(name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0010\bJ\u0012\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016R\u0014\u0010\u0004\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001c\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001c\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR \u0010\u0012\u001a\u000e\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0013\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000eR\u001a\u0010\u0015\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0016X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0014\u0010\u0019\u001a\u00020\u001aX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\nR\u0016\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001c\u0010\"\u001a\n\u0012\u0004\u0012\u00020\u001f\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u000e\u00a8\u0006("}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$OperationObject;", "Lcom/apurebase/kgraphql/schema/structure/Type$ComplexType;", "name", "", "description", "fields", "", "Lcom/apurebase/kgraphql/schema/structure/Field;", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getDescription", "()Ljava/lang/String;", "enumValues", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/structure/Type$Interface;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getName", "ofType", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "isInstance", "", "value", "", "kgraphql"})
    public static final class OperationObject
    extends ComplexType {
        @NotNull
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final KClass<?> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> possibleTypes;
        @Nullable
        private final List<Interface<?>> interfaces;

        public OperationObject(@NotNull String name, @NotNull String description2, @NotNull List<? extends Field> fields2) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(description2, "description");
            Intrinsics.checkNotNullParameter(fields2, "fields");
            super(fields2);
            this.name = name;
            this.description = description2;
            this.kind = TypeKind.OBJECT;
            this.interfaces = CollectionsKt.emptyList();
        }

        @Override
        @NotNull
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Nullable
        public List<Interface<?>> getInterfaces() {
            return this.interfaces;
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return false;
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000X\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0003B5\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0010\b\u0002\u0010\t\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\u0007\u00a2\u0006\u0002\u0010\u000bJ\u001a\u0010(\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\rX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0010\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u001c\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0015\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u001c\u0010\t\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u001a\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00000\u0019X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\u00020\u001dX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0016\u0010 \u001a\u0004\u0018\u00010\rX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u000fR\u0016\u0010\"\u001a\u0004\u0018\u00010#X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u001c\u0010&\u001a\n\u0012\u0004\u0012\u00020#\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0013\u00a8\u0006)"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Object;", "T", "", "Lcom/apurebase/kgraphql/schema/structure/Type$ComplexType;", "definition", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Object;", "fields", "", "Lcom/apurebase/kgraphql/schema/structure/Field;", "interfaces", "Lcom/apurebase/kgraphql/schema/structure/Type;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Object;Ljava/util/List;Ljava/util/List;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "withInterfaces", "kgraphql"})
    public static final class Object<T>
    extends ComplexType {
        @NotNull
        private final TypeDef.Object<T> definition;
        @Nullable
        private final List<Type> interfaces;
        @NotNull
        private final KClass<T> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> possibleTypes;

        public Object(@NotNull TypeDef.Object<T> definition, @NotNull List<? extends Field> fields2, @Nullable List<? extends Type> interfaces) {
            Intrinsics.checkNotNullParameter(definition, "definition");
            Intrinsics.checkNotNullParameter(fields2, "fields");
            super(fields2);
            this.definition = definition;
            this.interfaces = interfaces;
            this.kClass = this.definition.getKClass();
            this.kind = TypeKind.OBJECT;
            this.name = this.definition.getName();
            String string = this.definition.getDescription();
            this.description = string == null ? "" : string;
        }

        public /* synthetic */ Object(TypeDef.Object object, List list, List list2, int n, DefaultConstructorMarker defaultConstructorMarker) {
            if ((n & 2) != 0) {
                list = CollectionsKt.emptyList();
            }
            if ((n & 4) != 0) {
                list2 = CollectionsKt.emptyList();
            }
            this(object, list, list2);
        }

        @Nullable
        public List<Type> getInterfaces() {
            return this.interfaces;
        }

        @NotNull
        public KClass<T> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @NotNull
        public final Object<T> withInterfaces(@NotNull List<? extends Type> interfaces) {
            Intrinsics.checkNotNullParameter(interfaces, "interfaces");
            return new Object<T>(this.definition, this.getAllFields(), interfaces);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000X\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0003B5\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0010\b\u0002\u0010\t\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\u0007\u00a2\u0006\u0002\u0010\u000bJ\u001a\u0010(\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\u00020\rX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0010\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u001c\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0015\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u001c\u0010\u0017\u001a\n\u0012\u0004\u0012\u00020\u0018\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u001a\u0010\u001a\u001a\b\u0012\u0004\u0012\u00028\u00000\u001bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001e\u001a\u00020\u001fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0016\u0010\"\u001a\u0004\u0018\u00010\rX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u000fR\u0016\u0010$\u001a\u0004\u0018\u00010\u0018X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u001c\u0010\t\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0013\u00a8\u0006)"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Interface;", "T", "", "Lcom/apurebase/kgraphql/schema/structure/Type$ComplexType;", "definition", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Object;", "fields", "", "Lcom/apurebase/kgraphql/schema/structure/Field;", "possibleTypes", "Lcom/apurebase/kgraphql/schema/structure/Type;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Object;Ljava/util/List;Ljava/util/List;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getPossibleTypes", "withPossibleTypes", "kgraphql"})
    public static final class Interface<T>
    extends ComplexType {
        @NotNull
        private final TypeDef.Object<T> definition;
        @Nullable
        private final List<Type> possibleTypes;
        @NotNull
        private final KClass<T> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;

        public Interface(@NotNull TypeDef.Object<T> definition, @NotNull List<? extends Field> fields2, @Nullable List<? extends Type> possibleTypes) {
            Intrinsics.checkNotNullParameter(definition, "definition");
            Intrinsics.checkNotNullParameter(fields2, "fields");
            super(fields2);
            this.definition = definition;
            this.possibleTypes = possibleTypes;
            this.kClass = this.definition.getKClass();
            this.kind = TypeKind.INTERFACE;
            this.name = this.definition.getName();
            String string = this.definition.getDescription();
            this.description = string == null ? "" : string;
        }

        public /* synthetic */ Interface(TypeDef.Object object, List list, List list2, int n, DefaultConstructorMarker defaultConstructorMarker) {
            if ((n & 2) != 0) {
                list = CollectionsKt.emptyList();
            }
            if ((n & 4) != 0) {
                list2 = CollectionsKt.emptyList();
            }
            this(object, list, list2);
        }

        @Nullable
        public List<Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @NotNull
        public KClass<T> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @NotNull
        public final Interface<T> withPossibleTypes(@NotNull List<? extends Type> possibleTypes) {
            Intrinsics.checkNotNullParameter(possibleTypes, "possibleTypes");
            return new Interface<T>(this.definition, this.getAllFields(), possibleTypes);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000\\\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0003B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u00a2\u0006\u0002\u0010\u0006R\u001b\u0010\u0007\u001a\f\u0012\u0004\u0012\u00028\u0000\u0012\u0002\b\u00030\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001c\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u001c\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0015\u0018\u00010\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u001c\u0010\u0017\u001a\n\u0012\u0004\u0012\u00020\u0018\u0018\u00010\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u001c\u0010\u001a\u001a\n\u0012\u0004\u0012\u00020\u001b\u0018\u00010\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0013R\u001a\u0010\u001d\u001a\b\u0012\u0004\u0012\u00028\u00000\u001eX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0014\u0010!\u001a\u00020\"X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0016\u0010%\u001a\u0004\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\u000eR\u0016\u0010'\u001a\u0004\u0018\u00010\u001bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u001c\u0010*\u001a\n\u0012\u0004\u0012\u00020\u001b\u0018\u00010\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010\u0013\u00a8\u0006,"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Scalar;", "T", "", "Lcom/apurebase/kgraphql/schema/structure/Type;", "kqlType", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Scalar;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Scalar;)V", "coercion", "Lcom/apurebase/kgraphql/schema/scalar/ScalarCoercion;", "getCoercion", "()Lcom/apurebase/kgraphql/schema/scalar/ScalarCoercion;", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "kgraphql"})
    public static final class Scalar<T>
    implements Type {
        @NotNull
        private final KClass<T> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> possibleTypes;
        @NotNull
        private final ScalarCoercion<T, ?> coercion;

        public Scalar(@NotNull TypeDef.Scalar<T> kqlType) {
            Intrinsics.checkNotNullParameter(kqlType, "kqlType");
            this.kClass = kqlType.getKClass();
            this.kind = TypeKind.SCALAR;
            this.name = kqlType.getName();
            String string = kqlType.getDescription();
            this.description = string == null ? "" : string;
            this.coercion = kqlType.getCoercion();
        }

        @NotNull
        public KClass<T> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @NotNull
        public final ScalarCoercion<T, ?> getCoercion() {
            return this.coercion;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000\\\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000*\u000e\b\u0000\u0010\u0001*\b\u0012\u0004\u0012\u0002H\u00010\u00022\u00020\u0003B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u00a2\u0006\u0002\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001c\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0010\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u001c\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u0014\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000fR\u001c\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u000fR\u001a\u0010\u0019\u001a\b\u0012\u0004\u0012\u00028\u00000\u001aX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0014\u0010\u001d\u001a\u00020\u001eX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0016\u0010!\u001a\u0004\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\nR\u0016\u0010#\u001a\u0004\u0018\u00010\u0017X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u001c\u0010&\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b'\u0010\u000fR\u001d\u0010(\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000)0\f\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u000f\u00a8\u0006+"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Enum;", "T", "", "Lcom/apurebase/kgraphql/schema/structure/Type;", "kqlType", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Enumeration;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Enumeration;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "values", "Lcom/apurebase/kgraphql/schema/structure/EnumValue;", "getValues", "kgraphql"})
    public static final class Enum<T extends java.lang.Enum<T>>
    implements Type {
        @NotNull
        private final List<EnumValue<T>> values;
        @NotNull
        private final KClass<T> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> possibleTypes;

        /*
         * WARNING - void declaration
         */
        public Enum(@NotNull TypeDef.Enumeration<T> kqlType) {
            Collection collection;
            void $this$mapTo$iv$iv;
            void $this$map$iv;
            Intrinsics.checkNotNullParameter(kqlType, "kqlType");
            java.lang.Object object = kqlType.getValues();
            Enum enum_ = this;
            boolean $i$f$map = false;
            void var4_5 = $this$map$iv;
            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
            boolean $i$f$mapTo = false;
            for (java.lang.Object item$iv$iv : $this$mapTo$iv$iv) {
                void it;
                EnumValueDef enumValueDef = (EnumValueDef)item$iv$iv;
                collection = destination$iv$iv;
                boolean bl = false;
                EnumValue enumValue = it.toEnumValue();
                collection.add(enumValue);
            }
            collection = (List)destination$iv$iv;
            enum_.values = collection;
            this.kClass = kqlType.getKClass();
            this.kind = TypeKind.ENUM;
            this.name = kqlType.getName();
            object = kqlType.getDescription();
            this.description = object == null ? "" : object;
            this.enumValues = this.values;
        }

        @NotNull
        public final List<EnumValue<T>> getValues() {
            return this.values;
        }

        @NotNull
        public KClass<T> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000R\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0003B'\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\u0012\u0012\b\u0002\u0010\u0006\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b0\u0007\u00a2\u0006\u0002\u0010\tR\u0014\u0010\n\u001a\u00020\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001c\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001c\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u001e\u0010\u0006\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b0\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0011R\u001c\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0011R\u001a\u0010\u0019\u001a\b\u0012\u0004\u0012\u00028\u00000\u001aX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0014\u0010\u001d\u001a\u00020\u001eX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0016\u0010!\u001a\u0004\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\rR\u0016\u0010#\u001a\u0004\u0018\u00010\u0017X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u001c\u0010&\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0011\u00a8\u0006("}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Input;", "T", "", "Lcom/apurebase/kgraphql/schema/structure/Type;", "kqlType", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Input;", "inputFields", "", "Lcom/apurebase/kgraphql/schema/structure/InputValue;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Input;Ljava/util/List;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "kgraphql"})
    public static final class Input<T>
    implements Type {
        @NotNull
        private final List<InputValue<?>> inputFields;
        @NotNull
        private final KClass<T> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> possibleTypes;

        public Input(@NotNull TypeDef.Input<T> kqlType, @NotNull List<? extends InputValue<?>> inputFields) {
            Intrinsics.checkNotNullParameter(kqlType, "kqlType");
            Intrinsics.checkNotNullParameter(inputFields, "inputFields");
            this.inputFields = inputFields;
            this.kClass = kqlType.getKClass();
            this.kind = TypeKind.INPUT_OBJECT;
            this.name = kqlType.getName();
            String string = kqlType.getDescription();
            this.description = string == null ? "" : string;
        }

        public /* synthetic */ Input(TypeDef.Input input2, List list, int n, DefaultConstructorMarker defaultConstructorMarker) {
            if ((n & 2) != 0) {
                list = CollectionsKt.emptyList();
            }
            this(input2, list);
        }

        @NotNull
        public List<InputValue<?>> getInputFields() {
            return this.inputFields;
        }

        @NotNull
        public KClass<T> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u00a2\u0006\u0002\u0010\tJ\u0012\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010,H\u0016R\u0014\u0010\n\u001a\u00020\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001c\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001c\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u001c\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0016\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0011R\u001c\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u0019\u0018\u00010\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0011R\u001a\u0010\u001b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u001cX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010\u001f\u001a\u00020 X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0016\u0010#\u001a\u0004\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\rR\u0016\u0010%\u001a\u0004\u0018\u00010\u0019X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010'R\u001a\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0011\u00a8\u0006-"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$Union;", "Lcom/apurebase/kgraphql/schema/structure/Type$ComplexType;", "kqlType", "Lcom/apurebase/kgraphql/schema/model/TypeDef$Union;", "typenameResolver", "Lcom/apurebase/kgraphql/schema/structure/Field;", "possibleTypes", "", "Lcom/apurebase/kgraphql/schema/structure/Type;", "(Lcom/apurebase/kgraphql/schema/model/TypeDef$Union;Lcom/apurebase/kgraphql/schema/structure/Field;Ljava/util/List;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getPossibleTypes", "isInstance", "", "value", "", "kgraphql"})
    public static final class Union
    extends ComplexType {
        @NotNull
        private final List<Type> possibleTypes;
        @Nullable
        private final KClass<?> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;

        public Union(@NotNull TypeDef.Union kqlType, @NotNull Field typenameResolver2, @NotNull List<? extends Type> possibleTypes) {
            Intrinsics.checkNotNullParameter(kqlType, "kqlType");
            Intrinsics.checkNotNullParameter(typenameResolver2, "typenameResolver");
            Intrinsics.checkNotNullParameter(possibleTypes, "possibleTypes");
            super(CollectionsKt.listOf(typenameResolver2));
            this.possibleTypes = possibleTypes;
            this.kind = TypeKind.UNION;
            this.name = kqlType.getName();
            String string = kqlType.getDescription();
            this.description = string == null ? "" : string;
        }

        @NotNull
        public List<Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return false;
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u00020\u0004X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u001c\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u001c\u0010\f\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u001c\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000bR\u001c\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000bR\u001a\u0010\u0015\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0016X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0014\u0010\u0019\u001a\u00020\u001aX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0016\u0010\u001d\u001a\u0004\u0018\u00010\u0004X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0016\u0010\u001f\u001a\u0004\u0018\u00010\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001c\u0010\"\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u000b\u00a8\u0006$"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$_Context;", "Lcom/apurebase/kgraphql/schema/structure/Type;", "()V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "kgraphql"})
    public static final class _Context
    implements Type {
        @Nullable
        private final KClass<?> kClass = Reflection.getOrCreateKotlinClass(Context.class);
        @NotNull
        private final TypeKind kind = TypeKind.OBJECT;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> possibleTypes;

        public _Context() {
            this.description = "";
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u00020\u0004X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u001c\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u001c\u0010\f\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u001c\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000bR\u001c\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000bR\u001a\u0010\u0015\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0016X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0014\u0010\u0019\u001a\u00020\u001aX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0016\u0010\u001d\u001a\u0004\u0018\u00010\u0004X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0016\u0010\u001f\u001a\u0004\u0018\u00010\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001c\u0010\"\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u000b\u00a8\u0006$"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$_ExecutionNode;", "Lcom/apurebase/kgraphql/schema/structure/Type;", "()V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "kgraphql"})
    public static final class _ExecutionNode
    implements Type {
        @Nullable
        private final KClass<?> kClass = Reflection.getOrCreateKotlinClass(Execution.Node.class);
        @NotNull
        private final TypeKind kind = TypeKind.OBJECT;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;
        @Nullable
        private final __Type ofType;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> possibleTypes;

        public _ExecutionNode() {
            this.description = "";
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return DefaultImpls.isInstance(this, value);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0002\u0010\u0003J\u0012\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010'H\u0016J\b\u0010(\u001a\u00020\u0005H\u0016R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001c\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\tX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001c\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\tX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u001c\u0010\u0010\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\tX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\fR\u001c\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u0014\u0018\u00010\tX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\fR\u001a\u0010\u0016\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0017X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001a\u001a\u00020\u001bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0016\u0010\u001e\u001a\u0004\u0018\u00010\u0005X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0007R\u0014\u0010\u0002\u001a\u00020\u0001X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001c\u0010\"\u001a\n\u0012\u0004\u0012\u00020\u0014\u0018\u00010\tX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\f\u00a8\u0006)"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$NonNull;", "Lcom/apurebase/kgraphql/schema/structure/Type;", "ofType", "(Lcom/apurebase/kgraphql/schema/structure/Type;)V", "description", "", "getDescription", "()Ljava/lang/String;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "getOfType", "()Lcom/apurebase/kgraphql/schema/structure/Type;", "possibleTypes", "getPossibleTypes", "isInstance", "", "value", "", "toString", "kgraphql"})
    public static final class NonNull
    implements Type {
        @NotNull
        private final Type ofType;
        @Nullable
        private final KClass<?> kClass;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Type> possibleTypes;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;

        public NonNull(@NotNull Type ofType) {
            Intrinsics.checkNotNullParameter(ofType, "ofType");
            this.ofType = ofType;
            this.kind = TypeKind.NON_NULL;
            this.description = "NonNull wrapper type";
        }

        @Override
        @NotNull
        public Type getOfType() {
            return this.ofType;
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @NotNull
        public String toString() {
            return __TypeKt.asString(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return false;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=1, xi=48, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\u0002\u0010\u0003J\u0012\u0010'\u001a\u00020(2\b\u0010)\u001a\u0004\u0018\u00010*H\u0016J\b\u0010+\u001a\u00020\u0005H\u0016R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096D\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001c\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001c\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u001c\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000eR\u001c\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0016\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u000eR\u001a\u0010\u0018\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u0019X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\u00020\u001dX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0016\u0010 \u001a\u0004\u0018\u00010\u0005X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0007R\u0016\u0010\"\u001a\u0004\u0018\u00010\u0016X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u001c\u0010%\u001a\n\u0012\u0004\u0012\u00020\u0016\u0018\u00010\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\u000e\u00a8\u0006,"}, d2={"Lcom/apurebase/kgraphql/schema/structure/Type$AList;", "Lcom/apurebase/kgraphql/schema/structure/Type;", "elementType", "(Lcom/apurebase/kgraphql/schema/structure/Type;)V", "description", "", "getDescription", "()Ljava/lang/String;", "getElementType", "()Lcom/apurebase/kgraphql/schema/structure/Type;", "enumValues", "", "Lcom/apurebase/kgraphql/schema/introspection/__EnumValue;", "getEnumValues", "()Ljava/util/List;", "fields", "Lcom/apurebase/kgraphql/schema/introspection/__Field;", "getFields", "inputFields", "Lcom/apurebase/kgraphql/schema/introspection/__InputValue;", "getInputFields", "interfaces", "Lcom/apurebase/kgraphql/schema/introspection/__Type;", "getInterfaces", "kClass", "Lkotlin/reflect/KClass;", "getKClass", "()Lkotlin/reflect/KClass;", "kind", "Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "getKind", "()Lcom/apurebase/kgraphql/schema/introspection/TypeKind;", "name", "getName", "ofType", "getOfType", "()Lcom/apurebase/kgraphql/schema/introspection/__Type;", "possibleTypes", "getPossibleTypes", "isInstance", "", "value", "", "toString", "kgraphql"})
    public static final class AList
    implements Type {
        @NotNull
        private final Type elementType;
        @Nullable
        private final KClass<?> kClass;
        @Nullable
        private final __Type ofType;
        @NotNull
        private final TypeKind kind;
        @Nullable
        private final String name;
        @NotNull
        private final String description;
        @Nullable
        private final List<__Field> fields;
        @Nullable
        private final List<__Type> interfaces;
        @Nullable
        private final List<__Type> possibleTypes;
        @Nullable
        private final List<__EnumValue> enumValues;
        @Nullable
        private final List<__InputValue> inputFields;

        public AList(@NotNull Type elementType) {
            Intrinsics.checkNotNullParameter(elementType, "elementType");
            this.elementType = elementType;
            this.ofType = this.elementType;
            this.kind = TypeKind.LIST;
            this.description = "List wrapper type";
        }

        @NotNull
        public final Type getElementType() {
            return this.elementType;
        }

        @Override
        @Nullable
        public KClass<?> getKClass() {
            return this.kClass;
        }

        @Override
        @Nullable
        public __Type getOfType() {
            return this.ofType;
        }

        @Override
        @NotNull
        public TypeKind getKind() {
            return this.kind;
        }

        @Override
        @Nullable
        public String getName() {
            return this.name;
        }

        @Override
        @NotNull
        public String getDescription() {
            return this.description;
        }

        @Override
        @Nullable
        public List<__Field> getFields() {
            return this.fields;
        }

        @Override
        @Nullable
        public List<__Type> getInterfaces() {
            return this.interfaces;
        }

        @Override
        @Nullable
        public List<__Type> getPossibleTypes() {
            return this.possibleTypes;
        }

        @Override
        @Nullable
        public List<__EnumValue> getEnumValues() {
            return this.enumValues;
        }

        @Override
        @Nullable
        public List<__InputValue> getInputFields() {
            return this.inputFields;
        }

        @NotNull
        public String toString() {
            return __TypeKt.asString(this);
        }

        @Override
        public boolean isInstance(@Nullable java.lang.Object value) {
            return false;
        }

        @Override
        @Nullable
        public Field get(@NotNull String name) {
            return DefaultImpls.get(this, name);
        }

        @Override
        public boolean hasField(@NotNull String name) {
            return DefaultImpls.hasField(this, name);
        }

        @Override
        public boolean isElementNullable() {
            return DefaultImpls.isElementNullable(this);
        }

        @Override
        public boolean isList() {
            return DefaultImpls.isList(this);
        }

        @Override
        public boolean isNotList() {
            return DefaultImpls.isNotList(this);
        }

        @Override
        public boolean isNotNullable() {
            return DefaultImpls.isNotNullable(this);
        }

        @Override
        public boolean isNullable() {
            return DefaultImpls.isNullable(this);
        }

        @Override
        @NotNull
        public KType toKType() {
            return DefaultImpls.toKType(this);
        }

        @Override
        @NotNull
        public Type unwrapList() {
            return DefaultImpls.unwrapList(this);
        }

        @Override
        @NotNull
        public Type unwrapped() {
            return DefaultImpls.unwrapped(this);
        }
    }

    @Metadata(mv={1, 5, 1}, k=3, xi=48)
    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] arrn = new int[TypeKind.values().length];
            arrn[TypeKind.NON_NULL.ordinal()] = 1;
            arrn[TypeKind.LIST.ordinal()] = 2;
            $EnumSwitchMapping$0 = arrn;
        }
    }

    @Metadata(mv={1, 5, 1}, k=3, xi=48)
    public static final class DefaultImpls {
        public static boolean hasField(@NotNull Type this_, @NotNull String name) {
            boolean bl;
            Intrinsics.checkNotNullParameter(this_, "this");
            Intrinsics.checkNotNullParameter(name, "name");
            List<__Field> list = this_.getFields();
            if (list == null) {
                bl = false;
            } else {
                boolean bl2;
                boolean bl3;
                block5: {
                    Iterable $this$any$iv = list;
                    boolean $i$f$any = false;
                    if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                        bl3 = false;
                    } else {
                        for (java.lang.Object element$iv : $this$any$iv) {
                            __Field it = (__Field)element$iv;
                            boolean bl4 = false;
                            if (!Intrinsics.areEqual(it.getName(), name)) continue;
                            bl3 = true;
                            break block5;
                        }
                        bl3 = false;
                    }
                }
                bl = bl2 = bl3;
            }
            return bl;
        }

        @Nullable
        public static Field get(@NotNull Type this_, @NotNull String name) {
            Intrinsics.checkNotNullParameter(this_, "this");
            Intrinsics.checkNotNullParameter(name, "name");
            return null;
        }

        @NotNull
        public static Type unwrapped(@NotNull Type this_) {
            Type type2;
            Intrinsics.checkNotNullParameter(this_, "this");
            TypeKind typeKind = this_.getKind();
            int n = WhenMappings.$EnumSwitchMapping$0[typeKind.ordinal()];
            switch (n) {
                case 1: 
                case 2: {
                    __Type __Type2 = this_.getOfType();
                    if (__Type2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type com.apurebase.kgraphql.schema.structure.Type");
                    }
                    type2 = ((Type)__Type2).unwrapped();
                    break;
                }
                default: {
                    type2 = this_;
                }
            }
            return type2;
        }

        public static boolean isNullable(@NotNull Type this_) {
            Intrinsics.checkNotNullParameter(this_, "this");
            return this_.getKind() != TypeKind.NON_NULL;
        }

        public static boolean isNotNullable(@NotNull Type this_) {
            Intrinsics.checkNotNullParameter(this_, "this");
            return this_.getKind() == TypeKind.NON_NULL;
        }

        @NotNull
        public static Type unwrapList(@NotNull Type this_) {
            Type type2;
            Intrinsics.checkNotNullParameter(this_, "this");
            TypeKind typeKind = this_.getKind();
            int n = WhenMappings.$EnumSwitchMapping$0[typeKind.ordinal()];
            if (n == 2) {
                __Type __Type2 = this_.getOfType();
                if (__Type2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type com.apurebase.kgraphql.schema.structure.Type");
                }
                type2 = (Type)__Type2;
            } else {
                Type type3 = (Type)this_.getOfType();
                if (type3 == null) {
                    throw new NoSuchElementException("this type does not wrap list element");
                }
                type2 = type3.unwrapList();
            }
            return type2;
        }

        public static boolean isList(@NotNull Type this_) {
            boolean bl;
            Intrinsics.checkNotNullParameter(this_, "this");
            if (this_.getKind() == TypeKind.LIST) {
                bl = true;
            } else if (this_.getOfType() == null) {
                bl = false;
            } else {
                __Type __Type2 = this_.getOfType();
                if (__Type2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type com.apurebase.kgraphql.schema.structure.Type");
                }
                bl = ((Type)__Type2).isList();
            }
            return bl;
        }

        public static boolean isNotList(@NotNull Type this_) {
            Intrinsics.checkNotNullParameter(this_, "this");
            return !this_.isList();
        }

        public static boolean isElementNullable(@NotNull Type this_) {
            Intrinsics.checkNotNullParameter(this_, "this");
            return this_.isList() && this_.unwrapList().getKind() != TypeKind.NON_NULL;
        }

        public static boolean isInstance(@NotNull Type this_, @Nullable java.lang.Object value) {
            boolean bl;
            Intrinsics.checkNotNullParameter(this_, "this");
            KClass<?> kClass = this_.getKClass();
            return kClass == null ? false : (bl = kClass.isInstance(value));
        }

        @NotNull
        public static KType toKType(@NotNull Type this_) {
            Intrinsics.checkNotNullParameter(this_, "this");
            KClass<?> kClass = this_.unwrapped().getKClass();
            if (kClass == null) {
                throw new IllegalArgumentException("This type cannot be represented as KType");
            }
            KClass<?> unwrappedKClass = kClass;
            return this_.isList() ? KClassifiers.createType$default(Reflection.getOrCreateKotlinClass(List.class), CollectionsKt.listOf(KTypeProjection.Companion.covariant(KClassifiers.createType$default(unwrappedKClass, null, this_.isElementNullable(), null, 5, null))), this_.isNullable(), null, 4, null) : KClassifiers.createType$default(unwrappedKClass, null, this_.isNullable(), null, 5, null);
        }
    }
}

