/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.serialization.json.internal;

import kotlin.Metadata;
import kotlin.UByte;
import kotlin.UInt;
import kotlin.ULong;
import kotlin.UShort;
import kotlin.Unit;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.ExperimentalSerializationApi;
import kotlinx.serialization.PolymorphicSerializerKt;
import kotlinx.serialization.SerializationStrategy;
import kotlinx.serialization.descriptors.PolymorphicKind;
import kotlinx.serialization.descriptors.PrimitiveKind;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.descriptors.SerialKind;
import kotlinx.serialization.descriptors.StructureKind;
import kotlinx.serialization.encoding.AbstractEncoder;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.encoding.Encoder;
import kotlinx.serialization.internal.AbstractPolymorphicSerializer;
import kotlinx.serialization.internal.NamedValueEncoder;
import kotlinx.serialization.json.Json;
import kotlinx.serialization.json.JsonConfiguration;
import kotlinx.serialization.json.JsonElement;
import kotlinx.serialization.json.JsonElementKt;
import kotlinx.serialization.json.JsonElementSerializer;
import kotlinx.serialization.json.JsonEncoder;
import kotlinx.serialization.json.JsonLiteral;
import kotlinx.serialization.json.JsonNull;
import kotlinx.serialization.json.internal.JsonExceptionsKt;
import kotlinx.serialization.json.internal.JsonPrimitiveEncoder;
import kotlinx.serialization.json.internal.JsonTreeEncoder;
import kotlinx.serialization.json.internal.JsonTreeListEncoder;
import kotlinx.serialization.json.internal.JsonTreeMapEncoder;
import kotlinx.serialization.json.internal.PolymorphicKt;
import kotlinx.serialization.json.internal.StreamingJsonEncoderKt;
import kotlinx.serialization.json.internal.TreeJsonEncoderKt;
import kotlinx.serialization.json.internal.WriteModeKt;
import kotlinx.serialization.modules.SerializersModule;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ExperimentalSerializationApi
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u00a4\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\f\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\n\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b3\u0018\u00002\u00020\u00012\u00020\u0002B#\b\u0004\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006\u00a2\u0006\u0002\u0010\tJ\u0010\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\u0018\u0010\u0018\u001a\u00020\u000f2\u0006\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\u001a\u001a\u00020\u000fH\u0014J\u0010\u0010\u001b\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\u0007H\u0016J\b\u0010\u001d\u001a\u00020\bH\u0016J)\u0010\u001e\u001a\u00020\b\"\u0004\b\u0000\u0010\u001f2\f\u0010 \u001a\b\u0012\u0004\u0012\u0002H\u001f0!2\u0006\u0010\"\u001a\u0002H\u001fH\u0016\u00a2\u0006\u0002\u0010#J\u0018\u0010$\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020&H\u0014J\u0018\u0010'\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020(H\u0014J\u0018\u0010)\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020*H\u0014J\u0018\u0010+\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020,H\u0014J \u0010-\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010.\u001a\u00020\u00172\u0006\u0010/\u001a\u000200H\u0014J\u0018\u00101\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u000202H\u0014J\u0018\u00103\u001a\u0002042\u0006\u0010%\u001a\u00020\u000f2\u0006\u00105\u001a\u00020\u0017H\u0014J\u0018\u00106\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u000200H\u0014J\u0018\u00107\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u000208H\u0014J\u0010\u00109\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000fH\u0014J\u0018\u0010:\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020;H\u0014J\u0018\u0010<\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020\u000fH\u0014J\u0018\u0010=\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u000f2\u0006\u0010\"\u001a\u00020>H\u0014J\u0010\u0010?\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u0017H\u0014J\b\u0010@\u001a\u00020\u0007H&J\u0018\u0010A\u001a\u00020\b2\u0006\u0010B\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u0007H&J\u0018\u0010C\u001a\u00020&2\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010D\u001a\u000200H\u0016R\u0010\u0010\n\u001a\u00020\u000b8\u0004X\u0085\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0010\u001a\u00020\u00118F\u00a2\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013\u0082\u0001\u0003EFG\u00a8\u0006H"}, d2={"Lkotlinx/serialization/json/internal/AbstractJsonTreeEncoder;", "Lkotlinx/serialization/internal/NamedValueEncoder;", "Lkotlinx/serialization/json/JsonEncoder;", "json", "Lkotlinx/serialization/json/Json;", "nodeConsumer", "Lkotlin/Function1;", "Lkotlinx/serialization/json/JsonElement;", "", "(Lkotlinx/serialization/json/Json;Lkotlin/jvm/functions/Function1;)V", "configuration", "Lkotlinx/serialization/json/JsonConfiguration;", "getJson", "()Lkotlinx/serialization/json/Json;", "polymorphicDiscriminator", "", "serializersModule", "Lkotlinx/serialization/modules/SerializersModule;", "getSerializersModule", "()Lkotlinx/serialization/modules/SerializersModule;", "beginStructure", "Lkotlinx/serialization/encoding/CompositeEncoder;", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "composeName", "parentName", "childName", "encodeJsonElement", "element", "encodeNull", "encodeSerializableValue", "T", "serializer", "Lkotlinx/serialization/SerializationStrategy;", "value", "(Lkotlinx/serialization/SerializationStrategy;Ljava/lang/Object;)V", "encodeTaggedBoolean", "tag", "", "encodeTaggedByte", "", "encodeTaggedChar", "", "encodeTaggedDouble", "", "encodeTaggedEnum", "enumDescriptor", "ordinal", "", "encodeTaggedFloat", "", "encodeTaggedInline", "Lkotlinx/serialization/encoding/Encoder;", "inlineDescriptor", "encodeTaggedInt", "encodeTaggedLong", "", "encodeTaggedNull", "encodeTaggedShort", "", "encodeTaggedString", "encodeTaggedValue", "", "endEncode", "getCurrent", "putElement", "key", "shouldEncodeElementDefault", "index", "Lkotlinx/serialization/json/internal/JsonPrimitiveEncoder;", "Lkotlinx/serialization/json/internal/JsonTreeEncoder;", "Lkotlinx/serialization/json/internal/JsonTreeListEncoder;", "kotlinx-serialization-json"})
abstract class AbstractJsonTreeEncoder
extends NamedValueEncoder
implements JsonEncoder {
    @NotNull
    private final Json json;
    @NotNull
    private final Function1<JsonElement, Unit> nodeConsumer;
    @JvmField
    @NotNull
    protected final JsonConfiguration configuration;
    @Nullable
    private String polymorphicDiscriminator;

    private AbstractJsonTreeEncoder(Json json2, Function1<? super JsonElement, Unit> nodeConsumer) {
        this.json = json2;
        this.nodeConsumer = nodeConsumer;
        this.configuration = this.json.getConfiguration();
    }

    @Override
    @NotNull
    public final Json getJson() {
        return this.json;
    }

    @Override
    @NotNull
    public final SerializersModule getSerializersModule() {
        return this.json.getSerializersModule();
    }

    @Override
    public void encodeJsonElement(@NotNull JsonElement element) {
        Intrinsics.checkNotNullParameter(element, "element");
        this.encodeSerializableValue(JsonElementSerializer.INSTANCE, element);
    }

    @Override
    public boolean shouldEncodeElementDefault(@NotNull SerialDescriptor descriptor2, int index) {
        Intrinsics.checkNotNullParameter(descriptor2, "descriptor");
        return this.configuration.getEncodeDefaults();
    }

    @Override
    @NotNull
    protected String composeName(@NotNull String parentName, @NotNull String childName) {
        Intrinsics.checkNotNullParameter(parentName, "parentName");
        Intrinsics.checkNotNullParameter(childName, "childName");
        return childName;
    }

    public abstract void putElement(@NotNull String var1, @NotNull JsonElement var2);

    @NotNull
    public abstract JsonElement getCurrent();

    @Override
    public void encodeNull() {
        String string = (String)this.getCurrentTagOrNull();
        if (string == null) {
            this.nodeConsumer.invoke(JsonNull.INSTANCE);
            return;
        }
        String tag = string;
        this.encodeTaggedNull(tag);
    }

    @Override
    protected void encodeTaggedNull(@NotNull String tag) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonNull.INSTANCE);
    }

    @Override
    protected void encodeTaggedInt(@NotNull String tag, int value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedByte(@NotNull String tag, byte value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedShort(@NotNull String tag, short value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedLong(@NotNull String tag, long value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedFloat(@NotNull String tag, float value) {
        float f;
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(Float.valueOf(value)));
        if (!this.configuration.getAllowSpecialFloatingPointValues() && !(!Float.isInfinite(f = value) && !Float.isNaN(f))) {
            throw JsonExceptionsKt.InvalidFloatingPointEncoded(Float.valueOf(value), tag, this.getCurrent().toString());
        }
    }

    @Override
    public <T> void encodeSerializableValue(@NotNull SerializationStrategy<? super T> serializer2, T value) {
        Intrinsics.checkNotNullParameter(serializer2, "serializer");
        if (this.getCurrentTagOrNull() != null || !TreeJsonEncoderKt.access$getRequiresTopLevelTag(WriteModeKt.carrierDescriptor(serializer2.getDescriptor(), this.getSerializersModule()))) {
            JsonEncoder $this$encodePolymorphically$iv = this;
            boolean $i$f$encodePolymorphically = false;
            if (!(serializer2 instanceof AbstractPolymorphicSerializer) || $this$encodePolymorphically$iv.getJson().getConfiguration().getUseArrayPolymorphism()) {
                serializer2.serialize($this$encodePolymorphically$iv, value);
            } else {
                AbstractPolymorphicSerializer casted$iv = (AbstractPolymorphicSerializer)serializer2;
                String baseClassDiscriminator$iv = PolymorphicKt.classDiscriminator(serializer2.getDescriptor(), $this$encodePolymorphically$iv.getJson());
                T t = value;
                if (t == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Any");
                }
                SerializationStrategy<T> actualSerializer$iv = PolymorphicSerializerKt.findPolymorphicSerializer(casted$iv, $this$encodePolymorphically$iv, t);
                PolymorphicKt.access$validateIfSealed(casted$iv, actualSerializer$iv, baseClassDiscriminator$iv);
                PolymorphicKt.checkKind(actualSerializer$iv.getDescriptor().getKind());
                String it = baseClassDiscriminator$iv;
                boolean bl = false;
                this.polymorphicDiscriminator = it;
                actualSerializer$iv.serialize($this$encodePolymorphically$iv, value);
            }
        } else {
            JsonPrimitiveEncoder jsonPrimitiveEncoder;
            JsonPrimitiveEncoder $this$encodeSerializableValue_u24lambda_u2d1 = jsonPrimitiveEncoder = new JsonPrimitiveEncoder(this.json, this.nodeConsumer);
            boolean bl = false;
            $this$encodeSerializableValue_u24lambda_u2d1.encodeSerializableValue(serializer2, value);
            $this$encodeSerializableValue_u24lambda_u2d1.endEncode(serializer2.getDescriptor());
        }
    }

    @Override
    protected void encodeTaggedDouble(@NotNull String tag, double value) {
        double d;
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
        if (!this.configuration.getAllowSpecialFloatingPointValues() && !(!Double.isInfinite(d = value) && !Double.isNaN(d))) {
            throw JsonExceptionsKt.InvalidFloatingPointEncoded(value, tag, this.getCurrent().toString());
        }
    }

    @Override
    protected void encodeTaggedBoolean(@NotNull String tag, boolean value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedChar(@NotNull String tag, char value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        this.putElement(tag, JsonElementKt.JsonPrimitive(String.valueOf(value)));
    }

    @Override
    protected void encodeTaggedString(@NotNull String tag, @NotNull String value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        Intrinsics.checkNotNullParameter(value, "value");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value));
    }

    @Override
    protected void encodeTaggedEnum(@NotNull String tag, @NotNull SerialDescriptor enumDescriptor, int ordinal) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        Intrinsics.checkNotNullParameter(enumDescriptor, "enumDescriptor");
        this.putElement(tag, JsonElementKt.JsonPrimitive(enumDescriptor.getElementName(ordinal)));
    }

    @Override
    protected void encodeTaggedValue(@NotNull String tag, @NotNull Object value) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        Intrinsics.checkNotNullParameter(value, "value");
        this.putElement(tag, JsonElementKt.JsonPrimitive(value.toString()));
    }

    @Override
    @NotNull
    protected Encoder encodeTaggedInline(@NotNull String tag, @NotNull SerialDescriptor inlineDescriptor) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        Intrinsics.checkNotNullParameter(inlineDescriptor, "inlineDescriptor");
        return StreamingJsonEncoderKt.isUnsignedNumber(inlineDescriptor) ? (Encoder)new AbstractEncoder(this, tag){
            @NotNull
            private final SerializersModule serializersModule;
            final /* synthetic */ AbstractJsonTreeEncoder this$0;
            final /* synthetic */ String $tag;
            {
                this.this$0 = $receiver;
                this.$tag = $tag;
                this.serializersModule = $receiver.getJson().getSerializersModule();
            }

            @NotNull
            public SerializersModule getSerializersModule() {
                return this.serializersModule;
            }

            public final void putUnquotedString(@NotNull String s2) {
                Intrinsics.checkNotNullParameter(s2, "s");
                this.this$0.putElement(this.$tag, new JsonLiteral(s2, false));
            }

            public void encodeInt(int value) {
                this.putUnquotedString(UInt.toString-impl(UInt.constructor-impl(value)));
            }

            public void encodeLong(long value) {
                this.putUnquotedString(ULong.toString-impl(ULong.constructor-impl(value)));
            }

            public void encodeByte(byte value) {
                this.putUnquotedString(UByte.toString-impl(UByte.constructor-impl(value)));
            }

            public void encodeShort(short value) {
                this.putUnquotedString(UShort.toString-impl(UShort.constructor-impl(value)));
            }
        } : super.encodeTaggedInline(tag, inlineDescriptor);
    }

    @Override
    @NotNull
    public CompositeEncoder beginStructure(@NotNull SerialDescriptor descriptor2) {
        AbstractJsonTreeEncoder encoder2;
        AbstractJsonTreeEncoder abstractJsonTreeEncoder;
        Intrinsics.checkNotNullParameter(descriptor2, "descriptor");
        Function1 consumer2 = this.getCurrentTagOrNull() == null ? this.nodeConsumer : (Function1)new Function1<JsonElement, Unit>(this){
            final /* synthetic */ AbstractJsonTreeEncoder this$0;
            {
                this.this$0 = $receiver;
                super(1);
            }

            public final void invoke(@NotNull JsonElement node) {
                Intrinsics.checkNotNullParameter(node, "node");
                this.this$0.putElement(AbstractJsonTreeEncoder.access$getCurrentTag(this.this$0), node);
            }
        };
        SerialKind serialKind = descriptor2.getKind();
        if (Intrinsics.areEqual(serialKind, StructureKind.LIST.INSTANCE) ? true : serialKind instanceof PolymorphicKind) {
            abstractJsonTreeEncoder = new JsonTreeListEncoder(this.json, consumer2);
        } else if (Intrinsics.areEqual(serialKind, StructureKind.MAP.INSTANCE)) {
            AbstractJsonTreeEncoder abstractJsonTreeEncoder2;
            Json $this$selectMapMode$iv = this.json;
            boolean $i$f$selectMapMode = false;
            SerialDescriptor keyDescriptor$iv = WriteModeKt.carrierDescriptor(descriptor2.getElementDescriptor(0), $this$selectMapMode$iv.getSerializersModule());
            SerialKind keyKind$iv = keyDescriptor$iv.getKind();
            if (keyKind$iv instanceof PrimitiveKind || Intrinsics.areEqual(keyKind$iv, SerialKind.ENUM.INSTANCE)) {
                boolean bl = false;
                abstractJsonTreeEncoder2 = new JsonTreeMapEncoder(this.json, consumer2);
            } else if ($this$selectMapMode$iv.getConfiguration().getAllowStructuredMapKeys()) {
                boolean bl = false;
                abstractJsonTreeEncoder2 = new JsonTreeListEncoder(this.json, consumer2);
            } else {
                throw JsonExceptionsKt.InvalidKeyKindException(keyDescriptor$iv);
            }
            abstractJsonTreeEncoder = abstractJsonTreeEncoder2;
        } else {
            abstractJsonTreeEncoder = encoder2 = (AbstractJsonTreeEncoder)new JsonTreeEncoder(this.json, consumer2);
        }
        if (this.polymorphicDiscriminator != null) {
            String string = this.polymorphicDiscriminator;
            Intrinsics.checkNotNull(string);
            encoder2.putElement(string, JsonElementKt.JsonPrimitive(descriptor2.getSerialName()));
            this.polymorphicDiscriminator = null;
        }
        return encoder2;
    }

    @Override
    protected void endEncode(@NotNull SerialDescriptor descriptor2) {
        Intrinsics.checkNotNullParameter(descriptor2, "descriptor");
        this.nodeConsumer.invoke(this.getCurrent());
    }

    public /* synthetic */ AbstractJsonTreeEncoder(Json json2, Function1 nodeConsumer, DefaultConstructorMarker $constructor_marker) {
        this(json2, nodeConsumer);
    }

    public static final /* synthetic */ String access$getCurrentTag(AbstractJsonTreeEncoder $this) {
        return (String)$this.getCurrentTag();
    }
}

