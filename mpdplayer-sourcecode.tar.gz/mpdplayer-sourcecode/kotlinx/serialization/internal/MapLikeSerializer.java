/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.serialization.internal;

import java.util.Iterator;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntProgression;
import kotlin.ranges.RangesKt;
import kotlinx.serialization.InternalSerializationApi;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.SerializationStrategy;
import kotlinx.serialization.descriptors.PrimitiveKind;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.CompositeDecoder;
import kotlinx.serialization.encoding.CompositeEncoder;
import kotlinx.serialization.encoding.Encoder;
import kotlinx.serialization.internal.AbstractCollectionSerializer;
import org.jetbrains.annotations.NotNull;

@InternalSerializationApi
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0010&\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u0002*\u0004\b\u0002\u0010\u0003*\u0014\b\u0003\u0010\u0004*\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u00052 \u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00020\u0007\u0012\u0004\u0012\u0002H\u0003\u0012\u0004\u0012\u0002H\u00040\u0006B#\b\u0004\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\t\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00010\t\u00a2\u0006\u0002\u0010\u000bJ-\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00028\u00032\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0019H\u0004\u00a2\u0006\u0002\u0010\u001bJ-\u0010\u001c\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\u00192\u0006\u0010\u0017\u001a\u00028\u00032\u0006\u0010\u001e\u001a\u00020\u001fH\u0004\u00a2\u0006\u0002\u0010 J\u001d\u0010!\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00028\u0002H\u0016\u00a2\u0006\u0002\u0010%J)\u0010&\u001a\u00020\u0014*\u00028\u00032\u0006\u0010\u001d\u001a\u00020\u00192\u0006\u0010'\u001a\u00028\u00002\u0006\u0010$\u001a\u00028\u0001H$\u00a2\u0006\u0002\u0010(R\u0012\u0010\f\u001a\u00020\rX\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00010\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011\u0082\u0001\u0002)*\u00a8\u0006+"}, d2={"Lkotlinx/serialization/internal/MapLikeSerializer;", "Key", "Value", "Collection", "Builder", "", "Lkotlinx/serialization/internal/AbstractCollectionSerializer;", "", "keySerializer", "Lkotlinx/serialization/KSerializer;", "valueSerializer", "(Lkotlinx/serialization/KSerializer;Lkotlinx/serialization/KSerializer;)V", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "getKeySerializer", "()Lkotlinx/serialization/KSerializer;", "getValueSerializer", "readAll", "", "decoder", "Lkotlinx/serialization/encoding/CompositeDecoder;", "builder", "startIndex", "", "size", "(Lkotlinx/serialization/encoding/CompositeDecoder;Ljava/util/Map;II)V", "readElement", "index", "checkIndex", "", "(Lkotlinx/serialization/encoding/CompositeDecoder;ILjava/util/Map;Z)V", "serialize", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "(Lkotlinx/serialization/encoding/Encoder;Ljava/lang/Object;)V", "insertKeyValuePair", "key", "(Ljava/util/Map;ILjava/lang/Object;Ljava/lang/Object;)V", "Lkotlinx/serialization/internal/LinkedHashMapSerializer;", "Lkotlinx/serialization/internal/HashMapSerializer;", "kotlinx-serialization-core"})
public abstract class MapLikeSerializer<Key, Value, Collection, Builder extends Map<Key, Value>>
extends AbstractCollectionSerializer<Map.Entry<? extends Key, ? extends Value>, Collection, Builder> {
    @NotNull
    private final KSerializer<Key> keySerializer;
    @NotNull
    private final KSerializer<Value> valueSerializer;

    private MapLikeSerializer(KSerializer<Key> keySerializer, KSerializer<Value> valueSerializer) {
        super(null);
        this.keySerializer = keySerializer;
        this.valueSerializer = valueSerializer;
    }

    @NotNull
    public final KSerializer<Key> getKeySerializer() {
        return this.keySerializer;
    }

    @NotNull
    public final KSerializer<Value> getValueSerializer() {
        return this.valueSerializer;
    }

    protected abstract void insertKeyValuePair(@NotNull Builder var1, int var2, Key var3, Value var4);

    @Override
    @NotNull
    public abstract SerialDescriptor getDescriptor();

    @Override
    protected final void readAll(@NotNull CompositeDecoder decoder, @NotNull Builder builder, int startIndex, int size2) {
        Intrinsics.checkNotNullParameter(decoder, "decoder");
        Intrinsics.checkNotNullParameter(builder, "builder");
        if (!(size2 >= 0)) {
            boolean $i$a$-require-MapLikeSerializer$readAll$22 = false;
            String $i$a$-require-MapLikeSerializer$readAll$22 = "Size must be known in advance when using READ_ALL";
            throw new IllegalArgumentException($i$a$-require-MapLikeSerializer$readAll$22.toString());
        }
        IntProgression intProgression = RangesKt.step(RangesKt.until(0, size2 * 2), 2);
        int index = intProgression.getFirst();
        int n = intProgression.getLast();
        int n2 = intProgression.getStep();
        if (n2 > 0 && index <= n || n2 < 0 && n <= index) {
            while (true) {
                this.readElement(decoder, startIndex + index, builder, false);
                if (index == n) break;
                index += n2;
            }
        }
    }

    @Override
    protected final void readElement(@NotNull CompositeDecoder decoder, int index, @NotNull Builder builder, boolean checkIndex) {
        int n;
        Intrinsics.checkNotNullParameter(decoder, "decoder");
        Intrinsics.checkNotNullParameter(builder, "builder");
        Object key2 = CompositeDecoder.DefaultImpls.decodeSerializableElement$default(decoder, this.getDescriptor(), index, this.keySerializer, null, 8, null);
        if (checkIndex) {
            int n2;
            int it = n2 = decoder.decodeElementIndex(this.getDescriptor());
            boolean bl = false;
            if (!(it == index + 1)) {
                boolean bl2 = false;
                String string = "Value must follow key in a map, index for key: " + index + ", returned index for value: " + it;
                throw new IllegalArgumentException(string.toString());
            }
            n = n2;
        } else {
            n = index + 1;
        }
        int vIndex = n;
        Object value = builder.containsKey(key2) && !(this.valueSerializer.getDescriptor().getKind() instanceof PrimitiveKind) ? decoder.decodeSerializableElement(this.getDescriptor(), vIndex, this.valueSerializer, MapsKt.getValue(builder, key2)) : CompositeDecoder.DefaultImpls.decodeSerializableElement$default(decoder, this.getDescriptor(), vIndex, this.valueSerializer, null, 8, null);
        builder.put((Object)key2, (Object)value);
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void serialize(@NotNull Encoder encoder2, Collection value) {
        void $this$encodeCollection$iv;
        CompositeEncoder composite$iv;
        Intrinsics.checkNotNullParameter(encoder2, "encoder");
        int size2 = this.collectionSize(value);
        Encoder encoder3 = encoder2;
        SerialDescriptor descriptor$iv = this.getDescriptor();
        boolean $i$f$encodeCollection = false;
        CompositeEncoder $this$serialize_u24lambda_u2d4 = composite$iv = $this$encodeCollection$iv.beginCollection(descriptor$iv, size2);
        boolean bl = false;
        Iterator iterator2 = this.collectionIterator(value);
        int index = 0;
        Iterator $this$forEach$iv = iterator2;
        boolean $i$f$forEach = false;
        Iterator iterator3 = $this$forEach$iv;
        while (iterator3.hasNext()) {
            Object element$iv = iterator3.next();
            Map.Entry entry = (Map.Entry)element$iv;
            boolean bl2 = false;
            Object k = entry.getKey();
            Object v = entry.getValue();
            int n = index;
            index = n + 1;
            $this$serialize_u24lambda_u2d4.encodeSerializableElement(this.getDescriptor(), n, (SerializationStrategy)this.getKeySerializer(), k);
            n = index;
            index = n + 1;
            $this$serialize_u24lambda_u2d4.encodeSerializableElement(this.getDescriptor(), n, (SerializationStrategy)this.getValueSerializer(), v);
        }
        composite$iv.endStructure(descriptor$iv);
    }

    public /* synthetic */ MapLikeSerializer(KSerializer keySerializer, KSerializer valueSerializer, DefaultConstructorMarker $constructor_marker) {
        this(keySerializer, valueSerializer);
    }
}

