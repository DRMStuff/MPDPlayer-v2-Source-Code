/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.coroutines;

import java.util.Iterator;
import java.util.concurrent.CancellationException;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.JvmName;
import kotlin.sequences.Sequence;
import kotlinx.coroutines.CompletableJob;
import kotlinx.coroutines.CompletionHandlerBase;
import kotlinx.coroutines.DisposableHandle;
import kotlinx.coroutines.DisposeOnCompletion;
import kotlinx.coroutines.ExceptionsKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.JobCancellationException;
import kotlinx.coroutines.JobImpl;
import kotlinx.coroutines.JobKt;
import kotlinx.coroutines.JobSupport;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=5, xi=48, d1={"\u0000B\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0012\u0010\b\u001a\u00020\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u001a\u0019\u0010\u000b\u001a\u00020\u00052\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005H\u0007\u00a2\u0006\u0002\b\b\u001a\f\u0010\f\u001a\u00020\r*\u00020\u0002H\u0007\u001a\u0018\u0010\f\u001a\u00020\u0001*\u00020\u00022\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\f\u001a\u00020\r*\u00020\u00022\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\u001e\u0010\f\u001a\u00020\r*\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00132\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u001a\u0015\u0010\u0014\u001a\u00020\r*\u00020\u0005H\u0086@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0015\u001a\f\u0010\u0016\u001a\u00020\r*\u00020\u0002H\u0007\u001a\u0018\u0010\u0016\u001a\u00020\r*\u00020\u00022\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\u0016\u001a\u00020\r*\u00020\u00022\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\f\u0010\u0016\u001a\u00020\r*\u00020\u0005H\u0007\u001a\u0018\u0010\u0016\u001a\u00020\r*\u00020\u00052\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0007\u001a\u001c\u0010\u0016\u001a\u00020\r*\u00020\u00052\u0010\b\u0002\u0010\u000e\u001a\n\u0018\u00010\u0010j\u0004\u0018\u0001`\u0011\u001a\u0014\u0010\u0017\u001a\u00020\u0018*\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u0018H\u0000\u001a\n\u0010\u001a\u001a\u00020\r*\u00020\u0002\u001a\n\u0010\u001a\u001a\u00020\r*\u00020\u0005\u001a\u001b\u0010\u001b\u001a\u00020\u000f*\u0004\u0018\u00010\u000f2\u0006\u0010\u0004\u001a\u00020\u0005H\u0002\u00a2\u0006\u0002\b\u001c\"\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0000\u0010\u0003\"\u0015\u0010\u0004\u001a\u00020\u0005*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006\u001d"}, d2={"isActive", "", "Lkotlin/coroutines/CoroutineContext;", "(Lkotlin/coroutines/CoroutineContext;)Z", "job", "Lkotlinx/coroutines/Job;", "getJob", "(Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/Job;", "Job", "Lkotlinx/coroutines/CompletableJob;", "parent", "Job0", "cancel", "", "cause", "", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "message", "", "cancelAndJoin", "(Lkotlinx/coroutines/Job;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "cancelChildren", "disposeOnCompletion", "Lkotlinx/coroutines/DisposableHandle;", "handle", "ensureActive", "orCancellation", "orCancellation$JobKt__JobKt", "kotlinx-coroutines-core"}, xs="kotlinx/coroutines/JobKt")
final class JobKt__JobKt {
    @NotNull
    public static final CompletableJob Job(@Nullable Job parent) {
        return new JobImpl(parent);
    }

    public static /* synthetic */ CompletableJob Job$default(Job job2, int n, Object object) {
        if ((n & 1) != 0) {
            job2 = null;
        }
        return JobKt.Job(job2);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    @JvmName(name="Job")
    public static final /* synthetic */ Job Job(Job parent) {
        return JobKt.Job(parent);
    }

    public static /* synthetic */ Job Job$default(Job job2, int n, Object object) {
        if ((n & 1) != 0) {
            job2 = null;
        }
        return JobKt.Job(job2);
    }

    @NotNull
    public static final DisposableHandle disposeOnCompletion(@NotNull Job $this$disposeOnCompletion, @NotNull DisposableHandle handle2) {
        CompletionHandlerBase $this$asHandler$iv = new DisposeOnCompletion(handle2);
        boolean $i$f$getAsHandler = false;
        return $this$disposeOnCompletion.invokeOnCompletion($this$asHandler$iv);
    }

    @Nullable
    public static final Object cancelAndJoin(@NotNull Job $this$cancelAndJoin, @NotNull Continuation<? super Unit> $completion) {
        Job.DefaultImpls.cancel$default($this$cancelAndJoin, null, 1, null);
        Object object = $this$cancelAndJoin.join($completion);
        if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            return object;
        }
        return Unit.INSTANCE;
    }

    public static final void cancelChildren(@NotNull Job $this$cancelChildren, @Nullable CancellationException cause) {
        Sequence<Job> $this$forEach$iv = $this$cancelChildren.getChildren();
        boolean $i$f$forEach = false;
        Iterator<Job> iterator2 = $this$forEach$iv.iterator();
        while (iterator2.hasNext()) {
            Job element$iv;
            Job it = element$iv = iterator2.next();
            boolean bl = false;
            it.cancel(cause);
        }
    }

    public static /* synthetic */ void cancelChildren$default(Job job2, CancellationException cancellationException, int n, Object object) {
        if ((n & 1) != 0) {
            cancellationException = null;
        }
        JobKt.cancelChildren(job2, cancellationException);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ void cancelChildren(Job $this$cancelChildren) {
        JobKt.cancelChildren($this$cancelChildren, null);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ void cancelChildren(Job $this$cancelChildren, Throwable cause) {
        Sequence<Job> $this$forEach$iv = $this$cancelChildren.getChildren();
        boolean $i$f$forEach = false;
        Iterator<Job> iterator2 = $this$forEach$iv.iterator();
        while (iterator2.hasNext()) {
            Job element$iv;
            Job it = element$iv = iterator2.next();
            boolean bl = false;
            JobSupport jobSupport = it instanceof JobSupport ? (JobSupport)it : null;
            if (jobSupport == null) continue;
            jobSupport.cancelInternal(JobKt__JobKt.orCancellation$JobKt__JobKt(cause, $this$cancelChildren));
        }
    }

    public static /* synthetic */ void cancelChildren$default(Job job2, Throwable throwable, int n, Object object) {
        if ((n & 1) != 0) {
            throwable = null;
        }
        JobKt.cancelChildren(job2, throwable);
    }

    public static final boolean isActive(@NotNull CoroutineContext $this$isActive) {
        Job job2 = (Job)$this$isActive.get(Job.Key);
        return job2 != null ? job2.isActive() : false;
    }

    public static final void cancel(@NotNull CoroutineContext $this$cancel, @Nullable CancellationException cause) {
        block0: {
            Job job2 = (Job)$this$cancel.get(Job.Key);
            if (job2 == null) break block0;
            job2.cancel(cause);
        }
    }

    public static /* synthetic */ void cancel$default(CoroutineContext coroutineContext2, CancellationException cancellationException, int n, Object object) {
        if ((n & 1) != 0) {
            cancellationException = null;
        }
        JobKt.cancel(coroutineContext2, cancellationException);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ void cancel(CoroutineContext $this$cancel) {
        JobKt.cancel($this$cancel, null);
    }

    public static final void ensureActive(@NotNull Job $this$ensureActive) {
        if (!$this$ensureActive.isActive()) {
            throw $this$ensureActive.getCancellationException();
        }
    }

    public static final void ensureActive(@NotNull CoroutineContext $this$ensureActive) {
        block0: {
            Job job2 = (Job)$this$ensureActive.get(Job.Key);
            if (job2 == null) break block0;
            JobKt.ensureActive(job2);
        }
    }

    public static final void cancel(@NotNull Job $this$cancel, @NotNull String message2, @Nullable Throwable cause) {
        $this$cancel.cancel(ExceptionsKt.CancellationException(message2, cause));
    }

    public static /* synthetic */ void cancel$default(Job job2, String string, Throwable throwable, int n, Object object) {
        if ((n & 2) != 0) {
            throwable = null;
        }
        JobKt.cancel(job2, string, throwable);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ boolean cancel(CoroutineContext $this$cancel, Throwable cause) {
        Object e = $this$cancel.get(Job.Key);
        JobSupport jobSupport = e instanceof JobSupport ? (JobSupport)e : null;
        if (jobSupport == null) {
            return false;
        }
        JobSupport job2 = jobSupport;
        job2.cancelInternal(JobKt__JobKt.orCancellation$JobKt__JobKt(cause, job2));
        return true;
    }

    public static /* synthetic */ boolean cancel$default(CoroutineContext coroutineContext2, Throwable throwable, int n, Object object) {
        if ((n & 1) != 0) {
            throwable = null;
        }
        return JobKt.cancel(coroutineContext2, throwable);
    }

    public static final void cancelChildren(@NotNull CoroutineContext $this$cancelChildren, @Nullable CancellationException cause) {
        block1: {
            Object object = (Job)$this$cancelChildren.get(Job.Key);
            if (object == null || (object = object.getChildren()) == null) break block1;
            Object $this$forEach$iv = object;
            boolean $i$f$forEach = false;
            Iterator iterator2 = $this$forEach$iv.iterator();
            while (iterator2.hasNext()) {
                Object element$iv = iterator2.next();
                Job it = (Job)element$iv;
                boolean bl = false;
                it.cancel(cause);
            }
        }
    }

    public static /* synthetic */ void cancelChildren$default(CoroutineContext coroutineContext2, CancellationException cancellationException, int n, Object object) {
        if ((n & 1) != 0) {
            cancellationException = null;
        }
        JobKt.cancelChildren(coroutineContext2, cancellationException);
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ void cancelChildren(CoroutineContext $this$cancelChildren) {
        JobKt.cancelChildren($this$cancelChildren, null);
    }

    @NotNull
    public static final Job getJob(@NotNull CoroutineContext $this$job) {
        Job job2 = (Job)$this$job.get(Job.Key);
        if (job2 == null) {
            throw new IllegalStateException(("Current context doesn't contain Job in it: " + $this$job).toString());
        }
        return job2;
    }

    @Deprecated(message="Since 1.2.0, binary compatibility with versions <= 1.1.x", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ void cancelChildren(CoroutineContext $this$cancelChildren, Throwable cause) {
        Job job2 = (Job)$this$cancelChildren.get(Job.Key);
        if (job2 == null) {
            return;
        }
        Job job3 = job2;
        Sequence<Job> $this$forEach$iv = job3.getChildren();
        boolean $i$f$forEach = false;
        Iterator<Job> iterator2 = $this$forEach$iv.iterator();
        while (iterator2.hasNext()) {
            Job element$iv;
            Job it = element$iv = iterator2.next();
            boolean bl = false;
            JobSupport jobSupport = it instanceof JobSupport ? (JobSupport)it : null;
            if (jobSupport == null) continue;
            jobSupport.cancelInternal(JobKt__JobKt.orCancellation$JobKt__JobKt(cause, job3));
        }
    }

    public static /* synthetic */ void cancelChildren$default(CoroutineContext coroutineContext2, Throwable throwable, int n, Object object) {
        if ((n & 1) != 0) {
            throwable = null;
        }
        JobKt.cancelChildren(coroutineContext2, throwable);
    }

    private static final Throwable orCancellation$JobKt__JobKt(Throwable $this$orCancellation, Job job2) {
        Throwable throwable = $this$orCancellation;
        if (throwable == null) {
            throwable = new JobCancellationException("Job was cancelled", null, job2);
        }
        return throwable;
    }
}

