/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.coroutines.flow;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.CancellableFlow;
import kotlinx.coroutines.flow.CancellableFlowImpl;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.internal.ChannelFlowOperatorImpl;
import kotlinx.coroutines.flow.internal.FusibleFlow;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=5, xi=48, d1={"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u00a2\u0006\u0002\b\u0004\u001a(\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\b\b\u0002\u0010\b\u001a\u00020\tH\u0007\u001a0\u0010\u0005\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000b\u001a\u001c\u0010\f\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u0006\u001a\u001c\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u0006\u001a$\u0010\u000e\u001a\b\u0012\u0004\u0012\u0002H\u00070\u0006\"\u0004\b\u0000\u0010\u0007*\b\u0012\u0004\u0012\u0002H\u00070\u00062\u0006\u0010\u0002\u001a\u00020\u0003\u00a8\u0006\u000f"}, d2={"checkFlowContext", "", "context", "Lkotlin/coroutines/CoroutineContext;", "checkFlowContext$FlowKt__ContextKt", "buffer", "Lkotlinx/coroutines/flow/Flow;", "T", "capacity", "", "onBufferOverflow", "Lkotlinx/coroutines/channels/BufferOverflow;", "cancellable", "conflate", "flowOn", "kotlinx-coroutines-core"}, xs="kotlinx/coroutines/flow/FlowKt")
final class FlowKt__ContextKt {
    @NotNull
    public static final <T> Flow<T> buffer(@NotNull Flow<? extends T> $this$buffer, int capacity, @NotNull BufferOverflow onBufferOverflow) {
        if (!(capacity >= 0 || capacity == -2 || capacity == -1)) {
            boolean $i$a$-require-FlowKt__ContextKt$buffer$32 = false;
            String $i$a$-require-FlowKt__ContextKt$buffer$32 = "Buffer size should be non-negative, BUFFERED, or CONFLATED, but was " + capacity;
            throw new IllegalArgumentException($i$a$-require-FlowKt__ContextKt$buffer$32.toString());
        }
        if (!(capacity != -1 || onBufferOverflow == BufferOverflow.SUSPEND)) {
            boolean $i$a$-require-FlowKt__ContextKt$buffer$42 = false;
            String $i$a$-require-FlowKt__ContextKt$buffer$42 = "CONFLATED capacity cannot be used with non-default onBufferOverflow";
            throw new IllegalArgumentException($i$a$-require-FlowKt__ContextKt$buffer$42.toString());
        }
        int capacity2 = capacity;
        BufferOverflow onBufferOverflow2 = onBufferOverflow;
        if (capacity2 == -1) {
            capacity2 = 0;
            onBufferOverflow2 = BufferOverflow.DROP_OLDEST;
        }
        return $this$buffer instanceof FusibleFlow ? FusibleFlow.DefaultImpls.fuse$default((FusibleFlow)$this$buffer, null, capacity2, onBufferOverflow2, 1, null) : (Flow)new ChannelFlowOperatorImpl($this$buffer, null, capacity2, onBufferOverflow2, 2, null);
    }

    public static /* synthetic */ Flow buffer$default(Flow flow, int n, BufferOverflow bufferOverflow, int n2, Object object) {
        if ((n2 & 1) != 0) {
            n = -2;
        }
        if ((n2 & 2) != 0) {
            bufferOverflow = BufferOverflow.SUSPEND;
        }
        return FlowKt.buffer(flow, n, bufferOverflow);
    }

    @Deprecated(message="Since 1.4.0, binary compatibility with earlier versions", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Flow buffer(Flow $this$buffer, int capacity) {
        return FlowKt.buffer$default($this$buffer, capacity, null, 2, null);
    }

    public static /* synthetic */ Flow buffer$default(Flow flow, int n, int n2, Object object) {
        if ((n2 & 1) != 0) {
            n = -2;
        }
        return FlowKt.buffer(flow, n);
    }

    @NotNull
    public static final <T> Flow<T> conflate(@NotNull Flow<? extends T> $this$conflate) {
        return FlowKt.buffer$default($this$conflate, -1, null, 2, null);
    }

    @NotNull
    public static final <T> Flow<T> flowOn(@NotNull Flow<? extends T> $this$flowOn, @NotNull CoroutineContext context) {
        FlowKt__ContextKt.checkFlowContext$FlowKt__ContextKt(context);
        return Intrinsics.areEqual(context, EmptyCoroutineContext.INSTANCE) ? $this$flowOn : ($this$flowOn instanceof FusibleFlow ? FusibleFlow.DefaultImpls.fuse$default((FusibleFlow)$this$flowOn, context, 0, null, 6, null) : (Flow)new ChannelFlowOperatorImpl($this$flowOn, context, 0, null, 12, null));
    }

    @NotNull
    public static final <T> Flow<T> cancellable(@NotNull Flow<? extends T> $this$cancellable) {
        return $this$cancellable instanceof CancellableFlow ? $this$cancellable : (Flow)new CancellableFlowImpl<T>($this$cancellable);
    }

    private static final void checkFlowContext$FlowKt__ContextKt(CoroutineContext context) {
        if (!(context.get(Job.Key) == null)) {
            boolean bl = false;
            String string = "Flow context cannot contain job in it. Had " + context;
            throw new IllegalArgumentException(string.toString());
        }
    }
}

