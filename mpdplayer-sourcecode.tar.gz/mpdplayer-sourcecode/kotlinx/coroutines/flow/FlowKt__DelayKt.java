/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.coroutines.flow;

import kotlin.Metadata;
import kotlin.OverloadResolutionByLambdaReturnType;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Ref;
import kotlin.time.Duration;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DebugKt;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.FlowPreview;
import kotlinx.coroutines.channels.ChannelResult;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.FlowKt__DelayKt;
import kotlinx.coroutines.flow.internal.ChildCancelledException;
import kotlinx.coroutines.flow.internal.FlowCoroutineKt;
import kotlinx.coroutines.flow.internal.NullSurrogateKt;
import kotlinx.coroutines.internal.Symbol;
import kotlinx.coroutines.selects.SelectBuilderImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Metadata(mv={1, 6, 0}, k=5, xi=48, d1={"\u0000,\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u001a2\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00050\u0004H\u0007\u001a:\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00070\u0004H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\b\b\u001a&\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0005H\u0007\u001a3\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0007H\u0007\u00f8\u0001\u0000\u00f8\u0001\u0001\u00a2\u0006\u0004\b\t\u0010\n\u001a7\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00050\u0004H\u0002\u00a2\u0006\u0002\b\r\u001a$\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00052\b\b\u0002\u0010\u0013\u001a\u00020\u0005H\u0000\u001a&\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u0005H\u0007\u001a3\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u0007H\u0007\u00f8\u0001\u0000\u00f8\u0001\u0001\u00a2\u0006\u0004\b\u0017\u0010\n\u0082\u0002\u000b\n\u0002\b\u0019\n\u0005\b\u00a1\u001e0\u0001\u00a8\u0006\u0018"}, d2={"debounce", "Lkotlinx/coroutines/flow/Flow;", "T", "timeoutMillis", "Lkotlin/Function1;", "", "timeout", "Lkotlin/time/Duration;", "debounceDuration", "debounce-HG0u8IE", "(Lkotlinx/coroutines/flow/Flow;J)Lkotlinx/coroutines/flow/Flow;", "debounceInternal", "timeoutMillisSelector", "debounceInternal$FlowKt__DelayKt", "fixedPeriodTicker", "Lkotlinx/coroutines/channels/ReceiveChannel;", "", "Lkotlinx/coroutines/CoroutineScope;", "delayMillis", "initialDelayMillis", "sample", "periodMillis", "period", "sample-HG0u8IE", "kotlinx-coroutines-core"}, xs="kotlinx/coroutines/flow/FlowKt")
final class FlowKt__DelayKt {
    @FlowPreview
    @NotNull
    public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> $this$debounce, long timeoutMillis) {
        if (!(timeoutMillis >= 0L)) {
            boolean bl = false;
            String string = "Debounce timeout should not be negative";
            throw new IllegalArgumentException(string.toString());
        }
        if (timeoutMillis == 0L) {
            return $this$debounce;
        }
        return FlowKt__DelayKt.debounceInternal$FlowKt__DelayKt($this$debounce, new Function1<T, Long>(timeoutMillis){
            final /* synthetic */ long $timeoutMillis;
            {
                this.$timeoutMillis = $timeoutMillis;
                super(1);
            }

            @NotNull
            public final Long invoke(T it) {
                return this.$timeoutMillis;
            }
        });
    }

    @FlowPreview
    @OverloadResolutionByLambdaReturnType
    @NotNull
    public static final <T> Flow<T> debounce(@NotNull Flow<? extends T> $this$debounce, @NotNull Function1<? super T, Long> timeoutMillis) {
        return FlowKt__DelayKt.debounceInternal$FlowKt__DelayKt($this$debounce, timeoutMillis);
    }

    @FlowPreview
    @NotNull
    public static final <T> Flow<T> debounce-HG0u8IE(@NotNull Flow<? extends T> $this$debounce_u2dHG0u8IE, long timeout2) {
        return FlowKt.debounce($this$debounce_u2dHG0u8IE, DelayKt.toDelayMillis-LRDsOJo(timeout2));
    }

    @FlowPreview
    @JvmName(name="debounceDuration")
    @OverloadResolutionByLambdaReturnType
    @NotNull
    public static final <T> Flow<T> debounceDuration(@NotNull Flow<? extends T> $this$debounce, @NotNull Function1<? super T, Duration> timeout2) {
        return FlowKt__DelayKt.debounceInternal$FlowKt__DelayKt($this$debounce, new Function1<T, Long>(timeout2){
            final /* synthetic */ Function1<T, Duration> $timeout;
            {
                this.$timeout = $timeout;
                super(1);
            }

            @NotNull
            public final Long invoke(T emittedItem) {
                return DelayKt.toDelayMillis-LRDsOJo(this.$timeout.invoke(emittedItem).unbox-impl());
            }
        });
    }

    private static final <T> Flow<T> debounceInternal$FlowKt__DelayKt(Flow<? extends T> $this$debounceInternal, Function1<? super T, Long> timeoutMillisSelector) {
        return FlowCoroutineKt.scopedFlow(new Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object>(timeoutMillisSelector, $this$debounceInternal, null){
            Object L$2;
            Object L$3;
            int label;
            private /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;
            final /* synthetic */ Function1<T, Long> $timeoutMillisSelector;
            final /* synthetic */ Flow<T> $this_debounceInternal;
            {
                this.$timeoutMillisSelector = $timeoutMillisSelector;
                this.$this_debounceInternal = $receiver;
                super(3, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var14_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$scopedFlow = (CoroutineScope)this.L$0;
                        downstream = (FlowCollector)this.L$1;
                        values = ProduceKt.produce$default($this$scopedFlow, null, 0, new Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object>(this.$this_debounceInternal, null){
                            int label;
                            private /* synthetic */ Object L$0;
                            final /* synthetic */ Flow<T> $this_debounceInternal;
                            {
                                this.$this_debounceInternal = $receiver;
                                super(2, $completion);
                            }

                            /*
                             * WARNING - void declaration
                             * Enabled force condition propagation
                             * Lifted jumps to return sites
                             */
                            @Nullable
                            public final Object invokeSuspend(@NotNull Object object) {
                                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0: {
                                        ResultKt.throwOnFailure(object);
                                        ProducerScope $this$produce = (ProducerScope)this.L$0;
                                        this.label = 1;
                                        Object object3 = this.$this_debounceInternal.collect(new FlowCollector($this$produce){
                                            final /* synthetic */ ProducerScope<Object> $$this$produce;
                                            {
                                                this.$$this$produce = $$this$produce;
                                            }

                                            /*
                                             * Unable to fully structure code
                                             * Enabled aggressive block sorting
                                             * Lifted jumps to return sites
                                             */
                                            @Nullable
                                            public final Object emit(T var1_1, @NotNull Continuation<? super Unit> var2_2) {
                                                if (!(var2_2 instanceof debounceInternal.values.emit.1)) ** GOTO lbl-1000
                                                var4_3 = var2_2;
                                                if ((var4_3.label & -2147483648) != 0) {
                                                    var4_3.label -= -2147483648;
                                                } else lbl-1000:
                                                // 2 sources

                                                {
                                                    $continuation = new ContinuationImpl(this, var2_2){
                                                        /* synthetic */ Object result;
                                                        final /* synthetic */ debounceInternal.values.1<T> this$0;
                                                        int label;
                                                        {
                                                            this.this$0 = this$0;
                                                            super($completion);
                                                        }

                                                        @Nullable
                                                        public final Object invokeSuspend(@NotNull Object $result) {
                                                            this.result = $result;
                                                            this.label |= Integer.MIN_VALUE;
                                                            return this.this$0.emit(null, this);
                                                        }
                                                    };
                                                }
                                                $result = $continuation.result;
                                                var5_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                                switch ($continuation.label) {
                                                    case 0: {
                                                        ResultKt.throwOnFailure($result);
                                                        v0 = value;
                                                        if (v0 == null) {
                                                            v0 = NullSurrogateKt.NULL;
                                                        }
                                                        $continuation.label = 1;
                                                        v1 = this.$$this$produce.send(v0, $continuation);
                                                        v2 = v1;
                                                        if (v1 != var5_5) return Unit.INSTANCE;
                                                        return var5_5;
                                                    }
                                                    case 1: {
                                                        ResultKt.throwOnFailure($result);
                                                        v2 = $result;
                                                        return Unit.INSTANCE;
                                                    }
                                                }
                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                            }
                                        }, this);
                                        if (object3 != object2) return Unit.INSTANCE;
                                        return object2;
                                    }
                                    case 1: {
                                        void $result;
                                        ResultKt.throwOnFailure($result);
                                        Object object3 = $result;
                                        return Unit.INSTANCE;
                                    }
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }

                            @NotNull
                            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                                Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                                function2.L$0 = value;
                                return (Continuation)((Object)function2);
                            }

                            @Nullable
                            public final Object invoke(@NotNull ProducerScope<Object> p1, @Nullable Continuation<? super Unit> p2) {
                                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                            }
                        }, 3, null);
                        lastValue = new Ref.ObjectRef<Object>();
                        ** GOTO lbl62
                    }
                    case 1: {
                        timeoutMillis = (Ref.LongRef)this.L$3;
                        lastValue = (Ref.ObjectRef<Object>)this.L$2;
                        values = (ReceiveChannel)this.L$1;
                        downstream = (FlowCollector)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            lastValue.element = null;
lbl19:
                            // 3 sources

                            while (true) {
                                if (DebugKt.getASSERTIONS_ENABLED()) {
                                    $i$a$-assert-FlowKt__DelayKt$debounceInternal$1$2 = false;
                                    if (!(lastValue.element == null || timeoutMillis.element > 0L)) {
                                        throw new AssertionError();
                                    }
                                }
                                $i$f$select = false;
                                this.L$0 = downstream;
                                this.L$1 = values;
                                this.L$2 = lastValue;
                                this.L$3 = timeoutMillis;
                                this.label = 2;
                                uCont$iv = this;
                                $i$a$-suspendCoroutineUninterceptedOrReturn-SelectKt$select$3$iv = false;
                                scope$iv = new SelectBuilderImpl<R>(uCont$iv);
                                try {
                                    $this$invokeSuspend_u24lambda_u2d2 = scope$iv;
                                    $i$a$-select-FlowKt__DelayKt$debounceInternal$1$3 = false;
                                    if (lastValue.element != null) {
                                        $this$invokeSuspend_u24lambda_u2d2.onTimeout(timeoutMillis.element, (Function1)new Function1<Continuation<? super Unit>, Object>(downstream, lastValue, null){
                                            int label;
                                            final /* synthetic */ FlowCollector<T> $downstream;
                                            final /* synthetic */ Ref.ObjectRef<Object> $lastValue;
                                            {
                                                this.$downstream = $downstream;
                                                this.$lastValue = $lastValue;
                                                super(1, $completion);
                                            }

                                            /*
                                             * Unable to fully structure code
                                             * Enabled aggressive block sorting
                                             * Lifted jumps to return sites
                                             */
                                            @Nullable
                                            public final Object invokeSuspend(@NotNull Object var1_1) {
                                                var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                                switch (this.label) {
                                                    case 0: {
                                                        ResultKt.throwOnFailure(var1_1);
                                                        var2_3 = NullSurrogateKt.NULL;
                                                        value$iv = this.$lastValue.element;
                                                        $i$f$unbox = false;
                                                        this.label = 1;
                                                        v0 = this.$downstream.emit(value$iv == this_$iv ? null : var3_4, this);
                                                        if (v0 == var5_2) {
                                                            return var5_2;
                                                        }
                                                        ** GOTO lbl16
                                                    }
                                                    case 1: {
                                                        ResultKt.throwOnFailure($result);
                                                        v0 = $result;
lbl16:
                                                        // 2 sources

                                                        this.$lastValue.element = null;
                                                        return Unit.INSTANCE;
                                                    }
                                                }
                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                            }

                                            @NotNull
                                            public final Continuation<Unit> create(@NotNull Continuation<?> $completion) {
                                                return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
                                            }

                                            @Nullable
                                            public final Object invoke(@Nullable Continuation<? super Unit> p1) {
                                                return (this.create(p1)).invokeSuspend(Unit.INSTANCE);
                                            }
                                        });
                                    }
                                    $this$invokeSuspend_u24lambda_u2d2.invoke(values.getOnReceiveCatching(), (Function2)new Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object>(lastValue, downstream, null){
                                        Object L$1;
                                        int label;
                                        /* synthetic */ Object L$0;
                                        final /* synthetic */ Ref.ObjectRef<Object> $lastValue;
                                        final /* synthetic */ FlowCollector<T> $downstream;
                                        {
                                            this.$lastValue = $lastValue;
                                            this.$downstream = $downstream;
                                            super(2, $completion);
                                        }

                                        /*
                                         * Unable to fully structure code
                                         * Enabled aggressive block sorting
                                         * Lifted jumps to return sites
                                         */
                                        @Nullable
                                        public final Object invokeSuspend(@NotNull Object var1_1) {
                                            var12_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                            switch (this.label) {
                                                case 0: {
                                                    ResultKt.throwOnFailure(var1_1);
                                                    $this$onSuccess_u2dWpGqRn0$iv = value = ((ChannelResult)this.L$0).unbox-impl();
                                                    var4_6 = this.$lastValue;
                                                    $i$f$onSuccess-WpGqRn0 = false;
                                                    if (!($this$onSuccess_u2dWpGqRn0$iv instanceof ChannelResult.Failed)) {
                                                        it = $this$onSuccess_u2dWpGqRn0$iv;
                                                        $i$a$-onSuccess-WpGqRn0-FlowKt__DelayKt$debounceInternal$1$3$2$1 = false;
                                                        var4_6.element = it;
                                                    }
                                                    var4_6 = this.$lastValue;
                                                    var5_8 = this.$downstream;
                                                    $i$f$onFailure-WpGqRn0 = false;
                                                    if ($this$onFailure_u2dWpGqRn0$iv instanceof ChannelResult.Failed == false) return Unit.INSTANCE;
                                                    it = ChannelResult.exceptionOrNull-impl($this$onFailure_u2dWpGqRn0$iv);
                                                    $i$a$-onFailure-WpGqRn0-FlowKt__DelayKt$debounceInternal$1$3$2$2 = false;
                                                    v0 = it;
                                                    if (v0 != null) {
                                                        it = v0;
                                                        $i$a$-let-FlowKt__DelayKt$debounceInternal$1$3$2$2$1 = false;
                                                        throw it;
                                                    }
                                                    if (var4_6.element != null) {
                                                        var9_20 = NullSurrogateKt.NULL;
                                                        value$iv = var4_6.element;
                                                        $i$f$unbox = false;
                                                        this.L$0 = $this$onFailure_u2dWpGqRn0$iv;
                                                        this.L$1 = var4_6;
                                                        this.label = 1;
                                                        v1 = var5_8.emit(value$iv == this_$iv ? null : (T)value$iv, this);
                                                        if (v1 == var12_2) {
                                                            return var12_2;
                                                        }
                                                    }
                                                    ** GOTO lbl43
                                                }
                                                case 1: {
                                                    $i$f$onFailure-WpGqRn0 = false;
                                                    $i$a$-onFailure-WpGqRn0-FlowKt__DelayKt$debounceInternal$1$3$2$2 = false;
                                                    var4_6 = (Ref.ObjectRef<Object>)this.L$1;
                                                    $this$onFailure_u2dWpGqRn0$iv = this.L$0;
                                                    ResultKt.throwOnFailure($result);
                                                    v1 = $result;
lbl43:
                                                    // 2 sources

                                                    var4_6.element = NullSurrogateKt.DONE;
                                                    return Unit.INSTANCE;
                                                }
                                            }
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                        }

                                        @NotNull
                                        public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                                            Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                                            function2.L$0 = value;
                                            return (Continuation)((Object)function2);
                                        }

                                        @Nullable
                                        public final Object invoke-WpGqRn0(@NotNull Object p1, @Nullable Continuation<? super Unit> p2) {
                                            return (this.create(ChannelResult.box-impl(p1), p2)).invokeSuspend(Unit.INSTANCE);
                                        }
                                    });
                                }
                                catch (Throwable e$iv) {
                                    scope$iv.handleBuilderException(e$iv);
                                }
                                v1 = scope$iv.getResult();
                                if (v1 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                                    DebugProbesKt.probeCoroutineSuspended(this);
                                }
                                v2 = v1;
                                if (v1 == var14_2) {
                                    return var14_2;
                                }
                                ** GOTO lbl62
                                break;
                            }
                            break;
                        }
                    }
                    case 2: {
                        $i$f$select = false;
                        (Ref.LongRef)this.L$3;
                        lastValue = (Ref.ObjectRef)this.L$2;
                        values = (ReceiveChannel)this.L$1;
                        downstream = (FlowCollector)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl62:
                        // 3 sources

                        if (lastValue.element == NullSurrogateKt.DONE) return Unit.INSTANCE;
                        timeoutMillis = new Ref.LongRef();
                        if (lastValue.element == null) ** GOTO lbl19
                        var7_9 = NullSurrogateKt.NULL;
                        value$iv = lastValue.element;
                        $i$f$unbox = false;
                        timeoutMillis.element = ((Number)this.$timeoutMillisSelector.invoke(value$iv == this_$iv ? null : (P1)value$iv)).longValue();
                        if (!(timeoutMillis.element >= 0L)) {
                            $i$a$-require-FlowKt__DelayKt$debounceInternal$1$1 = false;
                            $i$a$-require-FlowKt__DelayKt$debounceInternal$1$1 = "Debounce timeout should not be negative";
                            throw new IllegalArgumentException($i$a$-require-FlowKt__DelayKt$debounceInternal$1$1.toString());
                        }
                        if (timeoutMillis.element != 0L) ** continue;
                        this_$iv = NullSurrogateKt.NULL;
                        value$iv = lastValue.element;
                        $i$f$unbox = false;
                        this.L$0 = downstream;
                        this.L$1 = values;
                        this.L$2 = lastValue;
                        this.L$3 = timeoutMillis;
                        this.label = 1;
                        if ((v0 = downstream.emit(value$iv == this_$iv ? null : (T)value$iv, this)) != var14_2) ** continue;
                        return var14_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @NotNull FlowCollector<? super T> p2, @Nullable Continuation<? super Unit> p3) {
                Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object> function3 = new /* invalid duplicate definition of identical inner class */;
                function3.L$0 = p1;
                function3.L$1 = p2;
                return function3.invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    @FlowPreview
    @NotNull
    public static final <T> Flow<T> sample(@NotNull Flow<? extends T> $this$sample, long periodMillis) {
        if (!(periodMillis > 0L)) {
            boolean bl = false;
            String string = "Sample period should be positive";
            throw new IllegalArgumentException(string.toString());
        }
        return FlowCoroutineKt.scopedFlow(new Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object>(periodMillis, $this$sample, null){
            Object L$2;
            Object L$3;
            int label;
            private /* synthetic */ Object L$0;
            /* synthetic */ Object L$1;
            final /* synthetic */ long $periodMillis;
            final /* synthetic */ Flow<T> $this_sample;
            {
                this.$periodMillis = $periodMillis;
                this.$this_sample = $receiver;
                super(3, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var14_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$scopedFlow = (CoroutineScope)this.L$0;
                        downstream = (FlowCollector)this.L$1;
                        values = ProduceKt.produce$default($this$scopedFlow, null, -1, new Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object>(this.$this_sample, null){
                            int label;
                            private /* synthetic */ Object L$0;
                            final /* synthetic */ Flow<T> $this_sample;
                            {
                                this.$this_sample = $receiver;
                                super(2, $completion);
                            }

                            /*
                             * WARNING - void declaration
                             * Enabled force condition propagation
                             * Lifted jumps to return sites
                             */
                            @Nullable
                            public final Object invokeSuspend(@NotNull Object object) {
                                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0: {
                                        ResultKt.throwOnFailure(object);
                                        ProducerScope $this$produce = (ProducerScope)this.L$0;
                                        this.label = 1;
                                        Object object3 = this.$this_sample.collect(new FlowCollector($this$produce){
                                            final /* synthetic */ ProducerScope<Object> $$this$produce;
                                            {
                                                this.$$this$produce = $$this$produce;
                                            }

                                            /*
                                             * Unable to fully structure code
                                             * Enabled aggressive block sorting
                                             * Lifted jumps to return sites
                                             */
                                            @Nullable
                                            public final Object emit(T var1_1, @NotNull Continuation<? super Unit> var2_2) {
                                                if (!(var2_2 instanceof sample.values.emit.1)) ** GOTO lbl-1000
                                                var4_3 = var2_2;
                                                if ((var4_3.label & -2147483648) != 0) {
                                                    var4_3.label -= -2147483648;
                                                } else lbl-1000:
                                                // 2 sources

                                                {
                                                    $continuation = new ContinuationImpl(this, var2_2){
                                                        /* synthetic */ Object result;
                                                        final /* synthetic */ sample.values.1<T> this$0;
                                                        int label;
                                                        {
                                                            this.this$0 = this$0;
                                                            super($completion);
                                                        }

                                                        @Nullable
                                                        public final Object invokeSuspend(@NotNull Object $result) {
                                                            this.result = $result;
                                                            this.label |= Integer.MIN_VALUE;
                                                            return this.this$0.emit(null, this);
                                                        }
                                                    };
                                                }
                                                $result = $continuation.result;
                                                var5_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                                switch ($continuation.label) {
                                                    case 0: {
                                                        ResultKt.throwOnFailure($result);
                                                        v0 = value;
                                                        if (v0 == null) {
                                                            v0 = NullSurrogateKt.NULL;
                                                        }
                                                        $continuation.label = 1;
                                                        v1 = this.$$this$produce.send(v0, $continuation);
                                                        v2 = v1;
                                                        if (v1 != var5_5) return Unit.INSTANCE;
                                                        return var5_5;
                                                    }
                                                    case 1: {
                                                        ResultKt.throwOnFailure($result);
                                                        v2 = $result;
                                                        return Unit.INSTANCE;
                                                    }
                                                }
                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                            }
                                        }, this);
                                        if (object3 != object2) return Unit.INSTANCE;
                                        return object2;
                                    }
                                    case 1: {
                                        void $result;
                                        ResultKt.throwOnFailure($result);
                                        Object object3 = $result;
                                        return Unit.INSTANCE;
                                    }
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }

                            @NotNull
                            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                                Function2<ProducerScope<? super Object>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                                function2.L$0 = value;
                                return (Continuation)((Object)function2);
                            }

                            @Nullable
                            public final Object invoke(@NotNull ProducerScope<Object> p1, @Nullable Continuation<? super Unit> p2) {
                                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                            }
                        }, 1, null);
                        lastValue = new Ref.ObjectRef<Object>();
                        ticker = FlowKt.fixedPeriodTicker$default($this$scopedFlow, this.$periodMillis, 0L, 2, null);
                        ** GOTO lbl20
                    }
                    case 1: {
                        $i$f$select = false;
                        ticker = (ReceiveChannel)this.L$3;
                        lastValue = (Ref.ObjectRef<Object>)this.L$2;
                        values = (ReceiveChannel)this.L$1;
                        downstream = (FlowCollector)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
lbl20:
                        // 2 sources

                        do {
                            if (lastValue.element == NullSurrogateKt.DONE) return Unit.INSTANCE;
                            $i$f$select = false;
                            this.L$0 = downstream;
                            this.L$1 = values;
                            this.L$2 = lastValue;
                            this.L$3 = ticker;
                            this.label = 1;
                            uCont$iv = this;
                            $i$a$-suspendCoroutineUninterceptedOrReturn-SelectKt$select$3$iv = false;
                            scope$iv = new SelectBuilderImpl<R>(uCont$iv);
                            try {
                                $this$invokeSuspend_u24lambda_u2d0 = scope$iv;
                                $i$a$-select-FlowKt__DelayKt$sample$2$1 = false;
                                $this$invokeSuspend_u24lambda_u2d0.invoke(values.getOnReceiveCatching(), (Function2)new Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object>(lastValue, (ReceiveChannel<Unit>)ticker, null){
                                    int label;
                                    /* synthetic */ Object L$0;
                                    final /* synthetic */ Ref.ObjectRef<Object> $lastValue;
                                    final /* synthetic */ ReceiveChannel<Unit> $ticker;
                                    {
                                        this.$lastValue = $lastValue;
                                        this.$ticker = $ticker;
                                        super(2, $completion);
                                    }

                                    /*
                                     * WARNING - void declaration
                                     */
                                    @Nullable
                                    public final Object invokeSuspend(@NotNull Object object) {
                                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                        switch (this.label) {
                                            case 0: {
                                                void $this$onFailure_u2dWpGqRn0$iv;
                                                Object result2;
                                                ResultKt.throwOnFailure(object);
                                                Object $this$onSuccess_u2dWpGqRn0$iv = result2 = ((ChannelResult)this.L$0).unbox-impl();
                                                Object object2 = this.$lastValue;
                                                boolean bl = false;
                                                if (!($this$onSuccess_u2dWpGqRn0$iv instanceof ChannelResult.Failed)) {
                                                    Object it = $this$onSuccess_u2dWpGqRn0$iv;
                                                    boolean bl2 = false;
                                                    ((Ref.ObjectRef)object2).element = it;
                                                }
                                                object2 = this.$ticker;
                                                Ref.ObjectRef<Object> objectRef = this.$lastValue;
                                                boolean bl3 = false;
                                                if ($this$onFailure_u2dWpGqRn0$iv instanceof ChannelResult.Failed) {
                                                    Throwable it = ChannelResult.exceptionOrNull-impl($this$onFailure_u2dWpGqRn0$iv);
                                                    boolean bl4 = false;
                                                    Throwable throwable = it;
                                                    if (throwable != null) {
                                                        Throwable it2 = throwable;
                                                        boolean bl5 = false;
                                                        throw it2;
                                                    }
                                                    object2.cancel(new ChildCancelledException());
                                                    objectRef.element = NullSurrogateKt.DONE;
                                                }
                                                return Unit.INSTANCE;
                                            }
                                        }
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }

                                    @NotNull
                                    public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                                        Function2<ChannelResult<? extends Object>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                                        function2.L$0 = value;
                                        return (Continuation)((Object)function2);
                                    }

                                    @Nullable
                                    public final Object invoke-WpGqRn0(@NotNull Object p1, @Nullable Continuation<? super Unit> p2) {
                                        return (this.create(ChannelResult.box-impl(p1), p2)).invokeSuspend(Unit.INSTANCE);
                                    }
                                });
                                $this$invokeSuspend_u24lambda_u2d0.invoke(ticker.getOnReceive(), (Function2)new Function2<Unit, Continuation<? super Unit>, Object>(lastValue, downstream, null){
                                    int label;
                                    final /* synthetic */ Ref.ObjectRef<Object> $lastValue;
                                    final /* synthetic */ FlowCollector<T> $downstream;
                                    {
                                        this.$lastValue = $lastValue;
                                        this.$downstream = $downstream;
                                        super(2, $completion);
                                    }

                                    /*
                                     * WARNING - void declaration
                                     * Enabled force condition propagation
                                     * Lifted jumps to return sites
                                     */
                                    @Nullable
                                    public final Object invokeSuspend(@NotNull Object object) {
                                        Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                        switch (this.label) {
                                            case 0: {
                                                void var2_3;
                                                ResultKt.throwOnFailure(object);
                                                T t = this.$lastValue.element;
                                                if (t == null) {
                                                    return Unit.INSTANCE;
                                                }
                                                T value = t;
                                                this.$lastValue.element = null;
                                                Symbol this_$iv = NullSurrogateKt.NULL;
                                                boolean $i$f$unbox = false;
                                                this.label = 1;
                                                Object object3 = this.$downstream.emit(value == this_$iv ? null : var2_3, this);
                                                if (object3 != object2) return Unit.INSTANCE;
                                                return object2;
                                            }
                                            case 1: {
                                                void $result;
                                                ResultKt.throwOnFailure($result);
                                                Object object3 = $result;
                                                return Unit.INSTANCE;
                                            }
                                        }
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }

                                    @NotNull
                                    public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                                        return (Continuation)((Object)new /* invalid duplicate definition of identical inner class */);
                                    }

                                    @Nullable
                                    public final Object invoke(@NotNull Unit p1, @Nullable Continuation<? super Unit> p2) {
                                        return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                                    }
                                });
                            }
                            catch (Throwable e$iv) {
                                scope$iv.handleBuilderException(e$iv);
                            }
                            v1 = scope$iv.getResult();
                            if (v1 == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                                DebugProbesKt.probeCoroutineSuspended(this);
                            }
                            v0 = v1;
                        } while (v1 != var14_2);
                        return var14_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @Nullable
            public final Object invoke(@NotNull CoroutineScope p1, @NotNull FlowCollector<? super T> p2, @Nullable Continuation<? super Unit> p3) {
                Function3<CoroutineScope, FlowCollector<? super T>, Continuation<? super Unit>, Object> function3 = new /* invalid duplicate definition of identical inner class */;
                function3.L$0 = p1;
                function3.L$1 = p2;
                return function3.invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    @NotNull
    public static final ReceiveChannel<Unit> fixedPeriodTicker(@NotNull CoroutineScope $this$fixedPeriodTicker, long delayMillis2, long initialDelayMillis) {
        if (!(delayMillis2 >= 0L)) {
            boolean $i$a$-require-FlowKt__DelayKt$fixedPeriodTicker$32 = false;
            String $i$a$-require-FlowKt__DelayKt$fixedPeriodTicker$32 = "Expected non-negative delay, but has " + delayMillis2 + " ms";
            throw new IllegalArgumentException($i$a$-require-FlowKt__DelayKt$fixedPeriodTicker$32.toString());
        }
        if (!(initialDelayMillis >= 0L)) {
            boolean bl = false;
            String string = "Expected non-negative initial delay, but has " + initialDelayMillis + " ms";
            throw new IllegalArgumentException(string.toString());
        }
        return ProduceKt.produce$default($this$fixedPeriodTicker, null, 0, new Function2<ProducerScope<? super Unit>, Continuation<? super Unit>, Object>(initialDelayMillis, delayMillis2, null){
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ long $initialDelayMillis;
            final /* synthetic */ long $delayMillis;
            {
                this.$initialDelayMillis = $initialDelayMillis;
                this.$delayMillis = $delayMillis;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var3_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        this.L$0 = $this$produce;
                        this.label = 1;
                        v0 = DelayKt.delay(this.$initialDelayMillis, this);
                        if (v0 == var3_2) {
                            return var3_2;
                        }
                        ** GOTO lbl32
                    }
                    case 1: {
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        ** GOTO lbl32
                    }
                    case 2: {
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
                        while (true) {
                            this.L$0 = $this$produce;
                            this.label = 3;
                            v2 = DelayKt.delay(this.$delayMillis, this);
                            if (v2 == var3_2) {
                                return var3_2;
                            }
                            ** GOTO lbl32
                            break;
                        }
                    }
                    case 3: {
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl32:
                        // 4 sources

                        this.L$0 = $this$produce;
                        this.label = 2;
                        if ((v1 = $this$produce.getChannel().send(Unit.INSTANCE, this)) != var3_2) ** continue;
                        return var3_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super Unit>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super Unit> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 1, null);
    }

    public static /* synthetic */ ReceiveChannel fixedPeriodTicker$default(CoroutineScope coroutineScope, long l, long l2, int n, Object object) {
        if ((n & 2) != 0) {
            l2 = l;
        }
        return FlowKt.fixedPeriodTicker(coroutineScope, l, l2);
    }

    @FlowPreview
    @NotNull
    public static final <T> Flow<T> sample-HG0u8IE(@NotNull Flow<? extends T> $this$sample_u2dHG0u8IE, long period) {
        return FlowKt.sample($this$sample_u2dHG0u8IE, DelayKt.toDelayMillis-LRDsOJo(period));
    }
}

