/*
 * Decompiled with CFR 0.150.
 */
package kotlinx.coroutines.channels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.PublishedApi;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.IndexedValue;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.GlobalScope;
import kotlinx.coroutines.channels.ChannelIterator;
import kotlinx.coroutines.channels.ChannelsKt;
import kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.channels.ReceiveChannel;
import kotlinx.coroutines.channels.SendChannel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=5, xi=48, d1={"\u0000\u00a0\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u001f\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\b\u0002\n\u0002\u0010!\n\u0000\n\u0002\u0010#\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u001aJ\u0010\u0000\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u0002\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u0001j\u0002`\u00072\u001a\u0010\b\u001a\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\n0\t\"\u0006\u0012\u0002\b\u00030\nH\u0001\u00a2\u0006\u0002\u0010\u000b\u001a!\u0010\f\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a1\u0010\u0010\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\u0002\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\u0004\u0012\u00020\u00060\u0001j\u0002`\u0007*\u0006\u0012\u0002\b\u00030\nH\u0001\u001a!\u0010\u0011\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a\u001e\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0007\u001aZ\u0010\u0014\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u0010\u0015*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010\u0018\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00150\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a0\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\u001e\u001a\u00020\u00122\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001aT\u0010\u001f\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a)\u0010!\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\"\u001a\u00020\u0012H\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010#\u001a+\u0010$\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\"\u001a\u00020\u0012H\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010#\u001aT\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001ai\u0010&\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001727\u0010 \u001a3\b\u0001\u0012\u0013\u0012\u00110\u0012\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(\u001aT\u0010)\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a$\u0010*\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\b\b\u0000\u0010\u000e*\u00020\u001b*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\nH\u0001\u001aA\u0010+\u001a\u0002H,\"\b\b\u0000\u0010\u000e*\u00020\u001b\"\u0010\b\u0001\u0010,*\n\u0012\u0006\b\u0000\u0012\u0002H\u000e0-*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010/\u001a?\u0010+\u001a\u0002H,\"\b\b\u0000\u0010\u000e*\u00020\u001b\"\u000e\b\u0001\u0010,*\b\u0012\u0004\u0012\u0002H\u000e00*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u00101\u001a!\u00102\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a#\u00103\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a`\u00104\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172(\u00106\u001a$\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\n0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a)\u00107\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u00108\u001a\u0002H\u000eH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u00109\u001a!\u0010:\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a)\u0010;\u001a\u00020\u0012\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u00108\u001a\u0002H\u000eH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u00109\u001a#\u0010<\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001aZ\u0010=\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u00106\u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0001\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001ao\u0010>\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001727\u00106\u001a3\b\u0001\u0012\u0013\u0012\u00110\u0012\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0001\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(\u001au\u0010?\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\b\b\u0001\u00105*\u00020\u001b*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001729\u00106\u001a5\b\u0001\u0012\u0013\u0012\u00110\u0012\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\"\u0012\u0004\u0012\u0002H\u000e\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u0001H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0'H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010(\u001a`\u0010@\u001a\b\u0012\u0004\u0012\u0002H50\n\"\u0004\b\u0000\u0010\u000e\"\b\b\u0001\u00105*\u00020\u001b*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172$\u00106\u001a \b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u0001H50\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a?\u0010A\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u001a\u0010B\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u000e0Cj\n\u0012\u0006\b\u0000\u0012\u0002H\u000e`DH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010E\u001a?\u0010F\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u001a\u0010B\u001a\u0016\u0012\u0006\b\u0000\u0012\u0002H\u000e0Cj\n\u0012\u0006\b\u0000\u0012\u0002H\u000e`DH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010E\u001a!\u0010G\u001a\u00020\r\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a$\u0010H\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\b\b\u0000\u0010\u000e*\u00020\u001b*\n\u0012\u0006\u0012\u0004\u0018\u0001H\u000e0\nH\u0007\u001a!\u0010I\u001a\u0002H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a#\u0010J\u001a\u0004\u0018\u0001H\u000e\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a0\u0010K\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010\u001e\u001a\u00020\u00122\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001aT\u0010L\u001a\b\u0012\u0004\u0012\u0002H\u000e0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u00172\"\u0010 \u001a\u001e\b\u0001\u0012\u0004\u0012\u0002H\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u0019H\u0007\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u001c\u001a9\u0010M\u001a\u0002H,\"\u0004\b\u0000\u0010\u000e\"\u000e\b\u0001\u0010,*\b\u0012\u0004\u0012\u0002H\u000e00*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0081@\u00f8\u0001\u0000\u00a2\u0006\u0002\u00101\u001a;\u0010N\u001a\u0002H,\"\u0004\b\u0000\u0010\u000e\"\u0010\b\u0001\u0010,*\n\u0012\u0006\b\u0000\u0012\u0002H\u000e0-*\b\u0012\u0004\u0012\u0002H\u000e0\n2\u0006\u0010.\u001a\u0002H,H\u0081@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010/\u001a?\u0010O\u001a\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0P\"\u0004\b\u0000\u0010\u0015\"\u0004\b\u0001\u0010Q*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0R0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001aU\u0010O\u001a\u0002HS\"\u0004\b\u0000\u0010\u0015\"\u0004\b\u0001\u0010Q\"\u0018\b\u0002\u0010S*\u0012\u0012\u0006\b\u0000\u0012\u0002H\u0015\u0012\u0006\b\u0000\u0012\u0002HQ0T*\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u0015\u0012\u0004\u0012\u0002HQ0R0\n2\u0006\u0010.\u001a\u0002HSH\u0081@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010U\u001a'\u0010V\u001a\b\u0012\u0004\u0012\u0002H\u000e0W\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a'\u0010X\u001a\b\u0012\u0004\u0012\u0002H\u000e0Y\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0081@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a'\u0010Z\u001a\b\u0012\u0004\u0012\u0002H\u000e0[\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\nH\u0087@\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000f\u001a.\u0010\\\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u000e0]0\n\"\u0004\b\u0000\u0010\u000e*\b\u0012\u0004\u0012\u0002H\u000e0\n2\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0007\u001a?\u0010^\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u0002H50R0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105*\b\u0012\u0004\u0012\u0002H\u000e0\n2\f\u0010_\u001a\b\u0012\u0004\u0012\u0002H50\nH\u0087\u0004\u001az\u0010^\u001a\b\u0012\u0004\u0012\u0002HQ0\n\"\u0004\b\u0000\u0010\u000e\"\u0004\b\u0001\u00105\"\u0004\b\u0002\u0010Q*\b\u0012\u0004\u0012\u0002H\u000e0\n2\f\u0010_\u001a\b\u0012\u0004\u0012\u0002H50\n2\b\b\u0002\u0010\u0016\u001a\u00020\u001726\u00106\u001a2\u0012\u0013\u0012\u0011H\u000e\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(`\u0012\u0013\u0012\u0011H5\u00a2\u0006\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(a\u0012\u0004\u0012\u0002HQ0\u0019H\u0001\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006b"}, d2={"consumesAll", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "cause", "", "Lkotlinx/coroutines/CompletionHandler;", "channels", "", "Lkotlinx/coroutines/channels/ReceiveChannel;", "([Lkotlinx/coroutines/channels/ReceiveChannel;)Lkotlin/jvm/functions/Function1;", "any", "", "E", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "consumes", "count", "", "distinct", "distinctBy", "K", "context", "Lkotlin/coroutines/CoroutineContext;", "selector", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;)Lkotlinx/coroutines/channels/ReceiveChannel;", "drop", "n", "dropWhile", "predicate", "elementAt", "index", "(Lkotlinx/coroutines/channels/ReceiveChannel;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "elementAtOrNull", "filter", "filterIndexed", "Lkotlin/Function3;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function3;)Lkotlinx/coroutines/channels/ReceiveChannel;", "filterNot", "filterNotNull", "filterNotNullTo", "C", "", "destination", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Collection;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlinx/coroutines/channels/SendChannel;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Lkotlinx/coroutines/channels/SendChannel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "first", "firstOrNull", "flatMap", "R", "transform", "indexOf", "element", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "last", "lastIndexOf", "lastOrNull", "map", "mapIndexed", "mapIndexedNotNull", "mapNotNull", "maxWith", "comparator", "Ljava/util/Comparator;", "Lkotlin/Comparator;", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Comparator;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "minWith", "none", "requireNoNulls", "single", "singleOrNull", "take", "takeWhile", "toChannel", "toCollection", "toMap", "", "V", "Lkotlin/Pair;", "M", "", "(Lkotlinx/coroutines/channels/ReceiveChannel;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "toMutableList", "", "toMutableSet", "", "toSet", "", "withIndex", "Lkotlin/collections/IndexedValue;", "zip", "other", "a", "b", "kotlinx-coroutines-core"}, xs="kotlinx/coroutines/channels/ChannelsKt")
final class ChannelsKt__DeprecatedKt {
    @PublishedApi
    @NotNull
    public static final Function1<Throwable, Unit> consumesAll(ReceiveChannel<?> ... channels2) {
        return new Function1<Throwable, Unit>(channels2){
            final /* synthetic */ ReceiveChannel<?>[] $channels;
            {
                this.$channels = $channels;
                super(1);
            }

            public final void invoke(@Nullable Throwable cause) {
                Throwable exception = null;
                for (ReceiveChannel<?> channel2 : this.$channels) {
                    try {
                        ChannelsKt.cancelConsumed(channel2, cause);
                    }
                    catch (Throwable e) {
                        if (exception == null) {
                            exception = e;
                            continue;
                        }
                        Throwable $this$addSuppressedThrowable$iv = exception;
                        boolean $i$f$addSuppressedThrowable = false;
                        ExceptionsKt.addSuppressed($this$addSuppressedThrowable$iv, e);
                    }
                }
                Throwable throwable = exception;
                if (throwable != null) {
                    Throwable it = throwable;
                    boolean bl = false;
                    throw it;
                }
            }
        };
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object elementAt(ReceiveChannel var0, int var1_1, Continuation var2_2) {
        if (!(var2_2 instanceof elementAt.1)) ** GOTO lbl-1000
        var13_3 = var2_2;
        if ((var13_3.label & -2147483648) != 0) {
            var13_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var2_2){
                int I$0;
                int I$1;
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.elementAt(null, 0, this);
                }
            };
        }
        $result = $continuation.result;
        var14_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$elementAt;
                $i$f$consume = false;
                cause$iv = null;
                try {
                    $this$elementAt_u24lambda_u2d0 = $this$consume$iv;
                    $i$a$-consume-ChannelsKt__DeprecatedKt$elementAt$2 = false;
                    if (index < 0) {
                        throw new IndexOutOfBoundsException("ReceiveChannel doesn't contain element at index " + index + '.');
                    }
                    count = 0;
                    var9_14 = $this$elementAt_u24lambda_u2d0.iterator();
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
                catch (Throwable var6_11) {
                    ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
                    throw var6_11;
                }
                while (true) {
                    $continuation.L$0 = $this$consume$iv;
                    $continuation.L$1 = var9_14;
                    $continuation.I$0 = index;
                    $continuation.I$1 = count;
                    $continuation.label = 1;
                    v0 = var9_14.hasNext($continuation);
                    if (v0 == var14_5) {
                        return var14_5;
                    }
                    ** GOTO lbl52
                    break;
                }
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$elementAt$2 = false;
                count = $continuation.I$1;
                index = $continuation.I$0;
                var9_14 = (ChannelIterator<E>)$continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl52:
                    // 2 sources

                    if (!((Boolean)v0).booleanValue()) ** GOTO lbl-1000
                    element = var9_14.next();
                    if (index != count++) ** continue;
                    var11_16 = element;
                }
                ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
                return var11_16;
lbl-1000:
                // 1 sources

                {
                    throw new IndexOutOfBoundsException("ReceiveChannel doesn't contain element at index " + index + '.');
                }
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object elementAtOrNull(ReceiveChannel var0, int var1_1, Continuation var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 1[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object first(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof first.1)) ** GOTO lbl-1000
        var10_2 = var1_1;
        if ((var10_2.label & -2147483648) != 0) {
            var10_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.first(null, this);
                }
            };
        }
        $result = $continuation.result;
        var11_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$first;
                $i$f$consume = false;
                cause$iv = null;
                $this$first_u24lambda_u2d2 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$first$2 = false;
                iterator = $this$first_u24lambda_u2d2.iterator();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = iterator;
                $continuation.label = 1;
                v0 = iterator.hasNext($continuation);
                ** if (v0 != var11_4) goto lbl27
lbl26:
                // 1 sources

                return var11_4;
lbl27:
                // 1 sources

                ** GOTO lbl38
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$first$2 = false;
                iterator = (ChannelIterator<E>)$continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl38:
                    // 2 sources

                    if (!((Boolean)v0).booleanValue()) {
                        throw new NoSuchElementException("ReceiveChannel is empty.");
                    }
                    var8_15 = iterator.next();
                    return var8_15;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_11) {
            throw var5_11;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object firstOrNull(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof firstOrNull.1)) ** GOTO lbl-1000
        var11_2 = var1_1;
        if ((var11_2.label & -2147483648) != 0) {
            var11_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.firstOrNull(null, this);
                }
            };
        }
        $result = $continuation.result;
        var12_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$firstOrNull;
                $i$f$consume = false;
                cause$iv = null;
                $this$firstOrNull_u24lambda_u2d3 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$firstOrNull$2 = false;
                iterator = $this$firstOrNull_u24lambda_u2d3.iterator();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = iterator;
                $continuation.label = 1;
                v0 = iterator.hasNext($continuation);
                ** if (v0 != var12_4) goto lbl27
lbl26:
                // 1 sources

                return var12_4;
lbl27:
                // 1 sources

                ** GOTO lbl38
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$firstOrNull$2 = false;
                iterator = (ChannelIterator<E>)$continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl38:
                    // 2 sources

                    if (!((Boolean)v0).booleanValue()) {
                        var9_15 = null;
                        return var9_15;
                    }
                    var8_16 = iterator.next();
                    return var8_16;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_11) {
            throw var5_11;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object indexOf(ReceiveChannel var0, Object var1_1, Continuation var2_2) {
        if (!(var2_2 instanceof indexOf.1)) ** GOTO lbl-1000
        var18_3 = var2_2;
        if ((var18_3.label & -2147483648) != 0) {
            var18_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var2_2){
                Object L$0;
                Object L$1;
                Object L$2;
                Object L$3;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.indexOf(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var19_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                index = new Ref.IntRef();
                $this$consumeEach$iv = $this$indexOf;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var11_16 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var9_14) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var9_14;
                    }
                }
lbl32:
                // 2 sources

                while (true) {
                    $continuation.L$0 = element;
                    $continuation.L$1 = index;
                    $continuation.L$2 = $this$consume$iv$iv;
                    $continuation.L$3 = var11_16;
                    $continuation.label = 1;
                    v0 = var11_16.hasNext($continuation);
                    if (v0 == var19_5) {
                        return var19_5;
                    }
                    ** GOTO lbl54
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var11_16 = (ChannelIterator<E>)$continuation.L$3;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$2;
                index = (Ref.IntRef)$continuation.L$1;
                element = $continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl54:
                    // 2 sources

                    if (!((Boolean)v0).booleanValue()) ** GOTO lbl65
                    it = e$iv = var11_16.next();
                    $i$a$-consumeEach-ChannelsKt__DeprecatedKt$indexOf$2 = false;
                    if (!Intrinsics.areEqual(element, it)) ** GOTO lbl-1000
                    var16_21 = Boxing.boxInt(index.element);
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return var16_21;
lbl-1000:
                // 1 sources

                {
                    var15_20 = index.element;
                    index.element = var15_20 + 1;
                    ** continue;
lbl65:
                    // 1 sources

                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return Boxing.boxInt(-1);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object last(ReceiveChannel var0, Continuation var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 1[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object lastIndexOf(ReceiveChannel var0, Object var1_1, Continuation var2_2) {
        if (!(var2_2 instanceof lastIndexOf.1)) ** GOTO lbl-1000
        var18_3 = var2_2;
        if ((var18_3.label & -2147483648) != 0) {
            var18_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var2_2){
                Object L$0;
                Object L$1;
                Object L$2;
                Object L$3;
                Object L$4;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.lastIndexOf(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var19_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                lastIndex = new Ref.IntRef();
                lastIndex.element = -1;
                index = new Ref.IntRef();
                $this$consumeEach$iv = $this$lastIndexOf;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var12_17 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var10_15) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var10_15;
                    }
                }
lbl34:
                // 2 sources

                while (true) {
                    $continuation.L$0 = element;
                    $continuation.L$1 = lastIndex;
                    $continuation.L$2 = index;
                    $continuation.L$3 = $this$consume$iv$iv;
                    $continuation.L$4 = var12_17;
                    $continuation.label = 1;
                    v0 = var12_17.hasNext($continuation);
                    if (v0 == var19_5) {
                        return var19_5;
                    }
                    ** GOTO lbl58
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var12_17 = (ChannelIterator<E>)$continuation.L$4;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$3;
                index = (Ref.IntRef)$continuation.L$2;
                lastIndex = (Ref.IntRef)$continuation.L$1;
                element = $continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl58:
                    // 2 sources

                    if (((Boolean)v0).booleanValue()) {
                        it = e$iv = var12_17.next();
                        $i$a$-consumeEach-ChannelsKt__DeprecatedKt$lastIndexOf$2 = false;
                        if (Intrinsics.areEqual(element, it)) {
                            lastIndex.element = index.element;
                        }
                        var16_21 = index.element;
                        index.element = var16_21 + 1;
                        ** continue;
                    }
                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return Boxing.boxInt(lastIndex.element);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object lastOrNull(ReceiveChannel var0, Continuation var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[CASE]], but top level block is 2[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object single(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof single.1)) ** GOTO lbl-1000
        var11_2 = var1_1;
        if ((var11_2.label & -2147483648) != 0) {
            var11_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.single(null, this);
                }
            };
        }
        $result = $continuation.result;
        var12_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$single;
                $i$f$consume = false;
                cause$iv = null;
                $this$single_u24lambda_u2d8 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$single$2 = false;
                iterator = $this$single_u24lambda_u2d8.iterator();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = iterator;
                $continuation.label = 1;
                v0 = iterator.hasNext($continuation);
                ** if (v0 != var12_4) goto lbl27
lbl26:
                // 1 sources

                return var12_4;
lbl27:
                // 1 sources

                ** GOTO lbl38
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$single$2 = false;
                iterator = (ChannelIterator<E>)$continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl38:
                // 2 sources

                if (!((Boolean)v0).booleanValue()) {
                    throw new NoSuchElementException("ReceiveChannel is empty.");
                }
                single = iterator.next();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = single;
                $continuation.label = 2;
                v1 = iterator.hasNext($continuation);
                ** if (v1 != var12_4) goto lbl47
lbl46:
                // 1 sources

                return var12_4;
lbl47:
                // 1 sources

                ** GOTO lbl58
            }
            case 2: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$single$2 = false;
                single = $continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v1 = $result;
lbl58:
                    // 2 sources

                    if (((Boolean)v1).booleanValue()) {
                        throw new IllegalArgumentException("ReceiveChannel has more than one element.");
                    }
                    var9_18 = single;
                    return var9_18;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_12) {
            throw var5_12;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object singleOrNull(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof singleOrNull.1)) ** GOTO lbl-1000
        var13_2 = var1_1;
        if ((var13_2.label & -2147483648) != 0) {
            var13_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                Object L$1;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.singleOrNull(null, this);
                }
            };
        }
        $result = $continuation.result;
        var14_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$singleOrNull;
                $i$f$consume = false;
                cause$iv = null;
                $this$singleOrNull_u24lambda_u2d9 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$singleOrNull$2 = false;
                iterator = $this$singleOrNull_u24lambda_u2d9.iterator();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = iterator;
                $continuation.label = 1;
                v0 = iterator.hasNext($continuation);
                ** if (v0 != var14_4) goto lbl27
lbl26:
                // 1 sources

                return var14_4;
lbl27:
                // 1 sources

                ** GOTO lbl38
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$singleOrNull$2 = false;
                iterator = (ChannelIterator<E>)$continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                ResultKt.throwOnFailure($result);
                v0 = $result;
lbl38:
                // 2 sources

                if (((Boolean)v0).booleanValue()) ** GOTO lbl43
                var11_17 = null;
                ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
                return var11_17;
lbl43:
                // 2 sources

                single = iterator.next();
                $continuation.L$0 = $this$consume$iv;
                $continuation.L$1 = single;
                $continuation.label = 2;
                v1 = iterator.hasNext($continuation);
                ** if (v1 != var14_4) goto lbl50
lbl49:
                // 1 sources

                return var14_4;
lbl50:
                // 1 sources

                ** GOTO lbl61
            }
            case 2: {
                $i$a$-consume-ChannelsKt__DeprecatedKt$singleOrNull$2 = false;
                $i$f$consume = false;
                single = $continuation.L$1;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v1 = $result;
lbl61:
                    // 2 sources

                    if (((Boolean)v1).booleanValue()) {
                        var10_19 = null;
                        return var10_19;
                    }
                    var9_20 = single;
                    return var9_20;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_12) {
            throw var5_12;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel drop(ReceiveChannel $this$drop, int n, CoroutineContext context) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$drop), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>(n, $this$drop, null){
            Object L$1;
            int I$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ int $n;
            final /* synthetic */ ReceiveChannel<E> $this_drop;
            {
                this.$n = $n;
                this.$this_drop = $receiver;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var6_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        var3_4 = this.$n >= 0;
                        var4_5 = this.$n;
                        if (!var3_4) {
                            $i$a$-require-ChannelsKt__DeprecatedKt$drop$1$1 = false;
                            $i$a$-require-ChannelsKt__DeprecatedKt$drop$1$1 = "Requested element count " + var4_5 + " is less than zero.";
                            throw new IllegalArgumentException($i$a$-require-ChannelsKt__DeprecatedKt$drop$1$1.toString());
                        }
                        remaining = this.$n;
                        if (remaining <= 0) ** GOTO lbl33
                        var4_6 = this.$this_drop.iterator();
                        ** GOTO lbl26
                    }
                    case 1: {
                        remaining = this.I$0;
                        var4_6 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (((Boolean)v0).booleanValue()) {
                            var4_6.next();
                            if (--remaining == 0) break;
lbl26:
                            // 2 sources

                            this.L$0 = $this$produce;
                            this.L$1 = var4_6;
                            this.I$0 = remaining;
                            this.label = 1;
                            v0 = var4_6.hasNext(this);
                            if (v0 != var6_2) continue;
                            return var6_2;
                        }
lbl33:
                        // 3 sources

                        var4_7 = this.$this_drop.iterator();
                        ** GOTO lbl55
                    }
                    case 2: {
                        var4_7 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
                        while (true) {
                            if ((Boolean)v1 == false) return Unit.INSTANCE;
                            e = var4_7.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var4_7;
                            this.label = 3;
                            v2 = $this$produce.send(e, this);
                            if (v2 == var6_2) {
                                return var6_2;
                            }
                            ** GOTO lbl55
                            break;
                        }
                    }
                    case 3: {
                        var4_7 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl55:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_7;
                        this.label = 2;
                        if ((v1 = var4_7.hasNext(this)) != var6_2) ** continue;
                        return var6_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel drop$default(ReceiveChannel receiveChannel2, int n, CoroutineContext coroutineContext2, int n2, Object object) {
        if ((n2 & 2) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.drop(receiveChannel2, n, coroutineContext2);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel dropWhile(ReceiveChannel $this$dropWhile, CoroutineContext context, Function2 predicate) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$dropWhile), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>($this$dropWhile, predicate, null){
            Object L$1;
            Object L$2;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_dropWhile;
            final /* synthetic */ Function2<E, Continuation<? super Boolean>, Object> $predicate;
            {
                this.$this_dropWhile = $receiver;
                this.$predicate = $predicate;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        var3_4 = this.$this_dropWhile.iterator();
                        ** GOTO lbl39
                    }
                    case 1: {
                        var3_4 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
lbl13:
                        // 2 sources

                        while (((Boolean)v0).booleanValue()) {
                            e = var3_4.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.L$2 = e;
                            this.label = 2;
                            v1 = this.$predicate.invoke(e, this);
                            if (v1 == var5_2) {
                                return var5_2;
                            }
                            ** GOTO lbl30
                        }
                        ** GOTO lbl50
                    }
                    case 2: {
                        e = this.L$2;
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl30:
                        // 2 sources

                        if (((Boolean)v1).booleanValue()) ** GOTO lbl39
                        this.L$0 = $this$produce;
                        this.L$1 = null;
                        this.L$2 = null;
                        this.label = 3;
                        v2 = $this$produce.send(e, this);
                        if (v2 == var5_2) {
                            return var5_2;
                        }
                        ** GOTO lbl50
lbl39:
                        // 2 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.L$2 = null;
                        this.label = 1;
                        v0 = var3_4.hasNext(this);
                        if (v0 != var5_2) ** GOTO lbl13
                        return var5_2;
                    }
                    case 3: {
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl50:
                        // 3 sources

                        var3_4 = this.$this_dropWhile.iterator();
                        ** GOTO lbl72
                    }
                    case 4: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
                        while (true) {
                            if ((Boolean)v3 == false) return Unit.INSTANCE;
                            e = var3_4.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.label = 5;
                            v4 = $this$produce.send(e, this);
                            if (v4 == var5_2) {
                                return var5_2;
                            }
                            ** GOTO lbl72
                            break;
                        }
                    }
                    case 5: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v4 = $result;
lbl72:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.label = 4;
                        if ((v3 = var3_4.hasNext(this)) != var5_2) ** continue;
                        return var5_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel dropWhile$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.dropWhile(receiveChannel2, coroutineContext2, function2);
    }

    @PublishedApi
    @NotNull
    public static final <E> ReceiveChannel<E> filter(@NotNull ReceiveChannel<? extends E> $this$filter, @NotNull CoroutineContext context, @NotNull Function2<? super E, ? super Continuation<? super Boolean>, ? extends Object> predicate) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$filter), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>($this$filter, predicate, null){
            Object L$1;
            Object L$2;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_filter;
            final /* synthetic */ Function2<E, Continuation<? super Boolean>, Object> $predicate;
            {
                this.$this_filter = $receiver;
                this.$predicate = $predicate;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        var3_4 = this.$this_filter.iterator();
                        ** GOTO lbl44
                    }
                    case 1: {
                        var3_4 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var3_4.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.L$2 = e;
                            this.label = 2;
                            v1 = this.$predicate.invoke(e, this);
                            if (v1 == var5_2) {
                                return var5_2;
                            }
                            ** GOTO lbl30
                            break;
                        }
                    }
                    case 2: {
                        e = this.L$2;
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl30:
                        // 2 sources

                        if (((Boolean)v1).booleanValue()) {
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.L$2 = null;
                            this.label = 3;
                            v2 = $this$produce.send(e, this);
                            if (v2 == var5_2) {
                                return var5_2;
                            }
                        }
                        ** GOTO lbl44
                    }
                    case 3: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl44:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.L$2 = null;
                        this.label = 1;
                        if ((v0 = var3_4.hasNext(this)) != var5_2) ** continue;
                        return var5_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel filter$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.filter(receiveChannel2, coroutineContext2, function2);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel filterIndexed(ReceiveChannel $this$filterIndexed, CoroutineContext context, Function3 predicate) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$filterIndexed), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>($this$filterIndexed, predicate, null){
            Object L$1;
            Object L$2;
            int I$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_filterIndexed;
            final /* synthetic */ Function3<Integer, E, Continuation<? super Boolean>, Object> $predicate;
            {
                this.$this_filterIndexed = $receiver;
                this.$predicate = $predicate;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var6_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        index = 0;
                        var4_5 = this.$this_filterIndexed.iterator();
                        ** GOTO lbl51
                    }
                    case 1: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var4_5.next();
                            v1 = index++;
                            this.L$0 = $this$produce;
                            this.L$1 = var4_5;
                            this.L$2 = e;
                            this.I$0 = index;
                            this.label = 2;
                            v2 = this.$predicate.invoke(Boxing.boxInt(v1), e, this);
                            if (v2 == var6_2) {
                                return var6_2;
                            }
                            ** GOTO lbl35
                            break;
                        }
                    }
                    case 2: {
                        index = this.I$0;
                        e = this.L$2;
                        var4_5 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl35:
                        // 2 sources

                        if (((Boolean)v2).booleanValue()) {
                            this.L$0 = $this$produce;
                            this.L$1 = var4_5;
                            this.L$2 = null;
                            this.I$0 = index;
                            this.label = 3;
                            v3 = $this$produce.send(e, this);
                            if (v3 == var6_2) {
                                return var6_2;
                            }
                        }
                        ** GOTO lbl51
                    }
                    case 3: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
lbl51:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_5;
                        this.L$2 = null;
                        this.I$0 = index;
                        this.label = 1;
                        if ((v0 = var4_5.hasNext(this)) != var6_2) ** continue;
                        return var6_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel filterIndexed$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function3 function3, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.filterIndexed(receiveChannel2, coroutineContext2, function3);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel filterNot(ReceiveChannel $this$filterNot, CoroutineContext context, Function2 predicate) {
        return ChannelsKt.filter($this$filterNot, context, new Function2<E, Continuation<? super Boolean>, Object>(predicate, null){
            int label;
            /* synthetic */ Object L$0;
            final /* synthetic */ Function2<E, Continuation<? super Boolean>, Object> $predicate;
            {
                this.$predicate = $predicate;
                super(2, $completion);
            }

            /*
             * WARNING - void declaration
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                Object object2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        Object it = this.L$0;
                        this.label = 1;
                        Object object3 = this.$predicate.invoke(it, this);
                        if (object3 != object2) return Boxing.boxBoolean((Boolean)object3 == false);
                        return object2;
                    }
                    case 1: {
                        void $result;
                        ResultKt.throwOnFailure($result);
                        Object object3 = $result;
                        return Boxing.boxBoolean((Boolean)object3 == false);
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<E, Continuation<? super Boolean>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(E p1, @Nullable Continuation<? super Boolean> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        });
    }

    public static /* synthetic */ ReceiveChannel filterNot$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.filterNot(receiveChannel2, coroutineContext2, function2);
    }

    @PublishedApi
    @NotNull
    public static final <E> ReceiveChannel<E> filterNotNull(@NotNull ReceiveChannel<? extends E> $this$filterNotNull) {
        return ChannelsKt.filter$default($this$filterNotNull, null, new Function2<E, Continuation<? super Boolean>, Object>(null){
            int label;
            /* synthetic */ Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        Object it = this.L$0;
                        return Boxing.boxBoolean(it != null);
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<E, Continuation<? super Boolean>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@Nullable E p1, @Nullable Continuation<? super Boolean> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 1, null);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object filterNotNullTo(ReceiveChannel var0, Collection var1_1, Continuation var2_2) {
        if (!(var2_2 instanceof filterNotNullTo.1)) ** GOTO lbl-1000
        var15_3 = var2_2;
        if ((var15_3.label & -2147483648) != 0) {
            var15_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var2_2){
                Object L$0;
                Object L$1;
                Object L$2;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.filterNotNullTo(null, null, (Continuation)this);
                }
            };
        }
        $result = $continuation.result;
        var16_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consumeEach$iv = $this$filterNotNullTo;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var10_15 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var8_13) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var8_13;
                    }
                }
lbl31:
                // 3 sources

                while (true) {
                    $continuation.L$0 = destination;
                    $continuation.L$1 = $this$consume$iv$iv;
                    $continuation.L$2 = var10_15;
                    $continuation.label = 1;
                    v0 = var10_15.hasNext($continuation);
                    if (v0 == var16_5) {
                        return var16_5;
                    }
                    ** GOTO lbl51
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var10_15 = (ChannelIterator<E>)$continuation.L$2;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$1;
                destination = (Collection)$continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl51:
                    // 2 sources

                    if (!((Boolean)v0).booleanValue()) ** GOTO lbl59
                    it = e$iv = var10_15.next();
                    $i$a$-consumeEach-ChannelsKt__DeprecatedKt$filterNotNullTo$2 = false;
                    if (it == null) ** GOTO lbl31
                    destination.add(it);
                    ** continue;
lbl59:
                    // 1 sources

                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return destination;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object filterNotNullTo(ReceiveChannel var0, SendChannel var1_1, Continuation var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [5[CASE]], but top level block is 0[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel take(ReceiveChannel $this$take, int n, CoroutineContext context) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$take), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>(n, $this$take, null){
            Object L$1;
            int I$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ int $n;
            final /* synthetic */ ReceiveChannel<E> $this_take;
            {
                this.$n = $n;
                this.$this_take = $receiver;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var6_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        if (this.$n == 0) {
                            return Unit.INSTANCE;
                        }
                        var3_4 = this.$n >= 0;
                        var4_5 = this.$n;
                        if (!var3_4) {
                            $i$a$-require-ChannelsKt__DeprecatedKt$take$1$1 = false;
                            $i$a$-require-ChannelsKt__DeprecatedKt$take$1$1 = "Requested element count " + var4_5 + " is less than zero.";
                            throw new IllegalArgumentException($i$a$-require-ChannelsKt__DeprecatedKt$take$1$1.toString());
                        }
                        remaining = this.$n;
                        var4_6 = this.$this_take.iterator();
                        ** GOTO lbl42
                    }
                    case 1: {
                        remaining = this.I$0;
                        var4_6 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var4_6.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var4_6;
                            this.I$0 = remaining;
                            this.label = 2;
                            v1 = $this$produce.send(e, this);
                            if (v1 == var6_2) {
                                return var6_2;
                            }
                            ** GOTO lbl40
                            break;
                        }
                    }
                    case 2: {
                        remaining = this.I$0;
                        var4_6 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl40:
                        // 2 sources

                        if (--remaining == 0) {
                            return Unit.INSTANCE;
                        }
lbl42:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_6;
                        this.I$0 = remaining;
                        this.label = 1;
                        if ((v0 = var4_6.hasNext(this)) != var6_2) ** continue;
                        return var6_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel take$default(ReceiveChannel receiveChannel2, int n, CoroutineContext coroutineContext2, int n2, Object object) {
        if ((n2 & 2) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.take(receiveChannel2, n, coroutineContext2);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel takeWhile(ReceiveChannel $this$takeWhile, CoroutineContext context, Function2 predicate) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$takeWhile), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>($this$takeWhile, predicate, null){
            Object L$1;
            Object L$2;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_takeWhile;
            final /* synthetic */ Function2<E, Continuation<? super Boolean>, Object> $predicate;
            {
                this.$this_takeWhile = $receiver;
                this.$predicate = $predicate;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        var3_4 = this.$this_takeWhile.iterator();
                        ** GOTO lbl45
                    }
                    case 1: {
                        var3_4 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var3_4.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.L$2 = e;
                            this.label = 2;
                            v1 = this.$predicate.invoke(e, this);
                            if (v1 == var5_2) {
                                return var5_2;
                            }
                            ** GOTO lbl30
                            break;
                        }
                    }
                    case 2: {
                        e = this.L$2;
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl30:
                        // 2 sources

                        if (!((Boolean)v1).booleanValue()) {
                            return Unit.INSTANCE;
                        }
                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.L$2 = null;
                        this.label = 3;
                        v2 = $this$produce.send(e, this);
                        if (v2 == var5_2) {
                            return var5_2;
                        }
                        ** GOTO lbl45
                    }
                    case 3: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl45:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.label = 1;
                        if ((v0 = var3_4.hasNext(this)) != var5_2) ** continue;
                        return var5_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel takeWhile$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.takeWhile(receiveChannel2, coroutineContext2, function2);
    }

    /*
     * Exception decompiling
     */
    @PublishedApi
    @Nullable
    public static final <E, C extends SendChannel<? super E>> Object toChannel(@NotNull ReceiveChannel<? extends E> var0, @NotNull C var1_1, @NotNull Continuation<? super C> var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [5[CASE]], but top level block is 0[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @PublishedApi
    @Nullable
    public static final <E, C extends Collection<? super E>> Object toCollection(@NotNull ReceiveChannel<? extends E> var0, @NotNull C var1_1, @NotNull Continuation<? super C> var2_2) {
        if (!(var2_2 instanceof toCollection.1)) ** GOTO lbl-1000
        var15_3 = var2_2;
        if ((var15_3.label & -2147483648) != 0) {
            var15_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super toCollection.1>)var2_2){
                Object L$0;
                Object L$1;
                Object L$2;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.toCollection(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var16_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consumeEach$iv = $this$toCollection;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var10_15 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var8_13) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var8_13;
                    }
                }
lbl31:
                // 2 sources

                while (true) {
                    $continuation.L$0 = destination;
                    $continuation.L$1 = $this$consume$iv$iv;
                    $continuation.L$2 = var10_15;
                    $continuation.label = 1;
                    v0 = var10_15.hasNext($continuation);
                    if (v0 == var16_5) {
                        return var16_5;
                    }
                    ** GOTO lbl51
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var10_15 = (ChannelIterator<E>)$continuation.L$2;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$1;
                destination = (Collection)$continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl51:
                    // 2 sources

                    if (((Boolean)v0).booleanValue()) {
                        it = e$iv = var10_15.next();
                        $i$a$-consumeEach-ChannelsKt__DeprecatedKt$toCollection$2 = false;
                        destination.add(it);
                        ** continue;
                    }
                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return destination;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object toMap(ReceiveChannel $this$toMap, Continuation $completion) {
        return ChannelsKt.toMap($this$toMap, (Map)new LinkedHashMap(), $completion);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @PublishedApi
    @Nullable
    public static final <K, V, M extends Map<? super K, ? super V>> Object toMap(@NotNull ReceiveChannel<? extends Pair<? extends K, ? extends V>> var0, @NotNull M var1_1, @NotNull Continuation<? super M> var2_2) {
        if (!(var2_2 instanceof toMap.2)) ** GOTO lbl-1000
        var15_3 = var2_2;
        if ((var15_3.label & -2147483648) != 0) {
            var15_3.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl((Continuation<? super toMap.2>)var2_2){
                Object L$0;
                Object L$1;
                Object L$2;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.toMap(null, null, this);
                }
            };
        }
        $result = $continuation.result;
        var16_5 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consumeEach$iv = $this$toMap;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var10_15 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var8_13) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var8_13;
                    }
                }
lbl31:
                // 2 sources

                while (true) {
                    $continuation.L$0 = destination;
                    $continuation.L$1 = $this$consume$iv$iv;
                    $continuation.L$2 = var10_15;
                    $continuation.label = 1;
                    v0 = var10_15.hasNext($continuation);
                    if (v0 == var16_5) {
                        return var16_5;
                    }
                    ** GOTO lbl51
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var10_15 = (ChannelIterator<E>)$continuation.L$2;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$1;
                destination = (Map)$continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl51:
                    // 2 sources

                    if (((Boolean)v0).booleanValue()) {
                        e$iv = var10_15.next();
                        it = (Pair)e$iv;
                        $i$a$-consumeEach-ChannelsKt__DeprecatedKt$toMap$3 = false;
                        destination.put(it.getFirst(), it.getSecond());
                        ** continue;
                    }
                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return destination;
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object toMutableList(ReceiveChannel $this$toMutableList, Continuation $completion) {
        return ChannelsKt.toCollection($this$toMutableList, (Collection)new ArrayList(), $completion);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object toSet(ReceiveChannel $this$toSet, Continuation $completion) {
        return ChannelsKt.toMutableSet($this$toSet, $completion);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel flatMap(ReceiveChannel $this$flatMap, CoroutineContext context, Function2 transform2) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$flatMap), new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>($this$flatMap, transform2, null){
            Object L$1;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_flatMap;
            final /* synthetic */ Function2<E, Continuation<? super ReceiveChannel<? extends R>>, Object> $transform;
            {
                this.$this_flatMap = $receiver;
                this.$transform = $transform;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var5_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        var3_4 = this.$this_flatMap.iterator();
                        ** GOTO lbl40
                    }
                    case 1: {
                        var3_4 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var3_4.next();
                            this.L$0 = $this$produce;
                            this.L$1 = var3_4;
                            this.label = 2;
                            v1 = this.$transform.invoke(e, this);
                            if (v1 == var5_2) {
                                return var5_2;
                            }
                            ** GOTO lbl28
                            break;
                        }
                    }
                    case 2: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl28:
                        // 2 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.label = 3;
                        v2 = ChannelsKt.toChannel((ReceiveChannel)v1, (SendChannel)$this$produce, this);
                        if (v2 == var5_2) {
                            return var5_2;
                        }
                        ** GOTO lbl40
                    }
                    case 3: {
                        var3_4 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl40:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var3_4;
                        this.label = 1;
                        if ((v0 = var3_4.hasNext(this)) != var5_2) ** continue;
                        return var5_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super R> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel flatMap$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.flatMap(receiveChannel2, coroutineContext2, function2);
    }

    @PublishedApi
    @NotNull
    public static final <E, R> ReceiveChannel<R> map(@NotNull ReceiveChannel<? extends E> $this$map, @NotNull CoroutineContext context, @NotNull Function2<? super E, ? super Continuation<? super R>, ? extends Object> transform2) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$map), new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>($this$map, transform2, null){
            Object L$1;
            Object L$2;
            Object L$3;
            Object L$4;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_map;
            final /* synthetic */ Function2<E, Continuation<? super R>, Object> $transform;
            {
                this.$this_map = $receiver;
                this.$transform = $transform;
                super(2, $completion);
            }

            /*
             * Exception decompiling
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                /*
                 * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                 * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 0[TRYBLOCK]
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:588)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner.dumpWithArgs(ClassFileDumperAnonymousInner.java:87)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner.dumpInner(ConstructorInvokationAnonymousInner.java:75)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation.dumpInner(StaticFunctionInvokation.java:116)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn.dump(StructuredReturn.java:52)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.dump(Block.java:560)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.dump(AttributeCode.java:135)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:617)
                 * org.benf.cfr.reader.entities.classfilehelpers.AbstractClassFileDumper.dumpMethods(AbstractClassFileDumper.java:193)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal.dump(ClassFileDumperNormal.java:77)
                 * org.benf.cfr.reader.entities.ClassFile.dump(ClassFile.java:1138)
                 * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:932)
                 * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
                 * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
                 * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
                 * org.benf.cfr.reader.Main.main(Main.java:49)
                 */
                throw new IllegalStateException(Decompilation failed);
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super R> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel map$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.map(receiveChannel2, coroutineContext2, function2);
    }

    @PublishedApi
    @NotNull
    public static final <E, R> ReceiveChannel<R> mapIndexed(@NotNull ReceiveChannel<? extends E> $this$mapIndexed, @NotNull CoroutineContext context, @NotNull Function3<? super Integer, ? super E, ? super Continuation<? super R>, ? extends Object> transform2) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$mapIndexed), new Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object>($this$mapIndexed, transform2, null){
            Object L$1;
            Object L$2;
            int I$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_mapIndexed;
            final /* synthetic */ Function3<Integer, E, Continuation<? super R>, Object> $transform;
            {
                this.$this_mapIndexed = $receiver;
                this.$transform = $transform;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var7_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        index = 0;
                        var4_5 = this.$this_mapIndexed.iterator();
                        ** GOTO lbl51
                    }
                    case 1: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var4_5.next();
                            var6_7 = $this$produce;
                            v1 = index++;
                            this.L$0 = $this$produce;
                            this.L$1 = var4_5;
                            this.L$2 = var6_7;
                            this.I$0 = index;
                            this.label = 2;
                            v2 = this.$transform.invoke(Boxing.boxInt(v1), e, this);
                            if (v2 == var7_2) {
                                return var7_2;
                            }
                            ** GOTO lbl36
                            break;
                        }
                    }
                    case 2: {
                        index = this.I$0;
                        var6_7 = (ProducerScope)this.L$2;
                        var4_5 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl36:
                        // 2 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_5;
                        this.L$2 = null;
                        this.I$0 = index;
                        this.label = 3;
                        v3 = var6_7.send(v2, this);
                        if (v3 == var7_2) {
                            return var7_2;
                        }
                        ** GOTO lbl51
                    }
                    case 3: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v3 = $result;
lbl51:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_5;
                        this.I$0 = index;
                        this.label = 1;
                        if ((v0 = var4_5.hasNext(this)) != var7_2) ** continue;
                        return var7_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super R>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super R> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel mapIndexed$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function3 function3, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.mapIndexed(receiveChannel2, coroutineContext2, function3);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel mapIndexedNotNull(ReceiveChannel $this$mapIndexedNotNull, CoroutineContext context, Function3 transform2) {
        return ChannelsKt.filterNotNull(ChannelsKt.mapIndexed($this$mapIndexedNotNull, context, transform2));
    }

    public static /* synthetic */ ReceiveChannel mapIndexedNotNull$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function3 function3, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.mapIndexedNotNull(receiveChannel2, coroutineContext2, function3);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel mapNotNull(ReceiveChannel $this$mapNotNull, CoroutineContext context, Function2 transform2) {
        return ChannelsKt.filterNotNull(ChannelsKt.map($this$mapNotNull, context, transform2));
    }

    public static /* synthetic */ ReceiveChannel mapNotNull$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.mapNotNull(receiveChannel2, coroutineContext2, function2);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel withIndex(ReceiveChannel $this$withIndex, CoroutineContext context) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$withIndex), new Function2<ProducerScope<? super IndexedValue<? extends E>>, Continuation<? super Unit>, Object>($this$withIndex, null){
            Object L$1;
            int I$0;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_withIndex;
            {
                this.$this_withIndex = $receiver;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var6_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        index = 0;
                        var4_5 = this.$this_withIndex.iterator();
                        ** GOTO lbl33
                    }
                    case 1: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator<E>)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var4_5.next();
                            v1 = index++;
                            this.L$0 = $this$produce;
                            this.L$1 = var4_5;
                            this.I$0 = index;
                            this.label = 2;
                            v2 = $this$produce.send(new IndexedValue<E>(v1, e), this);
                            if (v2 == var6_2) {
                                return var6_2;
                            }
                            ** GOTO lbl33
                            break;
                        }
                    }
                    case 2: {
                        index = this.I$0;
                        var4_5 = (ChannelIterator)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl33:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = var4_5;
                        this.I$0 = index;
                        this.label = 1;
                        if ((v0 = var4_5.hasNext(this)) != var6_2) ** continue;
                        return var6_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super IndexedValue<? extends E>>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super IndexedValue<? extends E>> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel withIndex$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.withIndex(receiveChannel2, coroutineContext2);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel distinct(ReceiveChannel $this$distinct) {
        return ChannelsKt.distinctBy$default($this$distinct, null, new Function2<E, Continuation<? super E>, Object>(null){
            int label;
            /* synthetic */ Object L$0;

            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(object);
                        Object it = this.L$0;
                        return it;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<E, Continuation<? super E>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(E p1, @Nullable Continuation<? super E> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 1, null);
    }

    @PublishedApi
    @NotNull
    public static final <E, K> ReceiveChannel<E> distinctBy(@NotNull ReceiveChannel<? extends E> $this$distinctBy, @NotNull CoroutineContext context, @NotNull Function2<? super E, ? super Continuation<? super K>, ? extends Object> selector) {
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumes($this$distinctBy), new Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object>($this$distinctBy, selector, null){
            Object L$1;
            Object L$2;
            Object L$3;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_distinctBy;
            final /* synthetic */ Function2<E, Continuation<? super K>, Object> $selector;
            {
                this.$this_distinctBy = $receiver;
                this.$selector = $selector;
                super(2, $completion);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                var7_2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        ResultKt.throwOnFailure(var1_1);
                        $this$produce = (ProducerScope)this.L$0;
                        keys = new HashSet();
                        var4_5 = this.$this_distinctBy.iterator();
                        ** GOTO lbl53
                    }
                    case 1: {
                        var4_5 = (ChannelIterator<E>)this.L$2;
                        keys = (HashSet)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v0 = $result;
                        while (true) {
                            if ((Boolean)v0 == false) return Unit.INSTANCE;
                            e = var4_5.next();
                            this.L$0 = $this$produce;
                            this.L$1 = keys;
                            this.L$2 = var4_5;
                            this.L$3 = e;
                            this.label = 2;
                            v1 = this.$selector.invoke(e, this);
                            if (v1 == var7_2) {
                                return var7_2;
                            }
                            ** GOTO lbl34
                            break;
                        }
                    }
                    case 2: {
                        e = this.L$3;
                        var4_5 = (ChannelIterator)this.L$2;
                        keys = (HashSet)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v1 = $result;
lbl34:
                        // 2 sources

                        if (keys.contains(k = v1)) ** GOTO lbl53
                        this.L$0 = $this$produce;
                        this.L$1 = keys;
                        this.L$2 = var4_5;
                        this.L$3 = k;
                        this.label = 3;
                        v2 = $this$produce.send(e, this);
                        if (v2 == var7_2) {
                            return var7_2;
                        }
                        ** GOTO lbl51
                    }
                    case 3: {
                        k = this.L$3;
                        var4_5 = (ChannelIterator)this.L$2;
                        keys = (HashSet)this.L$1;
                        $this$produce = (ProducerScope)this.L$0;
                        ResultKt.throwOnFailure($result);
                        v2 = $result;
lbl51:
                        // 2 sources

                        ((Collection)keys).add(k);
lbl53:
                        // 3 sources

                        this.L$0 = $this$produce;
                        this.L$1 = keys;
                        this.L$2 = var4_5;
                        this.L$3 = null;
                        this.label = 1;
                        if ((v0 = var4_5.hasNext(this)) != var7_2) ** continue;
                        return var7_2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super E>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super E> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel distinctBy$default(ReceiveChannel receiveChannel2, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 1) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.distinctBy(receiveChannel2, coroutineContext2, function2);
    }

    @PublishedApi
    @Nullable
    public static final <E> Object toMutableSet(@NotNull ReceiveChannel<? extends E> $this$toMutableSet, @NotNull Continuation<? super Set<E>> $completion) {
        return ChannelsKt.toCollection($this$toMutableSet, (Collection)new LinkedHashSet(), $completion);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object any(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof any.1)) ** GOTO lbl-1000
        var9_2 = var1_1;
        if ((var9_2.label & -2147483648) != 0) {
            var9_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.any(null, this);
                }
            };
        }
        $result = $continuation.result;
        var10_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$any;
                $i$f$consume = false;
                cause$iv = null;
                $this$any_u24lambda_u2d15 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$any$2 = false;
                $continuation.L$0 = $this$consume$iv;
                $continuation.label = 1;
                v0 = $this$any_u24lambda_u2d15.iterator().hasNext($continuation);
                ** if (v0 != var10_4) goto lbl25
lbl24:
                // 1 sources

                return var10_4;
lbl25:
                // 1 sources

                ** GOTO lbl35
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$any$2 = false;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl35:
                    // 2 sources

                    var7_12 = v0;
                    return var7_12;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_10) {
            throw var5_10;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object count(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof count.1)) ** GOTO lbl-1000
        var15_2 = var1_1;
        if ((var15_2.label & -2147483648) != 0) {
            var15_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                Object L$1;
                Object L$2;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.count(null, this);
                }
            };
        }
        $result = $continuation.result;
        var16_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                count = new Ref.IntRef();
                $this$consumeEach$iv = $this$count;
                $i$f$consumeEach = false;
                $this$consume$iv$iv = $this$consumeEach$iv;
                $i$f$consume = false;
                cause$iv$iv = null;
                try {
                    $this$consumeEach_u24lambda_u2d1$iv = $this$consume$iv$iv;
                    $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                    var10_15 = $this$consumeEach_u24lambda_u2d1$iv.iterator();
                }
                catch (Throwable e$iv$iv) {
                    try {
                        cause$iv$iv = e$iv$iv;
                        throw e$iv$iv;
                    }
                    catch (Throwable var8_13) {
                        ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                        throw var8_13;
                    }
                }
lbl32:
                // 2 sources

                while (true) {
                    $continuation.L$0 = count;
                    $continuation.L$1 = $this$consume$iv$iv;
                    $continuation.L$2 = var10_15;
                    $continuation.label = 1;
                    v0 = var10_15.hasNext($continuation);
                    if (v0 == var16_4) {
                        return var16_4;
                    }
                    ** GOTO lbl52
                    break;
                }
            }
            case 1: {
                $i$f$consumeEach = false;
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__Channels_commonKt$consumeEach$2$iv = false;
                var10_15 = (ChannelIterator<E>)$continuation.L$2;
                cause$iv$iv = null;
                $this$consume$iv$iv = (ReceiveChannel)$continuation.L$1;
                count = (Ref.IntRef)$continuation.L$0;
                {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl52:
                    // 2 sources

                    if (((Boolean)v0).booleanValue()) {
                        e$iv = var10_15.next();
                        $i$a$-consumeEach-ChannelsKt__DeprecatedKt$count$2 = false;
                        var13_18 = count.element;
                        count.element = var13_18 + 1;
                        ** continue;
                    }
                    $this$consumeEach_u24lambda_u2d1$iv = Unit.INSTANCE;
                }
                ChannelsKt.cancelConsumed($this$consume$iv$iv, cause$iv$iv);
                return Boxing.boxInt(count.element);
            }
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object maxWith(ReceiveChannel var0, Comparator var1_1, Continuation var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[CASE]], but top level block is 2[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object minWith(ReceiveChannel var0, Comparator var1_1, Continuation var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[CASE]], but top level block is 2[TRYBLOCK]
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1030)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ Object none(ReceiveChannel var0, Continuation var1_1) {
        if (!(var1_1 instanceof none.1)) ** GOTO lbl-1000
        var9_2 = var1_1;
        if ((var9_2.label & -2147483648) != 0) {
            var9_2.label -= -2147483648;
        } else lbl-1000:
        // 2 sources

        {
            $continuation = new ContinuationImpl(var1_1){
                Object L$0;
                /* synthetic */ Object result;
                int label;

                @Nullable
                public final Object invokeSuspend(@NotNull Object $result) {
                    this.result = $result;
                    this.label |= Integer.MIN_VALUE;
                    return ChannelsKt.none(null, this);
                }
            };
        }
        $result = $continuation.result;
        var10_4 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch ($continuation.label) {
            case 0: {
                ResultKt.throwOnFailure($result);
                $this$consume$iv = $this$none;
                $i$f$consume = false;
                cause$iv = null;
                $this$none_u24lambda_u2d19 = $this$consume$iv;
                $i$a$-consume-ChannelsKt__DeprecatedKt$none$2 = false;
                $continuation.L$0 = $this$consume$iv;
                $continuation.label = 1;
                v0 = $this$none_u24lambda_u2d19.iterator().hasNext($continuation);
                ** if (v0 != var10_4) goto lbl25
lbl24:
                // 1 sources

                return var10_4;
lbl25:
                // 1 sources

                ** GOTO lbl35
            }
            case 1: {
                $i$f$consume = false;
                $i$a$-consume-ChannelsKt__DeprecatedKt$none$2 = false;
                cause$iv = null;
                $this$consume$iv = (ReceiveChannel)$continuation.L$0;
                try {
                    ResultKt.throwOnFailure($result);
                    v0 = $result;
lbl35:
                    // 2 sources

                    var7_14 = Boxing.boxBoolean((Boolean)v0 == false);
                    return var7_14;
                }
                catch (Throwable e$iv) {
                    cause$iv = e$iv;
                    throw e$iv;
                }
            }
        }
        catch (Throwable var5_11) {
            throw var5_11;
        }
        finally {
            ChannelsKt.cancelConsumed($this$consume$iv, cause$iv);
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }

    @Deprecated(message="Left for binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel requireNoNulls(ReceiveChannel $this$requireNoNulls) {
        return ChannelsKt.map$default($this$requireNoNulls, null, new Function2<E, Continuation<? super E>, Object>($this$requireNoNulls, null){
            int label;
            /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<E> $this_requireNoNulls;
            {
                this.$this_requireNoNulls = $receiver;
                super(2, $completion);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object object) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                switch (this.label) {
                    case 0: {
                        Object it;
                        ResultKt.throwOnFailure(object);
                        Object object2 = it = this.L$0;
                        if (object2 == null) {
                            throw new IllegalArgumentException("null element found in " + this.$this_requireNoNulls + '.');
                        }
                        return object2;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<E, Continuation<? super E>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@Nullable E p1, @Nullable Continuation<? super E> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 1, null);
    }

    @Deprecated(message="Binary compatibility", level=DeprecationLevel.HIDDEN)
    public static final /* synthetic */ ReceiveChannel zip(ReceiveChannel $this$zip, ReceiveChannel other) {
        return ChannelsKt.zip$default($this$zip, other, null, zip.1.INSTANCE, 2, null);
    }

    @PublishedApi
    @NotNull
    public static final <E, R, V> ReceiveChannel<V> zip(@NotNull ReceiveChannel<? extends E> $this$zip, @NotNull ReceiveChannel<? extends R> other, @NotNull CoroutineContext context, @NotNull Function2<? super E, ? super R, ? extends V> transform2) {
        ReceiveChannel[] arrreceiveChannel = new ReceiveChannel[]{$this$zip, other};
        return ProduceKt.produce$default(GlobalScope.INSTANCE, context, 0, null, ChannelsKt.consumesAll(arrreceiveChannel), new Function2<ProducerScope<? super V>, Continuation<? super Unit>, Object>(other, $this$zip, transform2, null){
            Object L$1;
            Object L$2;
            Object L$3;
            Object L$4;
            Object L$5;
            int label;
            private /* synthetic */ Object L$0;
            final /* synthetic */ ReceiveChannel<R> $other;
            final /* synthetic */ ReceiveChannel<E> $this_zip;
            final /* synthetic */ Function2<E, R, V> $transform;
            {
                this.$other = $other;
                this.$this_zip = $receiver;
                this.$transform = $transform;
                super(2, $completion);
            }

            /*
             * Exception decompiling
             */
            @Nullable
            public final Object invokeSuspend(@NotNull Object var1_1) {
                /*
                 * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                 * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CASE]], but top level block is 0[TRYBLOCK]
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:429)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:478)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:728)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:806)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
                 * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:588)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperAnonymousInner.dumpWithArgs(ClassFileDumperAnonymousInner.java:87)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.ConstructorInvokationAnonymousInner.dumpInner(ConstructorInvokationAnonymousInner.java:75)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.StaticFunctionInvokation.dumpInner(StaticFunctionInvokation.java:116)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dumpWithOuterPrecedence(AbstractExpression.java:124)
                 * org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractExpression.dump(AbstractExpression.java:80)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredReturn.dump(StructuredReturn.java:52)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.dump(Block.java:560)
                 * org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.dump(Op04StructuredStatement.java:214)
                 * org.benf.cfr.reader.entities.attributes.AttributeCode.dump(AttributeCode.java:135)
                 * org.benf.cfr.reader.state.TypeUsageCollectingDumper.dump(TypeUsageCollectingDumper.java:187)
                 * org.benf.cfr.reader.entities.Method.dump(Method.java:617)
                 * org.benf.cfr.reader.entities.classfilehelpers.AbstractClassFileDumper.dumpMethods(AbstractClassFileDumper.java:193)
                 * org.benf.cfr.reader.entities.classfilehelpers.ClassFileDumperNormal.dump(ClassFileDumperNormal.java:77)
                 * org.benf.cfr.reader.entities.ClassFile.dump(ClassFile.java:1138)
                 * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:932)
                 * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
                 * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
                 * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
                 * org.benf.cfr.reader.Main.main(Main.java:49)
                 */
                throw new IllegalStateException(Decompilation failed);
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object value, @NotNull Continuation<?> $completion) {
                Function2<ProducerScope<? super V>, Continuation<? super Unit>, Object> function2 = new /* invalid duplicate definition of identical inner class */;
                function2.L$0 = value;
                return (Continuation)((Object)function2);
            }

            @Nullable
            public final Object invoke(@NotNull ProducerScope<? super V> p1, @Nullable Continuation<? super Unit> p2) {
                return (this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
            }
        }, 6, null);
    }

    public static /* synthetic */ ReceiveChannel zip$default(ReceiveChannel receiveChannel2, ReceiveChannel receiveChannel3, CoroutineContext coroutineContext2, Function2 function2, int n, Object object) {
        if ((n & 2) != 0) {
            coroutineContext2 = Dispatchers.getUnconfined();
        }
        return ChannelsKt.zip(receiveChannel2, receiveChannel3, coroutineContext2, function2);
    }

    @PublishedApi
    @NotNull
    public static final Function1<Throwable, Unit> consumes(@NotNull ReceiveChannel<?> $this$consumes) {
        return new Function1<Throwable, Unit>($this$consumes){
            final /* synthetic */ ReceiveChannel<?> $this_consumes;
            {
                this.$this_consumes = $receiver;
                super(1);
            }

            public final void invoke(@Nullable Throwable cause) {
                ChannelsKt.cancelConsumed(this.$this_consumes, cause);
            }
        };
    }
}

